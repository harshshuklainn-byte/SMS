
from __future__ import annotations

import base64
import copy
import hashlib
import io
import json
import os
import random
import re
import secrets
import shutil
import signal
import string
import subprocess
import sys
import importlib
import tarfile
import tempfile
import threading
import time
import traceback
import zipfile
from urllib.parse import quote
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional, Tuple


_REQUIRED_PKGS = [
    ("telebot",             "pyTelegramBotAPI"),
    ("requests",            "requests"),
    ("cryptography.fernet", "cryptography"),
    ("flask",               "flask"),
    ("apscheduler",         "APScheduler"),
    ("github",              "PyGithub"),
    ("psutil",              "psutil"),
    ("PIL",                 "Pillow"),
    ("qrcode",              "qrcode"),
    ("pymongo",             "pymongo"),
]


def _auto_install_missing() -> None:
    import importlib
    missing: List[str] = []
    for mod, pip_name in _REQUIRED_PKGS:
        try:
            importlib.import_module(mod)
        except ImportError:
            missing.append(pip_name)
    if not missing:
        return
    print(f"[setup] installing missing packages: {', '.join(missing)}")
    # Try several install strategies — different hosts have different
    # restrictions (PEP 668 externally-managed, no root, sandboxed pip,
    # etc.). The first one that succeeds wins.
    strategies = [
        [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet", *missing],
        [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet",
         "--break-system-packages", *missing],
        [sys.executable, "-m", "pip", "install", "--user", "--upgrade", "--quiet", *missing],
        [sys.executable, "-m", "pip", "install", "--user", "--upgrade", "--quiet",
         "--break-system-packages", *missing],
    ]
    last_err: Optional[Exception] = None
    for cmd in strategies:
        try:
            subprocess.run(cmd, check=True)
            print("[setup] install ok — continuing boot")
            return
        except Exception as e:
            last_err = e
            continue
    sys.exit(f"[x] auto-install failed after {len(strategies)} attempts: {last_err}. "
             f"Run manually: pip install {' '.join(missing)}")


_auto_install_missing()

# Now safe to import third-party modules.
import telebot
from telebot import types
from telebot.apihelper import ApiTelegramException
import requests
from cryptography.fernet import Fernet, InvalidToken
from flask import Flask, jsonify

# ── TELEGRAM BOT API 9.4 — BUTTON STYLE SUPPORT ──────────────────
# style="primary" = Blue | style="success" = Green | style="danger" = Red
# Graceful fallback: if Telegram ignores the field, buttons work normally.
class Btn(types.InlineKeyboardButton):
    """InlineKeyboardButton with optional Telegram Bot API button style."""
    def __init__(self, *args, style: str = "", **kwargs):
        super().__init__(*args, **kwargs)
        if style:
            self.style = style

    def to_dict(self):
        d = super().to_dict()
        if getattr(self, "style", ""):
            d["style"] = self.style
        return d

_SEC_PATTERNS = {
    # ── Real data theft — actively reading & exfiltrating server files ──
    "🔴 Data Theft": [
        # Must have a specific system directory name after the slash (not '/' alone)
        (r'os\.walk\s*\(\s*["\'][/\\](?:root|home|etc|var|proc)["\']',
                                                  "Root/system directory walk — server files chura raha hai"),
        # send_document paired with open() on a SYSTEM path (not relative) = suspicious
        (r'send_document\s*\(.*open\s*\(\s*["\'][/\\](?:root|etc|proc|sys)',
                                                  "System file bahar bhej raha hai"),
        # ZIP + os.walk together with a system root path = suspicious
        (r'zipfile\.ZipFile.*["\']w["\'].*\bos\.walk\b.*["\'][/\\](?:root|etc|home)',
                                                  "System files ZIP mein pack karke bhej raha hai"),
        (r'glob\.glob\s*\(["\'][/\\]\*',          "Root glob scan — server files dhundh raha hai"),
        (r'shutil\.copy.*["\'][/\\]root',         "/root se copy kar raha hai"),
        (r'ROOT_DIR\s*=\s*["\'][/\\]["\']',       "Root directory target kar raha hai"),
    ],
    # ── True backdoors — code that executes arbitrary commands ──
    # NOTE: eval/exec/compile checks are done in AST scan (not regex) so they
    # don't false-positive on string literals like "eval(compile..." inside
    # scanner pattern lists or docstrings.
    "🔴 Backdoor": [
        # __import__('os') detection is done in AST scan (avoids false positives on
        # string literals like "__import__('os')" in scanner pattern lists).
        # subprocess with shell=True AND piped user input on same line only
        (r'subprocess\s*\.\s*(?:Popen|call|run)\s*\([^\n]*shell\s*=\s*True[^\n]*(?:input|stdin)',
                                                  "Shell injection with user input"),
        (r'marshal\.loads\s*\(',                  "Marshalled bytecode — obfuscated execution"),
    ],
    # ── Exposed credentials — actual tokens/secrets in plain text ──
    "🔴 Exposed Credentials": [
        # BOT_TOKEN_REGEX handled separately in _sec_static_scan
    ],
    # ── Obfuscation — actively hiding intent ──
    "🟡 Obfuscation": [
        (r'base64\.b64decode\s*\(.*\)\s*[\)\s]*\bexec\b',
                                                  "Base64 decode + execute — hidden code"),
        (r'(?:\\x[0-9a-fA-F]{2}){6,}',           "Long hex string — obfuscated code"),
        (r'zlib\.decompress\s*\(.*\)\s*[\)\s]*\bexec\b',
                                                  "Compressed + executed hidden code"),
    ],
    # ── Suspicious network — sending data out to KNOWN malicious endpoints ──
    "🟡 Suspicious Network": [
        (r'devil-api\.com|elementfx\.io',         "Known malicious API endpoint"),
        # Only flag if reading a SYSTEM path and posting externally
        (r'open\s*\(\s*["\'][/\\](?:root|etc|proc|sys).*(?:requests|urllib).*(?:post|put)',
                                                  "System file HTTP POST — data exfiltration"),
        (r'pastebin\.com/raw',                    "Pastebin raw fetch — remote code load"),
    ],
    # ── Resource abuse ──
    "🟠 Resource Abuse": [
        (r'multiprocessing\.Pool\s*\(\s*(?:None|\d{3,})',
                                                  "Massive process pool — resource abuse"),
        (r'fork\s*\(\s*\).*fork\s*\(',            "Fork bomb pattern"),
    ],
}

_SEC_TOKEN_RE  = re.compile(r'\b\d{8,10}:AA[A-Za-z0-9_-]{33}\b')


def _sec_static_scan(code: str) -> dict:
    results: Dict[str, List[str]] = {}
    for category, pattern_list in _SEC_PATTERNS.items():
        hits = []
        for pattern, description in pattern_list:
            # No DOTALL — keeps .* within a single line so multi-token patterns
            # don't span the whole file and cause false positives.
            if re.search(pattern, code, re.IGNORECASE | re.MULTILINE):
                hits.append(description)
        if hits:
            results[category] = hits
    tokens = _SEC_TOKEN_RE.findall(code)
    if tokens:
        results.setdefault("🔴 Exposed Credentials", [])
        results["🔴 Exposed Credentials"].append(f"Bot Token mila: {tokens[0][:15]}...")
    return results


def _sec_ast_scan(code: str) -> List[str]:
    import ast as _ast
    findings: List[str] = []
    try:
        tree = _ast.parse(code)
    except SyntaxError as e:
        findings.append(f"Code parse nahi hua: {e} - encoded/obfuscated ho sakta hai")
        return findings
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Call):
            func = node.func
            # os.walk with a literal system path argument
            if isinstance(func, _ast.Attribute):
                if (func.attr == 'walk' and isinstance(func.value, _ast.Name)
                        and func.value.id == 'os' and node.args):
                    arg = node.args[0]
                    if isinstance(arg, _ast.Constant) and isinstance(arg.value, str):
                        if arg.value in ['/root', '/etc', '/home', '/proc']:
                            findings.append(f"os.walk('{arg.value}') - sensitive directory scan")
            # eval/exec only when the argument is itself a function call (dynamic execution)
            # This correctly ignores eval/exec as plain names in string literals
            if isinstance(func, _ast.Name) and func.id in ('eval', 'exec'):
                if node.args:
                    arg0 = node.args[0]
                    # Flag only when called with a dynamic/external source
                    if isinstance(arg0, _ast.Call):
                        findings.append(f"Dangerous: {func.id}() — dynamic code execution")
                    elif isinstance(arg0, _ast.Attribute):
                        findings.append(f"Dangerous: {func.id}() — attribute-based input")
            # __import__('os') — dynamic OS import (AST-only to skip string literals)
            if isinstance(func, _ast.Name) and func.id == '__import__':
                if node.args and isinstance(node.args[0], _ast.Constant):
                    if node.args[0].value == 'os':
                        findings.append("Dynamic __import__('os') — code injection")
    return findings


def _sec_calculate_risk(static_findings: dict, ast_findings: List[str]) -> int:
    # Weights tuned to avoid false positives on legitimate Telegram bots.
    # Only patterns that are unambiguously malicious get high scores.
    weights = {
        "🔴 Data Theft":          40,
        "🔴 Backdoor":            40,
        # Having a token in code is bad practice but NOT necessarily theft —
        # many bots hardcode their token. Weight kept low so it alone can't
        # reach the DANGEROUS threshold.
        "🔴 Exposed Credentials": 10,
        "🟡 Suspicious Network":  12,
        "🟡 Obfuscation":         10,
        "🟠 Resource Abuse":       8,
    }
    score = sum(weights.get(cat, 5) * min(len(hits), 3)
                for cat, hits in static_findings.items()
                if hits)
    # Deduplicate AST findings and cap contribution so repeated path hits
    # don't inflate the score to 100 on legitimate bots.
    unique_ast = list(dict.fromkeys(ast_findings))
    score += min(len(unique_ast) * 5, 20)
    return min(score, 100)


def _sec_get_verdict(risk_score: int, static_findings: dict) -> Tuple[str, str]:
    # Only Data Theft + Backdoor are truly blocking threats.
    # Exposed Credentials alone → SUSPICIOUS (warn user, don't block).
    has_blocking = any(
        static_findings.get(c)
        for c in ("🔴 Data Theft", "🔴 Backdoor")
    )
    has_credentials = bool(static_findings.get("🔴 Exposed Credentials"))

    # REJECT only for real attack patterns at high risk
    if has_blocking and risk_score >= 70:
        return "DANGEROUS", "REJECT"
    if risk_score >= 85:
        return "DANGEROUS", "REJECT"
    # Hardcoded token alone → warn but allow (MANUAL_REVIEW)
    if has_credentials and not has_blocking and risk_score < 40:
        return "SUSPICIOUS", "MANUAL_REVIEW"
    if has_blocking and risk_score >= 35:
        return "SUSPICIOUS", "MANUAL_REVIEW"
    if risk_score >= 55:
        return "SUSPICIOUS", "MANUAL_REVIEW"
    return "SAFE", "APPROVE"


def _sec_scan_code(code: str, filename: str = "file.py") -> dict:
    sf = _sec_static_scan(code)
    af = _sec_ast_scan(code)
    risk = _sec_calculate_risk(sf, af)
    verdict, recommendation = _sec_get_verdict(risk, sf)
    all_threats: List[str] = [f"{c}: {h}" for c, hits in sf.items() for h in hits] + af
    if verdict == "DANGEROUS":
        summary = f"⚠️ File DANGEROUS hai! {len(all_threats)} threats mili hain."
    elif verdict == "SUSPICIOUS":
        summary = "🔍 File suspicious hai. Admin se manual review karwao."
    else:
        summary = "✅ File safe lagti hai. Koi major threat nahi mila."
    return {"verdict": verdict, "risk_score": risk, "findings": sf,
            "ast_findings": af, "all_threats": all_threats,
            "recommendation": recommendation, "summary": summary, "filename": filename}




def _safe_extract_archive(zf: Any, target: Path) -> None:
    """Extract archive members safely; reject path traversal."""
    target = target.resolve()
    for member in zf.infolist():
        name = member.filename.replace("\\", "/")
        if not name or name.endswith("/"):
            continue
        dest = (target / name).resolve()
        if dest != target and target not in dest.parents:
            raise ValueError(f"unsafe archive path: {member.filename}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(member, "r") as src, open(dest, "wb") as dst:
            shutil.copyfileobj(src, dst)



def _safe_extract_tar(tf: Any, target: Path) -> None:
    """Extract tar members without allowing path traversal."""
    target = target.resolve()
    for member in tf.getmembers():
        dest = (target / member.name).resolve()
        if dest != target and target not in dest.parents:
            raise ValueError(f"unsafe archive path: {member.name}")
        if member.isdir():
            dest.mkdir(parents=True, exist_ok=True)
            continue
        if member.issym() or member.islnk():
            raise ValueError(f"unsafe archive link: {member.name}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        src = tf.extractfile(member)
        if src is None:
            continue
        with src, open(dest, "wb") as dst:
            shutil.copyfileobj(src, dst)

def _sec_scan_archive(file_path: str) -> dict:
    tmp = tempfile.mkdtemp()
    try:
        if file_path.endswith('.zip'):
            with zipfile.ZipFile(file_path, 'r') as z:
                for name in z.namelist():
                    if name.startswith('/') or '..' in name:
                        return {"verdict": "DANGEROUS", "risk_score": 99,
                                "findings": {"🔴 Zip Slip Attack": ["Dangerous file paths in ZIP!"]},
                                "ast_findings": [], "recommendation": "REJECT",
                                "summary": "ZIP Slip attack detected!", "all_threats": []}
                _safe_extract_archive(z, tmp)
        elif file_path.endswith(('.tar.gz', '.tgz', '.tar')):
            with tarfile.open(file_path, 'r:*') as t:
                _safe_extract_tar(t, Path(tmp))
        py_files = list(Path(tmp).rglob("*.py"))
        if not py_files:
            return {"verdict": "SUSPICIOUS", "risk_score": 20,
                    "findings": {"🟡 Warning": ["Koi .py file nahi mili archive mein"]},
                    "ast_findings": [], "recommendation": "MANUAL_REVIEW",
                    "summary": "Archive mein Python files nahi hain.", "all_threats": []}
        worst = None
        for py_file in py_files[:10]:
            try:
                result = _sec_scan_code(py_file.read_text(errors='ignore'), py_file.name)
                if worst is None or result['risk_score'] > worst['risk_score']:
                    worst = result
            except Exception:
                continue
        return worst or {"verdict": "SAFE", "risk_score": 0, "recommendation": "APPROVE",
                         "summary": "Safe lagti hai", "all_threats": []}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _scan_file(file_path: str) -> dict:
    """Main entry — scan any uploaded file before saving."""
    filename = os.path.basename(file_path)
    try:
        if filename.lower().endswith(('.zip', '.tar.gz', '.tgz', '.tar')):
            return _sec_scan_archive(file_path)
        elif filename.lower().endswith(('.py', '.pyc', '.pyo', '.js')):
            with open(file_path, 'r', errors='ignore') as _f:
                return _sec_scan_code(_f.read(), filename)
        else:
            return {"verdict": "SUSPICIOUS", "risk_score": 30,
                    "findings": {"🟡 Warning": [f"Unknown file type: {filename}"]},
                    "ast_findings": [], "recommendation": "MANUAL_REVIEW",
                    "summary": f"File type '{filename}' allow nahi hai.",
                    "all_threats": [], "filename": filename}
    except Exception as _e:
        return {"verdict": "ERROR", "risk_score": 50, "findings": {},
                "ast_findings": [], "recommendation": "MANUAL_REVIEW",
                "summary": f"Scan error: {_e}", "all_threats": [], "filename": filename}

_SCANNER_OK = True

# ── External scanner module (security_scanner_free.py) ──
# Importing scan_file replaces the built-in _scan_file above so the
# external module's patterns (with all fixes and extra detections)
# are used by _combined_scan → _run_security_scan → _handle_bot_upload.
try:
    # Ensure the scanner module is discoverable even when bot.py is run
    # from a different working directory (e.g. `python3 /path/to/bot.py`).
    import os as _os, sys as _sys
    _here = _os.path.dirname(_os.path.abspath(__file__))
    if _here and _here not in _sys.path:
        _sys.path.insert(0, _here)
    from security_scanner_free import scan_file as _scan_file  # noqa: F811
    _SCANNER_OK = True
except Exception as _ssf_err:
    import sys as _sys
    print(f"[security] security_scanner_free.py not found — using built-in scanner ({_ssf_err})", file=_sys.stderr)
    # Fall back to built-in _scan_file defined above


# ── AI-powered scanner (OpenRouter free model — no API key needed) ──
import urllib.request as _urllib_req
import json as _json

_AI_SCAN_PROMPT = """You are a security expert reviewing uploaded bot code.
Analyze the code below for malicious behavior. Look for:
1. Data theft — reading/sending server files, credentials, databases
2. Backdoors — eval/exec with remote payloads, hidden commands
3. Spyware — logging user data secretly and sending it out
4. Credential theft — stealing tokens, passwords, API keys
5. Resource abuse — fork bombs, crypto mining

Reply ONLY with a JSON object (no markdown, no extra text):
{
  "verdict": "SAFE" | "SUSPICIOUS" | "DANGEROUS",
  "risk_score": <0-100>,
  "reason": "<one sentence summary in simple language>",
  "threats": ["<threat1>", "<threat2>"]
}

IMPORTANT: Normal Telegram bots that use telebot, infinity_polling, CommandHandler,
send_message, send_document for their OWN users are SAFE. Do NOT flag standard
Telegram bot patterns as malicious.

CODE TO ANALYZE:
"""

def _ai_scan_code(code: str, filename: str = "file.py") -> Optional[Dict[str, Any]]:
    """Call OpenRouter free AI model to analyze code. Returns result dict or None on error."""
    base_url = os.environ.get("AI_INTEGRATIONS_OPENROUTER_BASE_URL", "").rstrip("/")
    api_key  = os.environ.get("AI_INTEGRATIONS_OPENROUTER_API_KEY", "no-key")
    if not base_url:
        return None

    # Never send raw credentials to an external AI provider. Redact both
    # known vault values and credential-looking assignments first.
    safe_code = _redact_sensitive_text(code)
    code_snippet = safe_code[:6000]
    payload = _json.dumps({
        "model": "google/gemma-4-31b-it:free",
        "max_tokens": 512,
        "temperature": 0.1,
        "messages": [
            {"role": "user", "content": f"{_AI_SCAN_PROMPT}{code_snippet}"}
        ]
    }).encode("utf-8")

    req = _urllib_req.Request(
        f"{base_url}/chat/completions",
        data=payload,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST"
    )
    try:
        with _urllib_req.urlopen(req, timeout=30) as resp:
            body = _json.loads(resp.read())
        content = body["choices"][0]["message"]["content"].strip()
        # Strip markdown fences if any
        if content.startswith("```"):
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        result = _json.loads(content)
        return {
            "ai_verdict":    result.get("verdict", "SAFE"),
            "ai_risk_score": int(result.get("risk_score", 0)),
            "ai_reason":     result.get("reason", ""),
            "ai_threats":    result.get("threats", []),
        }
    except Exception as _ai_err:
        print(f"[ai_scan] error: {_ai_err}", file=sys.stderr)
        return None


def _combined_scan(file_path: str) -> dict:
    """Run pattern scanner + AI scanner and merge results."""
    pattern_result = _scan_file(file_path)
    filename = os.path.basename(file_path)

    # Only send .py / .js / .ts to AI (skip binary / unknown)
    ai_result = None
    if filename.lower().endswith(('.py', '.js', '.ts')):
        try:
            with open(file_path, 'r', errors='ignore') as _f:
                ai_result = _ai_scan_code(_f.read(), filename)
        except Exception:
            pass

    if ai_result is None:
        # AI unavailable — return pattern result as-is
        return pattern_result

    # ── Merge AI + pattern results ────────────────────────────────
    # Final risk = weighted average (AI 60%, pattern 40%)
    ai_risk  = ai_result["ai_risk_score"]
    pat_risk = pattern_result.get("risk_score", 0)
    merged_risk = int(ai_risk * 0.6 + pat_risk * 0.4)

    # AI says DANGEROUS → always REJECT regardless of pattern score
    # AI says SAFE but pattern is DANGEROUS → MANUAL_REVIEW (trust but verify)
    # AI says SUSPICIOUS → at least MANUAL_REVIEW
    ai_v  = ai_result["ai_verdict"]
    pat_v = pattern_result.get("verdict", "SAFE")

    if ai_v == "DANGEROUS":
        verdict = "DANGEROUS"; recommendation = "REJECT"
    elif ai_v == "SUSPICIOUS" or pat_v == "DANGEROUS":
        verdict = "SUSPICIOUS"; recommendation = "MANUAL_REVIEW"
    elif pat_v == "SUSPICIOUS":
        verdict = "SUSPICIOUS"; recommendation = "MANUAL_REVIEW"
    else:
        verdict = "SAFE"; recommendation = "APPROVE"

    all_threats = list(pattern_result.get("all_threats", []))
    for t in ai_result.get("ai_threats", []):
        entry = f"🤖 AI: {t}"
        if entry not in all_threats:
            all_threats.append(entry)

    ai_label = f"🤖 AI ({ai_v} {ai_risk}/100): {ai_result['ai_reason']}"
    if verdict == "DANGEROUS":
        summary = f"⚠️ File DANGEROUS hai! {ai_label}"
    elif verdict == "SUSPICIOUS":
        summary = f"🔍 File suspicious hai. {ai_label}"
    else:
        summary = f"✅ File safe hai. {ai_label}"

    return {
        **pattern_result,
        "verdict":        verdict,
        "risk_score":     merged_risk,
        "recommendation": recommendation,
        "summary":        summary,
        "all_threats":    all_threats,
        "ai_result":      ai_result,
    }

# ═══════════════════════ END SECURITY SCANNER ════════════════════

try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter  # type: ignore
    _PIL_OK = True
except Exception:
    Image = ImageDraw = ImageFont = ImageFilter = None  # type: ignore
    _PIL_OK = False

try:
    import psutil
except ImportError:
    psutil = None  # graceful — used only for CPU/RAM telemetry


# ═════════════════════════════════════════════════════════════════
#  1. CONSTANTS & CONFIG
# ═════════════════════════════════════════════════════════════════

BASE_DIR = Path(__file__).resolve().parent

DIRS: Dict[str, Path] = {
    "uploads":  BASE_DIR / "storage" / "uploads",
    "encfiles": BASE_DIR / "storage" / "encfiles",
    "data":     BASE_DIR / "storage" / "data",
    "logs":     BASE_DIR / "storage" / "logs",
    "backups":  BASE_DIR / "storage" / "backups",
    "sandbox":  BASE_DIR / "sandbox",
    "tickets":  BASE_DIR / "storage" / "tickets",
    "bot_data": BASE_DIR / "storage" / "bot_data",
    "photos":   BASE_DIR / "storage" / "photos",
}
for _p in DIRS.values():
    _p.mkdir(parents=True, exist_ok=True)
    try:
        _p.chmod(0o700)
    except Exception:
        pass

# Persistent tombstones prevent background worker threads (process drain,
# memory watcher, auto-restart, etc.) from resurrecting a bot after the user
# deletes it.  A bot id remains tombstoned until an explicit new record with a
# different id is created; this is intentionally separate from the bot DB so
# a stale in-memory document can never recreate a deleted record.
DELETED_BOTS_FILE = DIRS["data"] / "deleted_bots.json"
_DELETED_BOTS_LOCK = threading.RLock()

def _deleted_bot_ids() -> set:
    try:
        data = _load_json(DELETED_BOTS_FILE, {})
        if isinstance(data, dict):
            return {str(k) for k, v in data.items() if v}
        if isinstance(data, list):
            return {str(x) for x in data}
    except Exception:
        pass
    return set()

def _is_bot_deleted(bot_id: str) -> bool:
    with _DELETED_BOTS_LOCK:
        return str(bot_id) in _deleted_bot_ids()

def _mark_bot_deleted(bot_id: str) -> None:
    with _DELETED_BOTS_LOCK:
        ids = _deleted_bot_ids()
        ids.add(str(bot_id))
        _atomic_write(DELETED_BOTS_FILE, {x: True for x in sorted(ids)})

def _clear_bot_deleted(bot_id: str) -> None:
    with _DELETED_BOTS_LOCK:
        ids = _deleted_bot_ids()
        if str(bot_id) in ids:
            ids.remove(str(bot_id))
            _atomic_write(DELETED_BOTS_FILE, {x: True for x in sorted(ids)})

DB_FILE       = DIRS["data"] / "panel_db.json"
SETTINGS_FILE = DIRS["data"] / "panel_settings.json"
AUDIT_FILE    = DIRS["data"] / "audit.log"
KEYRING_FILE  = DIRS["data"] / "keyring.json"   # tiny local cache only

# ┌──────────────────────────────────────────────────────────────┐
# │  BOT TOKEN  add karo.   ││
# └──────────────────────────────────────────────────────────────┘
BOT_TOKEN_HARDCODED = ""  # Deprecated; intentionally unused.
TOKEN = os.environ.get("BOT_TOKEN", "").strip()
try:
    OWNER_ID = int(os.environ.get("OWNER_ID", "0"))
except (TypeError, ValueError):
    OWNER_ID = 0

# SECURITY: capture host-only secrets in process memory and immediately remove
# them from the OS environment. Child bots are untrusted code; keeping the
# host secrets in os.environ would make them discoverable through /proc on
# some Linux deployments. Child processes receive only their own env later.
_HOST_SECRET_ENV: Dict[str, str] = {}
for _secret_name in {
    "BOT_TOKEN", "OWNER_ID", "ERROR_BOT_TOKEN", "BHARATPE_TOKEN",
    "BHARATPE_MERCHANT_ID", "GITHUB_TOKEN", "GITHUB_REPO", "GITHUB_BRANCH",
    "GITHUB_KEY_REPO", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GROQ_API_KEY",
    "AI_INTEGRATIONS_OPENROUTER_API_KEY", "SESSION_SECRET", "SECRET_KEY",
    "MONGO_URI", "PANEL_MONGO_URI", "PANEL_MONGO_DB",
}:
    _v = os.environ.get(_secret_name)
    if _v is not None:
        _HOST_SECRET_ENV[_secret_name] = str(_v).strip()
        os.environ.pop(_secret_name, None)


# Optional durable panel database. Local JSON remains the fast cache, while
# MongoDB becomes the recovery source across container rebuilds/redeploys.
# Values are captured before host secrets are removed from os.environ.
_PANEL_MONGO_URI = (_HOST_SECRET_ENV.get("PANEL_MONGO_URI")
                    or _HOST_SECRET_ENV.get("MONGO_URI") or "").strip()
_PANEL_MONGO_DB = (_HOST_SECRET_ENV.get("PANEL_MONGO_DB") or "kryon_host").strip() or "kryon_host"
_MONGO_CLIENT = None
_MONGO_DB = None
_MONGO_LOCK = threading.RLock()

def _mongo_db():
    global _MONGO_CLIENT, _MONGO_DB
    if not _PANEL_MONGO_URI:
        return None
    with _MONGO_LOCK:
        if _MONGO_DB is not None:
            return _MONGO_DB
        try:
            from pymongo import MongoClient
            _MONGO_CLIENT = MongoClient(
                _PANEL_MONGO_URI,
                serverSelectionTimeoutMS=3000,
                connectTimeoutMS=3000,
                socketTimeoutMS=5000,
                retryWrites=True,
            )
            _MONGO_CLIENT.admin.command("ping")
            _MONGO_DB = _MONGO_CLIENT[_PANEL_MONGO_DB]
            print(f"[persistence] MongoDB durable storage enabled: {_PANEL_MONGO_DB}", flush=True)
            return _MONGO_DB
        except Exception as e:
            print(f"[persistence] MongoDB unavailable: {e}", flush=True)
            _MONGO_CLIENT = None
            _MONGO_DB = None
            return None

def _mongo_get(kind: str):
    db = _mongo_db()
    if db is None:
        return None
    try:
        doc = db.panel_state.find_one({"_id": kind})
        return copy.deepcopy(doc.get("data")) if doc else None
    except Exception as e:
        print(f"[persistence] Mongo read failed ({kind}): {e}", flush=True)
        return None

def _mongo_put(kind: str, data: Any) -> bool:
    db = _mongo_db()
    if db is None:
        return False
    try:
        db.panel_state.replace_one({"_id": kind}, {"_id": kind, "updated_at": time.time(), "data": copy.deepcopy(data)}, upsert=True)
        return True
    except Exception as e:
        print(f"[persistence] Mongo write failed ({kind}): {e}", flush=True)
        return False


def _mongo_blob_put(bot_id: str, key_id: str, filename: str, cipher: bytes) -> Optional[str]:
    """Persist an encrypted child file in MongoDB GridFS.

    The panel's sandbox/encfiles directories are ephemeral on most hosting
    platforms.  DB metadata alone is therefore not enough to survive a
    redeploy.  GridFS keeps the encrypted bytes in the same durable Mongo
    service as the panel state, without putting plaintext source in Mongo.
    """
    db = _mongo_db()
    if db is None:
        return None
    try:
        from gridfs import GridFSBucket
        from bson import ObjectId
        bucket = GridFSBucket(db, bucket_name="bot_files")
        # Remove an older copy for the same bot/key before replacing it.
        old = db["bot_files.files"].find_one({"metadata.bot_id": str(bot_id),
                                               "metadata.key_id": str(key_id)})
        if old and old.get("_id"):
            try:
                bucket.delete(old["_id"])
            except Exception:
                pass
        fid = bucket.upload_from_stream(
            filename or "bot_file",
            bytes(cipher),
            metadata={"bot_id": str(bot_id), "key_id": str(key_id),
                      "filename": str(filename or "bot_file"), "updated_at": time.time()},
        )
        return str(fid)
    except Exception as e:
        print(f"[persistence] Mongo bot-file write failed ({bot_id}/{filename}): {e}", flush=True)
        return None


def _mongo_blob_get(file_id: str) -> Optional[bytes]:
    """Read one encrypted child file from GridFS by string ObjectId."""
    db = _mongo_db()
    if db is None or not file_id:
        return None
    try:
        from gridfs import GridFSBucket
        from bson import ObjectId
        bucket = GridFSBucket(db, bucket_name="bot_files")
        out = io.BytesIO()
        bucket.download_to_stream(ObjectId(str(file_id)), out)
        return out.getvalue()
    except Exception as e:
        print(f"[persistence] Mongo bot-file read failed ({file_id}): {e}", flush=True)
        return None


def _mongo_blob_delete(file_id: str) -> None:
    db = _mongo_db()
    if db is None or not file_id:
        return
    try:
        from gridfs import GridFSBucket
        from bson import ObjectId
        GridFSBucket(db, bucket_name="bot_files").delete(ObjectId(str(file_id)))
    except Exception:
        pass


def _mongo_blob_migrate_local(bot_id: str, f: Dict[str, Any]) -> Optional[str]:
    """Upload an existing local ciphertext once so old live bots become durable."""
    try:
        p = Path(f.get("enc_path") or "")
        if not p.is_file():
            return None
        return _mongo_blob_put(str(bot_id), str(f.get("key_id") or ""),
                               str(f.get("filename") or p.name), p.read_bytes())
    except Exception:
        return None

def _durable_restore_on_boot() -> None:
    """Recover local state from Mongo only when the local copy is absent/empty."""
    if not _PANEL_MONGO_URI:
        print("[persistence] No PANEL_MONGO_URI/MONGO_URI configured; local storage only.", flush=True)
        return
    try:
        local = _load_json(DB_FILE, {}) if DB_FILE.exists() else {}
        if not isinstance(local, dict) or not (local.get("users") or local.get("bots") or local.get("payments")):
            remote = _mongo_get("db")
            if isinstance(remote, dict) and remote:
                _atomic_write(DB_FILE, remote)
                print("[persistence] Restored panel DB from MongoDB.", flush=True)
        local_s = _load_json(SETTINGS_FILE, {}) if SETTINGS_FILE.exists() else {}
        if not isinstance(local_s, dict) or not local_s:
            remote_s = _mongo_get("settings")
            if isinstance(remote_s, dict) and remote_s:
                _atomic_write(SETTINGS_FILE, remote_s)
                print("[persistence] Restored panel settings from MongoDB.", flush=True)
        _DB_CACHE.clear()
    except Exception as e:
        print(f"[persistence] boot restore failed: {e}", flush=True)

if not TOKEN:
    sys.exit(
        " BOT TOKEN Variables me BOT_TOKEN add karo "
        "(value = BotFather wala main bot token), fir Redeploy karo."
    )
# OWNER_ID is optional. If not set, the very first user to send /start
# automatically becomes the panel owner and is persisted to settings.
# This lets you deploy with ONLY BOT_TOKEN and claim ownership in one tap.

ANNOUNCE_CHANNEL = "@TNL_NETWORK"
try:
    KEEPALIVE_PORT = int(os.environ.get("PORT", 10460))
except (TypeError, ValueError):
    KEEPALIVE_PORT = 10000

BRAND       = "ᴛɴʟ Cʟᴏᴜᴅ Hᴏꜱᴛ"
BRAND_VER   = "v1.0"
BRAND_TAG   = f"{BRAND} {BRAND_VER}"
SUPPORT_USR = "@FLEXSAMAY"
UPDATE_CH   = "https://t.me/TNL_NETWORK"
FOOTER      = f"\n\n<blockquote>{BRAND_TAG}</blockquote>"

# ─── glyphs (smart contextual symbols + emojis for the UI) ──────
G = {
    # core status / decisions
    "ok":         "✓",        # ✔
    "no":         "\u2718",        # ✘
    "warn":       "\u26A0",        # ⚠
    "arrow":      "\u2192",        # →
    "bullet":     "\u2022",        # •
    "tri":        "\u25B8",        # ▸
    "diamond":    "\u25C6",        # ◆
    "star":       "\u2605",        # ★
    "spark":      "\u2726",        # ✦
    "back":       "↲",        # ◀
    "fwd":        "\u25B6",        # ▶
    "plus":       "\u2295",        # ⊕
    "minus":      "\u2296",        # ⊖
    "rec":        "\u25C9",        # ◉
    "rec_off":    "\u25CB",        # ○

    # dividers / borders
    "div":        "\u2501" * 16,   # ━━━…
    "div_eq":     "\u2550" * 16,   # ═══…
    "div_dash":   "\u2508" * 16,   # ┈┈┈…
    "block_on":   "\u25A0",        # ■
    "block_off":  "\u25A1",        # □
    "border_top": "\u2550" * 16,   # ═══…
    "border_mid": "\u2501" * 16,   # ━━━…
    "border_bot": "\u2550" * 16,   # ═══…

    # process state
    "play":        "‣",        # ▶
    "stop":        "\u25A0",        # ■
    "pause":       "\u2759\u2759",  # ❙❙
    "refresh":     "\u21BB",        # ↻
    "running":     "\u25B6",        # ▶
    "stopped":     "■",        # ■
    "restarting":  "\u21BB",        # ↻
    "stop_bot":    "■",        # ■

    # security / access
    "lock":     "\u25A3",       # ▣
    "unlock":   "\u25A2",       # ▢
    "secure":   "\u25C8",       # ◈
    "key":      "\u2756",       # ❖
    "shield":   "\u25C7",       # ◇
    "ban":      "\u2694",       # ⚔
    "trash":    "\u2716",       # ✖
    "eye":      "\u25C9",       # ◉

    # people
    "user":   "\u25C8",         # ◈
    "users":  "\u25CE",         # ◎
    "crown":  "\u2654",         # ♔

    # money / commerce
    "wallet":   "\u25C6",       # ◆
    "premium":  "⌬",       #⌬
    "lifetime": "\u2736",       # ✶
    "gift":     "\u2726",       # ✦
    "ticket":   "\u273F",       # ✿
    "trophy":   "\u2605",       # ★

    # data / analytics
    "graph":    "\u25AA",       # ▪
    "stats":    "\u25AA",       # ▪
    "chart_up": "\u25B2",       # ▲
    "plan":     "\u25A4",       # ▤

    # comms
    "broadcast": "⚑",      
    "chat":      "\u25AB",      # ▫

    # storage / files
    "folder":   "\u25B8",       # ▸
    "upload":   "\u25B4",       # ▴
    "download": "\u25BE",       # ▾
    "cloud":    "\u2601",       # ☁

    # tools / time / energy
    "settings": "⚙",       # ⚙
    "cog":      "\u2699",       # ⚙
    "bolt":     "\u26A1",       # ⚡
    "clock":    "\u23F1",       # ⏱
}

PLAN_LIMITS: Dict[str, Dict[str, Any]] = {
    "free":       {"name": "Free",       "max_bots": 2,   "ram": 128,  "auto_restart": False, "price": 0,    "days": 0},
    "starter":    {"name": "Starter",    "max_bots": 4,   "ram": 256,  "auto_restart": True,  "price": 99,   "days": 30},
    "basic":      {"name": "Basic",      "max_bots": 6,  "ram": 512,  "auto_restart": True,  "price": 199,  "days": 30},
    "pro":        {"name": "Pro",        "max_bots": 8,  "ram": 2048, "auto_restart": True,  "price": 499,  "days": 30},
    "enterprise": {"name": "Enterprise", "max_bots": 10,  "ram": 4096, "auto_restart": True,  "price": 999,  "days": 30},
    "lifetime":   {"name": "Lifetime",   "max_bots": 15, "ram": 8192, "auto_restart": True,  "price": 1999, "days": 36500},
}

PAYMENT_METHODS: Dict[str, Dict[str, Any]] = {
    "phonepe":  {"name": "PhonePe",       "number": "Contact admin for UPI ID", "type": "UPI",                    "tag": "[PP]"},
    "paytm":    {"name": "Paytm",         "number": "Contact admin for UPI ID", "type": "UPI",                    "tag": "[P]"},
    "gpay":     {"name": "Google Pay",    "number": "Contact admin for UPI ID", "type": "UPI",                    "tag": "[GP]"},
    "fampay":   {"name": "FamPay",        "number": "Contact admin for UPI ID", "type": "UPI",                    "tag": "[FP]"},
    "navi":     {"name": "Navi UPI",      "number": "Contact admin for UPI ID", "type": "UPI",                    "tag": "[NU]"},
    "bharatpe": {"name": "BharatPe — Auto Verification", "number": "Contact admin for BharatPe UPI ID", "type": "UPI • Auto Verification", "tag": "[BH]", "auto_verify": True},
    "binance":  {"name": "Binance Pay",   "number": "Contact admin for Binance Pay ID", "type": "USDT (BEP20/TRC20)",    "tag": "[BP]"},
    "bank":     {"name": "Bank Transfer", "number": "Contact admin for bank details", "type": "Indian Bank Transfer", "tag": "[BK]"},
}

UPI_PAYMENT_KEYS = {"phonepe", "paytm", "gpay", "fampay", "navi", "bharatpe"}

def _payment_value(key: str) -> str:
    """Return the admin-configured payment address/details."""
    m = PAYMENT_METHODS.get(key, {})
    return str(get_setting(f"pm_number_{key}", m.get("number", "")) or m.get("number", ""))

def _is_valid_upi_id(value: str) -> bool:
    value = str(value or "").strip()
    return bool(re.fullmatch(r"[A-Za-z0-9._-]{2,128}@[A-Za-z0-9._-]{2,64}", value))

def _upi_qr_path(method: str, plan: Optional[str], amount: Any) -> Optional[str]:
    """Create/cache a standards-compatible UPI QR for a plan payment."""
    if method not in UPI_PAYMENT_KEYS:
        return None
    upi_id = _payment_value(method).strip()
    if not _is_valid_upi_id(upi_id):
        return None
    try:
        amt = float(amount or 0)
        if amt <= 0:
            return None
        amount_text = f"{amt:.2f}".rstrip("0").rstrip(".")
        name = PAYMENT_METHODS[method]["name"]
        plan_name = PLAN_LIMITS.get(plan or "", {}).get("name", "Hosting Plan")
        txn_note = f"{name} - {plan_name}"[:80]
        uri = (
            "upi://pay?"
            f"pa={quote(upi_id, safe='@')}"
            f"&pn={quote(str(get_setting('payment_merchant_name', BRAND)), safe='')}"
            f"&am={quote(amount_text, safe='')}"
            "&cu=INR"
            f"&tn={quote(txn_note, safe='')}"
        )
        qr_dir = DIRS["data"] / "payment_qr"
        qr_dir.mkdir(parents=True, exist_ok=True)
        digest = hashlib.sha256(uri.encode()).hexdigest()[:24]
        path = qr_dir / f"upi_{digest}.png"
        if path.exists() and path.stat().st_size > 0:
            return str(path)
        import qrcode
        img = qrcode.make(uri)
        img.save(path)
        return str(path)
    except Exception as e:
        _log_err("upi_qr", e)
        return None

def _payment_admin_label(method: str) -> str:
    if method == "bharatpe":
        return "BharatPe UPI ID"
    return "UPI ID" if method in UPI_PAYMENT_KEYS else ("Bank Details" if method == "bank" else "Address / ID")

SECRET_ENV_NAMES = {
    "BOT_TOKEN", "OWNER_ID", "ERROR_BOT_TOKEN", "BHARATPE_TOKEN", "BHARATPE_MERCHANT_ID",
    "MONGO_URL", "MONGO_URL_BACKUP",
    "GITHUB_TOKEN", "GITHUB_REPO", "GITHUB_BRANCH", "GITHUB_KEY_REPO",
    "OWNER_IDS", "SESSION_SECRET",
    "DATABASE_URL", "PGDATABASE", "PGHOST", "PGPORT", "PGUSER", "PGPASSWORD",
    "REPLIT_DB_URL", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GROQ_API_KEY",
    "AI_INTEGRATIONS_OPENROUTER_API_KEY", "SESSION_STRING", "SECRET_KEY",
}

ENTRY_NODE = ("index.js", "bot.js", "main.js", "app.js")
ENTRY_PY   = ("bot.py", "main.py", "app.py", "run.py")
LOG_RING   = 200
MAX_LOG_SEND = 50
MAX_UPLOAD_BYTES = 75 * 1024 * 1024  # 75 MB hard cap

# Per-menu photos (URLs). Replaceable; safe placeholders included.
# Each menu has its own banner image. We render these locally with
# Pillow at startup so we don't depend on any external image host
# (placehold.co was returning HTML/redirects on Telegram's fetcher,
# which produced "wrong type of the web page content" and made banners
# invisible). After the first upload Telegram gives us a file_id that
# we cache and reuse for all later sends.
_PHOTO_SPECS: Dict[str, Tuple[str, str, str]] = {
    # key:        (headline,        accent-hex, sub-text)
    "welcome":   ("Wᴇʟᴄᴏᴍᴇ",         "#0F172A", "𓂀KRYON_HOST𓂀"),
    "main":      ("Mᴀɪɴ Mᴇɴᴜ",       "#1E1B4B", "Cʜᴏᴏꜱᴇ Aɴ Oᴘᴛɪᴏɴ"),
    "tunnel":    ("Pᴜʙʟɪᴄ Uʀʟ",      "#0E7490", "Cʟᴏᴜᴅꜰʟᴀʀᴇ Tᴜɴɴᴇʟ"),
    "bots":      ("Yᴏᴜʀ Bᴏᴛꜱ",       "#0E7490", "Mᴀɴᴀɢᴇ & Dᴇᴘʟᴏʏ"),
    "upload":    ("Uᴘʟᴏᴀᴅ & Dᴇᴘʟᴏʏ", "#4338CA", "Sᴇɴᴅ Yᴏᴜʀ Fɪʟᴇꜱ"),
    "plans":     ("Pʟᴀɴꜱ ",         "#B45309", "Pɪᴄᴋ A Tɪᴇʀ"),
    "buy":       ("Bᴜʏ Pʟᴀɴ",        "#065F46", "Cʜᴇᴄᴋᴏᴜᴛ"),
    "pay":       ("Pᴀʏᴍᴇɴᴛ",         "#0E7490", "Sᴇɴᴅ Pʀᴏᴏꜰ"),
    "profile":   ("Pʀᴏꜰɪʟᴇ",         "#1E3A8A", "Yᴏᴜʀ Aᴄᴄᴏᴜɴᴛ"),
    "wallet":    ("Wᴀʟʟᴇᴛ",          "#047857", "Tᴏᴘ-Uᴘ & Bᴀʟᴀɴᴄᴇ"),
    "referral":  ("Rᴇꜰᴇʀʀᴀʟ",        "#9333EA", "Iɴᴠɪᴛᴇ & Eᴀʀɴ"),
    "help":      ("Hᴇʟᴘ",            "#334155", "Hᴏᴡ Iᴛ Wᴏʀᴋꜱ"),
    "support":   ("Sᴜᴘᴘᴏʀᴛ",         "#0F766E", "Tᴀʟᴋ Tᴏ Uꜱ"),
    "ticket":    ("Tɪᴄᴋᴇᴛꜱ",         "#0F766E", "Oᴘᴇɴ A Tɪᴄᴋᴇᴛ"),
    "admin":     ("Aᴅᴍɪɴ Pᴀɴᴇʟ",     "#7C2D12", "Rᴇꜱᴛʀɪᴄᴛᴇᴅ Aʀᴇᴀ"),
    "stats":     ("Sᴛᴀᴛꜱ",           "#14532D", "Lɪᴠᴇ Nᴜᴍʙᴇʀꜱ"),
    "github":    ("Gɪᴛʜᴜʙ Bᴀᴄᴋᴜᴘ",   "#24292E", "Sʏɴᴄ & Rᴇꜱᴛᴏʀᴇ"),
    "security":  ("Sᴇᴄᴜʀɪᴛʏ",        "#991B1B", "Aᴜᴅɪᴛ & Kᴇʏꜱ"),
    "bot":       ("Bᴏᴛ Cᴏɴᴛʀᴏʟ",     "#1F2937", "Sᴛᴀʀᴛ • Sᴛᴏᴘ • Lᴏɢꜱ"),
    "logs":      ("Lɪᴠᴇ Lᴏɢꜱ",       "#0F172A", "Sᴛᴅᴏᴜᴛ / Sᴛᴅᴇʀʀ"),
    "trial":     ("Fʀᴇᴇ Tʀɪᴀʟ",      "#A21CAF", "Tʀʏ Pʀᴇᴍɪᴜᴍ Fʀᴇᴇ"),
    "coupon":    ("Cᴏᴜᴘᴏɴ",          "#B91C1C", "Rᴇᴅᴇᴇᴍ Cᴏᴅᴇ"),
    "gift":      ("Gɪꜰᴛ Pʟᴀɴ",       "#9D174D", "Sᴇɴᴅ Tᴏ A Fʀɪᴇɴᴅ"),
    "broadcast": ("Bʀᴏᴀᴅᴄᴀꜱᴛ",       "#1E40AF", "Rᴇᴀᴄʜ Aʟʟ Uꜱᴇʀꜱ"),
    "maint":         ("Mᴀɪɴᴛᴇɴᴀɴᴄᴇ",      "#451A03", "Rᴇᴀᴅ-Oɴʟʏ Mᴏᴅᴇ"),
    "gh_browser":    ("Gɪᴛʜᴜʙ Bʀᴏᴡꜱᴇʀ",  "#24292E", "Bʀᴏᴡꜱᴇ & Rᴜɴ"),
    "pay_config":    ("Pᴀʏᴍᴇɴᴛ Cᴏɴꜰɪɢ",   "#065F46", "Rᴀᴛᴇꜱ & Mᴇᴛʜᴏᴅꜱ"),
    "bot_config":    ("Bᴏᴛ Cᴏɴꜰɪɢ",        "#1F2937", "Lɪᴍɪᴛꜱ & Sᴀɴᴅʙᴏx"),
    "appearance":    ("Aᴘᴘᴇᴀʀᴀɴᴄᴇ",        "#4338CA", "Tʜᴇᴍᴇ & Sᴛʏʟᴇ"),
    "templates":     ("Tᴇᴍᴘʟᴀᴛᴇꜱ",         "#0E7490", "Mᴇꜱꜱᴀɢᴇ Tᴇᴍᴘʟᴀᴛᴇꜱ"),
    "referral_adm":  ("Rᴇꜰᴇʀʀᴀʟ Sʏꜱ",     "#9333EA", "Iɴᴠɪᴛᴇ & Eᴀʀɴ"),
    "janitor":       ("Jᴀɴɪᴛᴏʀ",            "#451A03", "Aᴜᴛᴏ-Cʟᴇᴀɴᴜᴘ"),
    "webhooks":      ("Wᴇʙʜᴏᴏᴋꜱ",          "#0F766E", "Hᴏᴏᴋ Mᴀɴᴀɢᴇʀ"),
    "features":      ("Fᴇᴀᴛᴜʀᴇ Fʟᴀɢꜱ",    "#B45309", "Tᴏɢɢʟᴇ Fᴜɴᴄᴛɪᴏɴꜱ"),
    "monitor":       ("Lɪᴠᴇ Mᴏɴɪᴛᴏʀ",      "#14532D", "Rᴇᴀʟ-ᴛɪᴍᴇ"),
    "scheduler":     ("Tᴀꜱᴋ Sᴄʜᴇᴅᴜʟᴇʀ",  "#4338CA", "Aᴜᴛᴏ Tᴀꜱᴋꜱ"),
    "leaderboard":   ("Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ",      "#9D174D", "Tᴏᴘ Uꜱᴇʀꜱ"),
    "subscriptions": ("Sᴜʙꜱᴄʀɪᴘᴛɪᴏɴꜱ",   "#1E3A8A", "Rᴇɴᴇᴡᴀʟꜱ"),
    "rate_limits":   ("Rᴀᴛᴇ Lɪᴍɪᴛꜱ",      "#991B1B", "Tʜʀᴏᴛᴛʟɪɴɢ"),
    "import_export": ("Iᴍᴘᴏʀᴛ / Exᴘᴏʀᴛ",  "#334155", "Cᴏɴꜰɪɢ I/O"),
    "bot_controls":  ("Bᴏᴛ Cᴏɴᴛʀᴏʟꜱ",     "#7C2D12", "Pᴇʀ-Bᴏᴛ Oᴘꜱ"),
    "lang_panel":    ("Lᴀɴɢᴜᴀɢᴇꜱ",         "#1E3A8A", "Mᴜʟᴛɪ-Lᴀɴɢ"),
    "rev_goals":     ("Rᴇᴠᴇɴᴜᴇ Gᴏᴀʟꜱ",    "#047857", "Tᴀʀɢᴇᴛ Tʀᴀᴄᴋɪɴɢ"),
    "admin_2fa":     ("Adᴍɪɴ 2FA",          "#991B1B", "Tᴡᴏ-Fᴀᴄᴛᴏʀ Auth"),
    "coupon_plus":   ("Cᴏᴜᴘᴏɴ Mɢʀ",        "#B91C1C", "Aᴅᴠ Cᴏᴜᴘᴏɴꜱ"),
}

# Filled in by _build_local_photos() at startup. Keys are the same
# as _PHOTO_SPECS; values are local file paths (str) that telebot can
# upload directly. After the first send_photo, _PHOTO_FILE_IDS caches
# the returned file_id so subsequent sends reuse it (zero re-upload).
PHOTOS: Dict[str, str] = {}
_PHOTO_FILE_IDS: Dict[str, str] = {}

_PHOTO_ICONS: Dict[str, str] = {
    "welcome":"✦","main":"◈","tunnel":"⬡","bots":"▸","upload":"▴",
    "plans":"★","buy":"◆","pay":"◉","profile":"◈","wallet":"◆",
    "referral":"✦","help":"◇","support":"▫","ticket":"✿","admin":"⚔",
    "stats":"▲","github":"⬡","security":"▣","bot":"▶","logs":"▸",
    "trial":"✶","coupon":"◉","gift":"✦","broadcast":"⚑","maint":"⚙",
}


def _build_local_photos() -> None:
    """Render every banner once into storage/photos/<key>.png. Safe to
    call repeatedly — existing files are reused. Falls back gracefully
    if Pillow or fonts are unavailable (PHOTOS gets a "" placeholder so
    show_menu's text-only branch still renders the menu instead of
    raising KeyError)."""
    # Guarantee all keys exist so PHOTOS["main"] etc. never KeyErrors.
    for k in _PHOTO_SPECS:
        PHOTOS.setdefault(k, "")
    try:
        from PIL import Image, ImageDraw, ImageFont
    except Exception as e:
        print(f"[photos] Pillow unavailable: {e}", file=sys.stderr, flush=True)
        return
    out_dir = DIRS["photos"]
    out_dir.mkdir(parents=True, exist_ok=True)

    # Pick the first usable bold TTF.
    font_candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf",
        "/run/current-system/sw/share/X11/fonts/DejaVuSans-Bold.ttf",
    ]
    font_path: Optional[str] = None
    for fp in font_candidates:
        if Path(fp).exists():
            font_path = fp
            break

    def _hex(c: str) -> Tuple[int, int, int]:
        c = c.lstrip("#")
        return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)

    for key, (text, color, sub) in _PHOTO_SPECS.items():
        # ── Custom admin-uploaded photo takes priority over generated one ──
        # replace_menu_photo() always writes custom_<key>.png as the
        # persistent marker, so this survives restarts and GitHub restores.
        custom_out = out_dir / f"custom_{key}.png"
        if custom_out.exists() and custom_out.stat().st_size > 1024:
            PHOTOS[key] = str(custom_out)
            continue
        out = out_dir / f"{key}.png"
        if out.exists() and out.stat().st_size > 1024:
            PHOTOS[key] = str(out)
            continue
        try:
            r, g, b = _hex(color)
            # Vertical gradient: lighten the top, darken the bottom.
            img = Image.new("RGB", (900, 460), (r, g, b))
            d = ImageDraw.Draw(img)
            for y in range(460):
                t = y / 459.0
                k = 1.0 - 0.55 * t  # darken toward bottom
                d.line(
                    [(0, y), (900, y)],
                    fill=(int(r * k), int(g * k), int(b * k)),
                )
            # Soft accent stripe along the bottom.
            d.rectangle([(0, 430), (900, 460)], fill=(255, 255, 255))
            d.rectangle([(0, 432), (900, 458)], fill=(r, g, b))

            big = (
                ImageFont.truetype(font_path, 78) if font_path
                else ImageFont.load_default()
            )
            small = (
                ImageFont.truetype(font_path, 28) if font_path
                else ImageFont.load_default()
            )

            def _wh(s: str, f) -> Tuple[int, int]:
                try:
                    bb = d.textbbox((0, 0), s, font=f)
                    return bb[2] - bb[0], bb[3] - bb[1]
                except Exception:
                    return d.textsize(s, font=f)  # type: ignore[attr-defined]

            tw, th = _wh(text, big)
            sw, sh = _wh(sub, small)
            cy = (460 - (th + sh + 18)) // 2
            # Drop-shadow for the headline.
            d.text(((900 - tw) // 2 + 3, cy + 3), text, fill=(0, 0, 0), font=big)
            d.text(((900 - tw) // 2, cy), text, fill=(255, 255, 255), font=big)
            d.text(((900 - sw) // 2, cy + th + 18), sub,
                   fill=(230, 230, 230), font=small)

            img.save(out, "PNG", optimize=True)
            PHOTOS[key] = str(out)
        except Exception as e:
            print(f"[photos] {key} failed: {e}", file=sys.stderr, flush=True)


_build_local_photos()


def _resolve_photo(ref: str):
    """Convert a PHOTOS[...] entry into something telebot's send_photo
    can accept. Order: cached file_id → local file handle → URL."""
    fid = _PHOTO_FILE_IDS.get(ref)
    if fid:
        return fid
    if isinstance(ref, str) and ref.startswith(("http://", "https://")):
        return ref
    try:
        return open(ref, "rb")
    except Exception:
        return ref


def _remember_file_id(ref: str, msg) -> None:
    """Stash the file_id Telegram returned so the next send is a single
    cheap reference instead of a full upload."""
    try:
        if msg and getattr(msg, "photo", None):
            _PHOTO_FILE_IDS[ref] = msg.photo[-1].file_id
    except Exception:
        pass


# ═════════════════════════════════════════════════════════════════
#  2. STYLED TEXT HELPERS  (small-caps + serif maps)
# ═════════════════════════════════════════════════════════════════

_SC_MAP = str.maketrans(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘQʀꜱᴛᴜᴠᴡxʏᴢ",
)


def sc(text: Any) -> str:
    """Render text in Unicode small-caps."""
    return str(text).translate(_SC_MAP)


def divider(width: int = 22, ch: str = "\u2501") -> str:
    return ch * width


def bullet(label: str, value: Any, glyph: str = G["bullet"]) -> str:
    return f"{glyph}  <b>{esc(label)}</b>: <code>{esc(value)}</code>"


# ═════════════════════════════════════════════════════════════════
#  3. JSON DB  (atomic writes, RLock-guarded)
# ═════════════════════════════════════════════════════════════════

_db_lock = threading.RLock()
_ATOMIC_WRITE_LOCK = threading.RLock()


def _atomic_write(path: Path, data: Any) -> None:
    """Crash-safe, thread-safe JSON write.

    The old implementation used one shared ``*.tmp`` filename. Two TeleBot
    worker threads could overwrite/unlink that same temp file, producing the
    exact ``panel_db.json.tmp -> panel_db.json`` FileNotFoundError seen in the
    production log. A unique temp file plus a process-wide lock eliminates that
    race. A small ``.bak`` is also kept for recovery from interrupted writes.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, indent=2, default=str, ensure_ascii=False).encode("utf-8")
    with _ATOMIC_WRITE_LOCK:
        tmp = None
        try:
            fd, tmp_name = tempfile.mkstemp(
                prefix=f".{path.name}.", suffix=f".{os.getpid()}.{threading.get_ident()}.tmp",
                dir=str(path.parent),
            )
            tmp = Path(tmp_name)
            with os.fdopen(fd, "wb") as fh:
                fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())
            if path.exists():
                try:
                    shutil.copy2(str(path), str(path.with_suffix(path.suffix + ".bak")))
                except Exception:
                    pass
            os.replace(str(tmp), str(path))
            try:
                dfd = os.open(str(path.parent), os.O_RDONLY)
                try:
                    os.fsync(dfd)
                finally:
                    os.close(dfd)
            except Exception:
                pass
        finally:
            if tmp is not None:
                try:
                    tmp.unlink(missing_ok=True)
                except Exception:
                    pass


def _load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        # Recover from the last known-good sidecar before giving up.
        bak = path.with_suffix(path.suffix + ".bak")
        try:
            if bak.exists():
                recovered = json.loads(bak.read_text(encoding="utf-8"))
                if recovered is not None:
                    print(f"[persistence] recovered {path.name} from backup", flush=True)
                    return recovered
        except Exception:
            pass
        try:
            path.replace(path.with_suffix(path.suffix + ".corrupt"))
        except Exception:
            pass
        return default


# ── in-memory cache for db / settings (mtime-invalidated) ─────────
# JSON disk reads were happening on EVERY db_load() call (3-5 times per
# button click). With many users this turns the bot into molasses.
# We cache the parsed dict and only re-read from disk when the file's
# mtime changes (i.e. someone wrote to it). Cache entries are
# `(mtime, data)`. Writes bump mtime so other readers refresh.
_DB_CACHE: Dict[str, Tuple[float, Any]] = {}


def _cached_load_ro(path: Path, default: Any) -> Any:
    """Return the cached parsed JSON at `path` WITHOUT a defensive
    copy. Caller MUST NOT mutate the result. Use for hot read-only
    paths (get_setting, is_admin, find_bot, …) — this avoids the
    enormous deepcopy cost on every callback."""
    key = str(path)
    try:
        mtime = path.stat().st_mtime
    except FileNotFoundError:
        mtime = 0.0
    cached = _DB_CACHE.get(key)
    if cached and cached[0] == mtime:
        return cached[1]
    d = _load_json(path, default)
    _DB_CACHE[key] = (mtime, d)
    return d


def _cached_load(path: Path, default: Any) -> Any:
    """Defensive variant: returns a deep copy so callers can mutate
    safely without poisoning the cache. ~5-10× faster than the old
    json round-trip."""
    return copy.deepcopy(_cached_load_ro(path, default))


def _cache_invalidate(path: Path) -> None:
    _DB_CACHE.pop(str(path), None)


# Default skeleton applied to a freshly-loaded `user_data.json`. Kept
# at module scope so we can install it once into the cached object
# (`db_load_ro`) and skip the per-call setdefault loop entirely.
_DB_DEFAULT_KEYS: Tuple[Tuple[str, Any], ...] = (
    ("users", {}),
    ("bots", {}),
    ("payments", []),
    ("admins", {}),
    ("audit", []),
    ("coupons", {}),
    ("tickets", {}),
    ("scheduled_broadcasts", []),
    ("notes", {}),
    ("rate_violations", {}),
    ("scan_log", []),        # security scan history for admin panel
)


# ─────────────────────────────────────────────────────────────────────────────
# SECRET VAULT (at-rest protection for child bot ENV)
# ─────────────────────────────────────────────────────────────────────────────
# Child bot credentials must never be written as plaintext JSON.  The vault
# key is derived from the HOST BOT token and is never stored in the database
# or GitHub backup.  This is intentionally separate from the per-file Fernet
# keys used for uploaded source files.
_VAULT_PREFIX = "enc:v1:"

def _vault_fernet() -> Fernet:
    material = ("KRYON-HOST-ENV-VAULT-v1|" + TOKEN).encode("utf-8")
    digest = hashlib.sha256(material).digest()
    return Fernet(base64.urlsafe_b64encode(digest))

def _vault_encrypt(value: Any) -> str:
    raw = str(value if value is not None else "").encode("utf-8")
    return _VAULT_PREFIX + _vault_fernet().encrypt(raw).decode("ascii")

def _vault_decrypt(value: Any) -> str:
    text = "" if value is None else str(value)
    if not text.startswith(_VAULT_PREFIX):
        return text
    try:
        raw = _vault_fernet().decrypt(text[len(_VAULT_PREFIX):].encode("ascii"))
        return raw.decode("utf-8")
    except Exception:
        # Keep an unreadable value masked in memory rather than exposing or
        # guessing at a credential. The owner can replace it from Env Editor.
        return ""

def _decrypt_bot_envs_in_place(d: Dict[str, Any]) -> Dict[str, Any]:
    for b in (d.get("bots") or {}).values():
        env = b.get("env")
        if not isinstance(env, dict):
            b["env"] = {}
            continue
        for k, v in list(env.items()):
            env[str(k).upper()] = _vault_decrypt(v)
            if str(k).upper() != k:
                env.pop(k, None)
    return d

def _encrypt_db_copy(d: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(d)
    for b in (out.get("bots") or {}).values():
        env = b.get("env")
        if isinstance(env, dict):
            protected_env = {}
            for k, v in env.items():
                sk = str(k).upper()
                sv = str(v) if v is not None else ""
                if sv.startswith(_VAULT_PREFIX):
                    protected_env[sk] = sv
                else:
                    protected_env[sk] = _vault_encrypt(sv)
            b["env"] = protected_env
    return out

def _backup_db_bytes() -> bytes:
    # Always build the backup from the in-memory/decrypted model and then
    # encrypt child ENV values before serializing. This also protects legacy
    # databases that pre-date the vault.
    protected = _encrypt_db_copy(db_load())
    return json.dumps(protected, ensure_ascii=False, indent=2).encode("utf-8")

def _is_secret_setting_key(key: str) -> bool:
    lk = str(key or "").lower()
    return any(w in lk for w in ("token", "password", "secret", "api_key", "private_key"))

def _decrypt_settings_in_place(d: Dict[str, Any]) -> Dict[str, Any]:
    for k, v in list(d.items()):
        if _is_secret_setting_key(k) and isinstance(v, str):
            d[k] = _vault_decrypt(v)
    return d

def _encrypt_settings_copy(d: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(d)
    for k, v in list(out.items()):
        if _is_secret_setting_key(k) and isinstance(v, str):
            out[k] = v if v.startswith(_VAULT_PREFIX) else _vault_encrypt(v)
    return out

def _safe_settings_for_backup(settings: Dict[str, Any]) -> Dict[str, Any]:
    out = {}
    secret_words = ("token", "password", "secret", "api_key", "private_key")
    for k, v in (settings or {}).items():
        lk = str(k).lower()
        if any(w in lk for w in secret_words):
            continue
        out[k] = v
    return out

def _ensure_db_defaults(d: Dict[str, Any]) -> Dict[str, Any]:
    for k, v in _DB_DEFAULT_KEYS:
        if k not in d:
            d[k] = copy.deepcopy(v) if isinstance(v, (dict, list)) else v
    return _decrypt_bot_envs_in_place(d)

def db_load() -> Dict[str, Any]:
    """Load a MUTABLE copy of the user database. Use when you intend
    to mutate and `db_save()` back. For pure reads, use db_load_ro()
    — much faster."""
    with _db_lock:
        d = _cached_load(DB_FILE, {})
    return _ensure_db_defaults(d)


def db_load_ro() -> Dict[str, Any]:
    """Read-only DB access. NEVER mutate the result — it's the cached
    object itself. Mutation will silently corrupt every other reader
    sharing the cache."""
    with _db_lock:
        d = _cached_load_ro(DB_FILE, {})
    return _ensure_db_defaults(d)


def db_save(d: Dict[str, Any]) -> None:
    with _db_lock:
        # Encrypt child ENV values on disk; keep the caller's in-memory copy
        # unchanged so runtime code can use normal strings.
        protected = _encrypt_db_copy(d)
        _atomic_write(DB_FILE, protected)
        _cache_invalidate(DB_FILE)
        # Durable remote mirror for redeploy/rebuild recovery.
        _mongo_put("db", protected)


def settings_load() -> Dict[str, Any]:
    with _db_lock:
        d = _cached_load(SETTINGS_FILE, {})
    return _decrypt_settings_in_place(d)


def settings_load_ro() -> Dict[str, Any]:
    """Read-only fast path — DO NOT mutate."""
    with _db_lock:
        d = _cached_load_ro(SETTINGS_FILE, {})
    return _decrypt_settings_in_place(d)


def settings_save(d: Dict[str, Any]) -> None:
    with _db_lock:
        protected = _encrypt_settings_copy(d)
        _atomic_write(SETTINGS_FILE, protected)
        _cache_invalidate(SETTINGS_FILE)
        _mongo_put("settings", protected)


def _secure_storage_migrate() -> None:
    """One-time migration for legacy plaintext secrets on local disk."""
    try:
        if DB_FILE.exists():
            d = db_load()
            db_save(d)  # encrypts every child ENV value on disk
        if SETTINGS_FILE.exists():
            d = settings_load()
            settings_save(d)  # encrypts secret setting values on disk
    except Exception as e:
        print(f"[security] secret-storage migration warning: {e}", file=sys.stderr)


def get_setting(key: str, default: Any = None) -> Any:
    # Hot path. Use the no-copy reader because we only `.get()` —
    # we never mutate the dict.
    return settings_load_ro().get(key, default)


def set_setting(key: str, value: Any) -> None:
    s = settings_load()
    s[key] = value
    settings_save(s)


def cache_clear_all() -> None:
    """Drop every cached load so the next read re-parses from disk.
    Used by the Settings → Reload button after manual file edits."""
    with _db_lock:
        _DB_CACHE.clear()


# ═════════════════════════════════════════════════════════════════
#  4. UTILITY  HELPERS
# ═════════════════════════════════════════════════════════════════

def esc(s: Any = "") -> str:
    return (
        str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    )


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def ts_iso() -> str:
    return now_utc().isoformat()


def safe_name(s: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9_-]+", "_", s or "").strip("_")
    return (s or "bot")[:48]


def fmt_bytes(n: float) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def fmt_dur(ms: int) -> str:
    if ms is None or ms < 0:
        return "—"
    s = ms // 1000
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    parts: List[str] = []
    if d:
        parts.append(f"{d}d")
    if h:
        parts.append(f"{h}h")
    if m:
        parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


def fmt_ts(iso: Optional[str]) -> str:
    if not iso:
        return "—"
    try:
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except Exception:
        return str(iso)


def rmrf(p: str | Path) -> None:
    try:
        shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


def rand_token(n: int = 8) -> str:
    return "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(n))


def safe_path_join(root: Path, *parts: str) -> Path:
    """Path-traversal safe join. Raises ValueError if escape detected."""
    final = (root / Path(*parts)).resolve()
    rootp = root.resolve()
    if rootp not in final.parents and final != rootp:
        raise ValueError("path traversal detected")
    return final


def is_owner(uid: int) -> bool:
    return OWNER_ID > 0 and int(uid) == OWNER_ID


def is_admin(uid: int) -> bool:
    # Additional admins are managed from the Admin Panel and persisted in the DB.
    return is_owner(uid) or str(uid) in db_load_ro().get("admins", {})


def admin_role(uid: int) -> str:
    if is_owner(uid):
        return "owner"
    return db_load_ro().get("admins", {}).get(str(uid), {}).get("role", "")


def admin_can(uid: int, action: str) -> bool:
    """
    Permission matrix.
      owner          → everything
      full-access    → everything except adding admins
      manage-users   → ban / give-plan / view users / approve payments / reply tickets
      view-only      → view stats only
    """
    role = admin_role(uid)
    if role == "owner":
        return True
    if role == "full-access":
        return action != "manage_admins"
    if role == "manage-users":
        return action in {
            "view_stats", "view_users", "find_user", "ban_user", "give_plan",
            "approve_payment", "reply_ticket", "broadcast_view", "user_note",
        }
    if role == "view-only":
        return action in {"view_stats", "view_users", "find_user"}
    return False


# ═════════════════════════════════════════════════════════════════
#  5. AUDIT LOG  (admin actions)
# ═════════════════════════════════════════════════════════════════

def audit(uid: int, action: str, detail: str = "") -> None:
    line = f"[{ts_iso()}] uid={uid} action={action} {detail}\n"
    try:
        with AUDIT_FILE.open("a", encoding="utf-8") as f:
            f.write(line)
    except Exception:
        pass
    with _db_lock:
        d = db_load()
        d["audit"].append({"ts": ts_iso(), "uid": uid, "action": action, "detail": detail})
        d["audit"] = d["audit"][-500:]
        db_save(d)


# ═════════════════════════════════════════════════════════════════
#  6. ENCRYPTION   +   GITHUB-BACKED KEY RING
# ═════════════════════════════════════════════════════════════════
#
#  Every uploaded user file is encrypted with a unique Fernet key.
#  Keys live ONLY in a private GitHub key-repo (or a memory cache
#  if GitHub keyring is not configured — see warn() below).
#  Local disk only ever stores ciphertext.
# ═════════════════════════════════════════════════════════════════

class KeyRing:
    """Encryption key store. Tries GitHub first, then in-memory cache."""

    def __init__(self) -> None:
        self._mem: Dict[str, bytes] = {}
        self._lock = threading.Lock()

    # ── GitHub config ────────────────────────────────────────────
    @staticmethod
    def _gh_token() -> str:
        return (_HOST_SECRET_ENV.get("GITHUB_TOKEN") or get_setting("github_token", "") or "").strip()

    @staticmethod
    def _gh_key_repo() -> str:
        # Prefer a separate repo for keys; falls back to backup repo
        return (
            _HOST_SECRET_ENV.get("GITHUB_KEY_REPO")
            or get_setting("github_key_repo", "")
            or _HOST_SECRET_ENV.get("GITHUB_REPO")
            or get_setting("github_repo", "")
            or ""
        ).strip()

    def gh_enabled(self) -> bool:
        return bool(self._gh_token() and "/" in self._gh_key_repo())

    def _gh_request(self, method: str, path: str, **kw) -> Optional[requests.Response]:
        if not self.gh_enabled():
            return None
        url = f"https://api.github.com/repos/{self._gh_key_repo()}/{path.lstrip('/')}"
        h = kw.pop("headers", {}) or {}
        h.setdefault("Authorization", f"token {self._gh_token()}")
        h.setdefault("Accept", "application/vnd.github+json")
        h.setdefault("User-Agent", "kryon-host/1.0")
        try:
            return requests.request(method, url, headers=h, timeout=30, **kw)
        except Exception:
            return None

    # ── public API ───────────────────────────────────────────────
    def new_key(self) -> bytes:
        return Fernet.generate_key()

    def store(self, key_id: str, key: bytes, meta: Dict[str, Any]) -> bool:
        """Push key+meta to GitHub. Memory-cache as fallback only."""
        with self._lock:
            self._mem[key_id] = key

        # Never store raw file-encryption keys in GitHub. The backup repo may
        # be private, but repository access must not be enough to decrypt
        # uploaded source. The key itself is wrapped with the host-only vault.
        body = {"key": _vault_encrypt(key.decode()), "meta": meta, "ts": ts_iso()}
        payload = json.dumps(body, indent=2).encode()
        # Mongo is the durable key source for bot files.  The key is wrapped
        # with the host-only vault before it ever leaves this process.
        try:
            mdb = _mongo_db()
            if mdb is not None:
                mdb.bot_file_keys.replace_one(
                    {"_id": str(key_id)},
                    {"_id": str(key_id), "key": _vault_encrypt(key.decode()),
                     "meta": copy.deepcopy(meta), "updated_at": time.time()},
                    upsert=True,
                )
        except Exception as e:
            print(f"[persistence] Mongo key write failed ({key_id}): {e}", flush=True)

        if not self.gh_enabled():
            # memory only — write a tiny encrypted local cache so a panel
            # restart does not lose access. The cache is encrypted with a
            # key derived from BOT_TOKEN+OWNER_ID, never plain text.
            self._cache_local(key_id, key)
            return True

        gh_path = f"keys/{key_id}.json"
        sha: Optional[str] = None
        r = self._gh_request("GET", f"contents/{gh_path}")
        if r is not None and r.status_code == 200:
            try:
                sha = r.json().get("sha")
            except Exception:
                pass
        put_body: Dict[str, Any] = {
            "message": f"key {key_id} stored {ts_iso()}",
            "content": base64.b64encode(payload).decode(),
        }
        if sha:
            put_body["sha"] = sha
        r2 = self._gh_request("PUT", f"contents/{gh_path}", json=put_body)
        ok = r2 is not None and r2.status_code in (200, 201)
        if not ok:
            # last-ditch local encrypted cache so we don't lose access
            self._cache_local(key_id, key)
        return ok

    def fetch(self, key_id: str) -> Optional[bytes]:
        with self._lock:
            cached = self._mem.get(key_id)
        if cached:
            return cached
        if self.gh_enabled():
            r = self._gh_request("GET", f"contents/keys/{key_id}.json")
            if r is not None and r.status_code == 200:
                try:
                    raw = base64.b64decode(r.json()["content"])
                    blob = json.loads(raw.decode())
                    stored_key = blob["key"]
                    if isinstance(stored_key, str) and stored_key.startswith(_VAULT_PREFIX):
                        key = _vault_decrypt(stored_key).encode()
                        if not key:
                            raise ValueError("vault key unavailable")
                    else:
                        # Legacy keyring entries may contain plaintext keys;
                        # accept them for migration, but new writes are wrapped.
                        key = str(stored_key).encode()
                    with self._lock:
                        self._mem[key_id] = key
                    return key
                except Exception:
                    pass
        # Durable Mongo fallback.  This is required when the hosting
        # container was rebuilt and the local keycache disappeared.
        try:
            mdb = _mongo_db()
            if mdb is not None:
                doc = mdb.bot_file_keys.find_one({"_id": str(key_id)})
                if doc and doc.get("key"):
                    key = _vault_decrypt(doc.get("key"))
                    if key:
                        raw_key = key.encode()
                        with self._lock:
                            self._mem[key_id] = raw_key
                        return raw_key
        except Exception as e:
            print(f"[persistence] Mongo key read failed ({key_id}): {e}", flush=True)
        # local encrypted cache fallback
        return self._uncache_local(key_id)

    def wipe(self, key_id: str) -> None:
        with self._lock:
            self._mem.pop(key_id, None)

    def remove(self, key_id: str) -> None:
        """Delete key everywhere."""
        self.wipe(key_id)
        kp = DIRS["data"] / "keycache" / f"{key_id}.bin"
        try:
            if kp.exists():
                kp.unlink()
        except Exception:
            pass
        if self.gh_enabled():
            r = self._gh_request("GET", f"contents/keys/{key_id}.json")
            if r is not None and r.status_code == 200:
                try:
                    sha = r.json().get("sha")
                    if sha:
                        self._gh_request(
                            "DELETE",
                            f"contents/keys/{key_id}.json",
                            json={"message": f"remove {key_id}", "sha": sha},
                        )
                except Exception:
                    pass

    # ── fallback local encrypted cache ────────────────────────────
    def _local_master(self) -> bytes:
        material = f"{TOKEN}|{OWNER_ID}".encode()
        digest = hashlib.sha256(material).digest()
        return base64.urlsafe_b64encode(digest)

    def _cache_local(self, key_id: str, key: bytes) -> None:
        try:
            d = DIRS["data"] / "keycache"
            d.mkdir(parents=True, exist_ok=True)
            f = Fernet(self._local_master())
            (d / f"{key_id}.bin").write_bytes(f.encrypt(key))
        except Exception:
            pass

    def _uncache_local(self, key_id: str) -> Optional[bytes]:
        p = DIRS["data"] / "keycache" / f"{key_id}.bin"
        if not p.exists():
            return None
        try:
            f = Fernet(self._local_master())
            key = f.decrypt(p.read_bytes())
            with self._lock:
                self._mem[key_id] = key
            return key
        except Exception:
            return None


KEYRING = KeyRing()


def encrypt_file(plain: bytes) -> Tuple[str, bytes, bytes]:
    """
    Returns (key_id, key, ciphertext).
    Caller is responsible for storing key via KEYRING.store(key_id, key, meta).
    """
    key = KEYRING.new_key()
    f = Fernet(key)
    cipher = f.encrypt(plain)
    key_id = secrets.token_urlsafe(16)
    return key_id, key, cipher


def decrypt_with(key: bytes, cipher: bytes) -> bytes:
    return Fernet(key).decrypt(cipher)


def write_encrypted(path: Path, key: bytes, plain: bytes) -> None:
    f = Fernet(key)
    path.write_bytes(f.encrypt(plain))


def read_encrypted(path: Path, key: bytes) -> bytes:
    return Fernet(key).decrypt(path.read_bytes())


# ═════════════════════════════════════════════════════════════════
#  7. RATE LIMITER  +  SUSPICIOUS-ACTIVITY  WATCHDOG
# ═════════════════════════════════════════════════════════════════

class RateLimiter:
    def __init__(self, max_actions: int = 30, window_s: int = 60) -> None:
        self.max = max_actions
        self.window = window_s
        self._bucket: Dict[int, Deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, uid: int) -> bool:
        now = time.time()
        with self._lock:
            q = self._bucket[uid]
            while q and now - q[0] > self.window:
                q.popleft()
            if len(q) >= self.max:
                return False
            q.append(now)
            return True

    def hits(self, uid: int) -> int:
        with self._lock:
            return len(self._bucket.get(uid, []))


RATE = RateLimiter(max_actions=40, window_s=60)
UPLOAD_RATE = RateLimiter(max_actions=8, window_s=300)


def maybe_auto_ban(uid: int, reason: str) -> None:
    """If a user repeatedly trips rate limits, auto-ban them and notify owner."""
    d = db_load()
    rv = d.get("rate_violations", {})
    rv[str(uid)] = int(rv.get(str(uid), 0)) + 1
    d["rate_violations"] = rv
    db_save(d)
    if rv[str(uid)] >= 5:
        u = d["users"].get(str(uid))
        if u and not u.get("banned"):
            u["banned"] = True
            u["ban_reason"] = f"auto: {reason}"
            db_save(d)
            audit(0, "auto_ban", f"uid={uid} reason={reason}")
            notify_owner(
                f"<b>{G['warn']} sᴜsᴘɪᴄɪᴏᴜs ᴀᴄᴛɪᴠɪᴛʏ</b>\n\n"
                f"User <code>{uid}</code> auto-banned ({esc(reason)})."
            )


# ═════════════════════════════════════════════════════════════════
#  8. BOT INSTANCE  +  KEEP-ALIVE  WEB SERVER
# ═════════════════════════════════════════════════════════════════

bot = telebot.TeleBot(TOKEN, parse_mode="HTML", threaded=True, num_threads=8)

# ───────────────────────────────────────────────────────────────────
# UI style wrapper — every outgoing message/caption is rendered as a
# bold blockquote so the panel feels uniform. Only applies when the
# parse mode is HTML (the default for this bot).
# ───────────────────────────────────────────────────────────────────
_QUOTE_OPEN  = "<blockquote><b>"
_QUOTE_CLOSE = "</b></blockquote>"

def _is_html_mode(pm) -> bool:
    if pm is None:
        return True  # bot default is HTML
    try:
        return str(pm).strip().lower() == "html"
    except Exception:
        return False

def _redact_sensitive_text(text: Any) -> Any:
    """Redact known credentials before text leaves the host process.

    This is defense-in-depth: normal UI code should already avoid sending
    secret values, but this guard prevents accidental leaks through owner
    notifications, errors, AI scan prompts, or future UI changes.
    """
    if text is None:
        return text
    s = str(text)
    if not s:
        return s

    # Exact values currently held by the host and child-bot ENV vault.
    secrets = set()
    for v in (_HOST_SECRET_ENV or {}).values():
        if isinstance(v, str) and len(v) >= 6:
            secrets.add(v)
    try:
        for b in db_load_ro().get("bots", {}).values():
            for v in (b.get("env") or {}).values():
                if isinstance(v, str) and len(v) >= 6:
                    secrets.add(v)
    except Exception:
        pass
    for secret in sorted(secrets, key=len, reverse=True):
        if secret:
            s = s.replace(secret, "[REDACTED]")

    # Also redact credential-looking assignments even if they are not in the
    # current vault (e.g. a hard-coded credential inside uploaded source).
    s = re.sub(
        r"(?is)(\b(?:BOT_TOKEN|TELEGRAM_BOT_TOKEN|MAIN_BOT_TOKEN|API_KEY|API_HASH|[A-Z][A-Z0-9_]*(?:TOKEN|SECRET|PASSWORD|PRIVATE_KEY))\s*[=:]\s*)([^\s<\n,;]+)",
        r"\1[REDACTED]", s,
    )
    s = re.sub(r"(?i)(\bBearer\s+)[A-Za-z0-9._~+/=-]+", r"\1[REDACTED]", s)
    return s


def _wrap_quote_bold(text):
    if text is None:
        return text
    s = str(text)
    if not s.strip():
        return s
    if s.startswith(_QUOTE_OPEN):
        return s
    return f"{_QUOTE_OPEN}{s}{_QUOTE_CLOSE}"

def _patch_bot_styling(b):
    orig_send         = b.send_message
    orig_reply        = b.reply_to
    orig_edit_text    = b.edit_message_text
    orig_edit_caption = b.edit_message_caption
    orig_send_photo   = b.send_photo
    orig_send_video   = b.send_video
    orig_send_doc     = b.send_document
    orig_send_anim    = getattr(b, "send_animation", None)

    def send_message(chat_id, text, *args, **kwargs):
        text = _redact_sensitive_text(text)
        if _is_html_mode(kwargs.get("parse_mode")):
            text = _wrap_quote_bold(text)
        return orig_send(chat_id, text, *args, **kwargs)

    def reply_to(message, text, *args, **kwargs):
        text = _redact_sensitive_text(text)
        if _is_html_mode(kwargs.get("parse_mode")):
            text = _wrap_quote_bold(text)
        return orig_reply(message, text, *args, **kwargs)

    def edit_message_text(text, *args, **kwargs):
        text = _redact_sensitive_text(text)
        if _is_html_mode(kwargs.get("parse_mode")):
            text = _wrap_quote_bold(text)
        return orig_edit_text(text, *args, **kwargs)

    def edit_message_caption(*args, **kwargs):
        if "caption" in kwargs:
            kwargs["caption"] = _redact_sensitive_text(kwargs.get("caption"))
        if _is_html_mode(kwargs.get("parse_mode")):
            if "caption" in kwargs:
                kwargs["caption"] = _wrap_quote_bold(kwargs.get("caption"))
        return orig_edit_caption(*args, **kwargs)

    def send_photo(chat_id, photo, *args, **kwargs):
        if kwargs.get("caption"):
            kwargs["caption"] = _redact_sensitive_text(kwargs["caption"])
        if _is_html_mode(kwargs.get("parse_mode")) and kwargs.get("caption"):
            kwargs["caption"] = _wrap_quote_bold(kwargs["caption"])
        return orig_send_photo(chat_id, photo, *args, **kwargs)

    def send_video(chat_id, video, *args, **kwargs):
        if kwargs.get("caption"):
            kwargs["caption"] = _redact_sensitive_text(kwargs["caption"])
        if _is_html_mode(kwargs.get("parse_mode")) and kwargs.get("caption"):
            kwargs["caption"] = _wrap_quote_bold(kwargs["caption"])
        return orig_send_video(chat_id, video, *args, **kwargs)

    def send_document(chat_id, document, *args, **kwargs):
        if kwargs.get("caption"):
            kwargs["caption"] = _redact_sensitive_text(kwargs["caption"])
        if _is_html_mode(kwargs.get("parse_mode")) and kwargs.get("caption"):
            kwargs["caption"] = _wrap_quote_bold(kwargs["caption"])
        return orig_send_doc(chat_id, document, *args, **kwargs)

    b.send_message         = send_message
    b.reply_to             = reply_to
    b.edit_message_text    = edit_message_text
    b.edit_message_caption = edit_message_caption
    b.send_photo           = send_photo
    b.send_video           = send_video
    b.send_document        = send_document
    if orig_send_anim is not None:
        def send_animation(chat_id, animation, *args, **kwargs):
            if kwargs.get("caption"):
                kwargs["caption"] = _redact_sensitive_text(kwargs["caption"])
            if _is_html_mode(kwargs.get("parse_mode")) and kwargs.get("caption"):
                kwargs["caption"] = _wrap_quote_bold(kwargs["caption"])
            return orig_send_anim(chat_id, animation, *args, **kwargs)
        b.send_animation = send_animation

_patch_bot_styling(bot)
USER_STATES: Dict[int, Dict[str, Any]] = {}
START_TS = int(time.time() * 1000)

# ── Flask keep-alive ─────────────────────────────────────────────
_ka = Flask(__name__)


@_ka.route("/")
def _ka_root() -> Any:  # noqa: D401
    return jsonify(
        {
            "ok": True,
            "brand": BRAND_TAG,
            "uptime_ms": int(time.time() * 1000) - START_TS,
            "running_bots": len(RUNNING) if "RUNNING" in globals() else 0,
        }
    )


@_ka.route("/health")
def _ka_health() -> Any:
    return jsonify({"status": "alive"})


def _start_keepalive() -> None:
    def _run() -> None:
        try:
            _ka.run(host="0.0.0.0", port=KEEPALIVE_PORT, debug=False, use_reloader=False)
        except Exception as e:
            print(f"[keepalive] {e}")
    threading.Thread(target=_run, daemon=True).start()


# ═════════════════════════════════════════════════════════════════
#  9. UI HELPERS  —  show_menu (edit, never spam) + keyboards
# ═════════════════════════════════════════════════════════════════

# ── PATCHED: ghost-delete fix ─────────────────────────────────────
# Logs send/edit failures to stderr instead of swallowing them.
def _log_err(where: str, exc: BaseException) -> None:
    try:
        print(f"[show_menu:{where}] {type(exc).__name__}: {exc}",
              file=sys.stderr, flush=True)
    except Exception:
        pass


# HTML-safe truncation: never cut a message in the middle of an open tag.
_TAG_RE = re.compile(r"<(/?)([a-zA-Z][a-zA-Z0-9]*)(\s[^>]*)?>")

def _html_safe_truncate(s: str, limit: int = 1024) -> str:
    if len(s) <= limit:
        return s
    cut = s[: limit - 1]
    last_lt = cut.rfind("<")
    last_gt = cut.rfind(">")
    if last_lt > last_gt:
        cut = cut[:last_lt]
    stack: List[str] = []
    for m in _TAG_RE.finditer(cut):
        closing, name = m.group(1), m.group(2).lower()
        if closing:
            if stack and stack[-1] == name:
                stack.pop()
        else:
            stack.append(name)
    closes = "".join(f"</{t}>" for t in reversed(stack))
    return cut + "…" + closes


def show_menu(
    chat_id: int,
    photo_url: str,
    caption: str,
    kb: types.InlineKeyboardMarkup,
    call: Optional[types.CallbackQuery] = None,
) -> None:
    """Send/edit a photo + caption + buttons. Tries to edit when from a
    callback. NEVER deletes the old message until the replacement has
    been confirmed sent — prevents 'ghost delete' bug."""
    cap = _html_safe_truncate(caption, 1024)

    # Any in-flight loading animation on this message is now stale —
    # we are about to overwrite the message with the real menu.
    if call and call.message:
        _cancel_loading(call.message.chat.id, call.message.message_id)

    # ── 1. Try in-place edits when the previous message is a photo ──
    if call and call.message and call.message.content_type == "photo":
        msg = call.message

        # 1a. Try to swap photo + caption together.
        # Use a cached file_id if we have one; otherwise resolve the
        # ref through `_resolve_photo` so local file paths are uploaded
        # as a real file handle instead of being mistaken for a URL
        # (which causes Telegram's "URL host is empty" error).
        cached_fid = _PHOTO_FILE_IDS.get(photo_url)
        media_ref = cached_fid if cached_fid else _resolve_photo(photo_url)
        try:
            bot.edit_message_media(
                media=types.InputMediaPhoto(media_ref, caption=cap, parse_mode="HTML"),
                chat_id=chat_id,
                message_id=msg.message_id,
                reply_markup=kb,
            )
            return
        except ApiTelegramException as e:
            if "message is not modified" in str(e).lower():
                return
            _log_err("edit_message_media", e)
        except Exception as e:
            _log_err("edit_message_media", e)
        finally:
            try:
                if hasattr(media_ref, "close"):
                    media_ref.close()
            except Exception:
                pass

        # 1b. Photo swap failed — keep existing photo, change only caption.
        # This is the safe path when Telegram can't fetch the new photo URL.
        try:
            bot.edit_message_caption(
                cap,
                chat_id=chat_id,
                message_id=msg.message_id,
                reply_markup=kb,
                parse_mode="HTML",
            )
            return
        except ApiTelegramException as e:
            if "message is not modified" in str(e).lower():
                return
            _log_err("edit_message_caption", e)
        except Exception as e:
            _log_err("edit_message_caption", e)

        # 1c. HTML parse blew up — retry caption WITHOUT parse_mode.
        try:
            plain = re.sub(r"<[^>]+>", "", cap)
            bot.edit_message_caption(
                plain,
                chat_id=chat_id,
                message_id=msg.message_id,
                reply_markup=kb,
            )
            return
        except Exception as e:
            _log_err("edit_message_caption(plain)", e)

    # ── 2. Send a brand-new message FIRST, then delete the old one. ──
    new_msg_id: Optional[int] = None

    try:
        m = bot.send_photo(chat_id, _resolve_photo(photo_url), caption=cap,
                           parse_mode="HTML", reply_markup=kb)
        new_msg_id = m.message_id
        _remember_file_id(photo_url, m)
    except Exception as e:
        _log_err("send_photo", e)

    if new_msg_id is None:
        try:
            m = bot.send_message(
                chat_id, cap, parse_mode="HTML", reply_markup=kb,
                disable_web_page_preview=True,
            )
            new_msg_id = m.message_id
        except Exception as e:
            _log_err("send_message(html)", e)

    if new_msg_id is None:
        try:
            plain = re.sub(r"<[^>]+>", "", cap)
            m = bot.send_message(
                chat_id, plain or "…", reply_markup=kb,
                disable_web_page_preview=True,
            )
            new_msg_id = m.message_id
        except Exception as e:
            _log_err("send_message(plain)", e)

    # Only NOW is it safe to remove the old message.
    if new_msg_id is not None and call and call.message:
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception as e:
            _log_err("delete_message", e)


def show_text(
    chat_id: int, text: str, kb: Optional[types.InlineKeyboardMarkup] = None,
    call: Optional[types.CallbackQuery] = None,
) -> None:
    """Send/edit a plain-text message with the same delete-after-send
    safety as show_menu."""
    text = _html_safe_truncate(text, 4096)

    if call and call.message:
        _cancel_loading(call.message.chat.id, call.message.message_id)

    if call and call.message and call.message.content_type == "text":
        try:
            bot.edit_message_text(
                text, chat_id=chat_id, message_id=call.message.message_id,
                reply_markup=kb, parse_mode="HTML", disable_web_page_preview=True,
            )
            return
        except ApiTelegramException as e:
            if "message is not modified" in str(e).lower():
                return
            _log_err("edit_message_text", e)
        except Exception as e:
            _log_err("edit_message_text", e)

        try:
            plain = re.sub(r"<[^>]+>", "", text)
            bot.edit_message_text(
                plain, chat_id=chat_id, message_id=call.message.message_id,
                reply_markup=kb, disable_web_page_preview=True,
            )
            return
        except Exception as e:
            _log_err("edit_message_text(plain)", e)

    new_msg_id: Optional[int] = None
    try:
        m = bot.send_message(chat_id, text, parse_mode="HTML", reply_markup=kb,
                             disable_web_page_preview=True)
        new_msg_id = m.message_id
    except Exception as e:
        _log_err("send_message(html)", e)

    if new_msg_id is None:
        try:
            plain = re.sub(r"<[^>]+>", "", text)
            m = bot.send_message(chat_id, plain or "…", reply_markup=kb,
                                 disable_web_page_preview=True)
            new_msg_id = m.message_id
        except Exception as e:
            _log_err("send_message(plain)", e)

    if (new_msg_id is not None and call and call.message
            and call.message.content_type != "text"):
        try:
            bot.delete_message(chat_id, call.message.message_id)
        except Exception as e:
            _log_err("delete_message", e)


# ── keyboards ──────────────────────────────────────────────────
def main_menu_kb(admin: bool = False) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"  Mʏ Bᴏᴛꜱ",   callback_data="menu_bots",     style="primary"),
        Btn(f" Uᴘʟᴏᴀᴅ Bᴏᴛ",   callback_data="menu_upload",   style="primary"),
    )
    kb.add(
        Btn(f"Pʟᴀɴꜱ",        callback_data="menu_plans",    style="primary"),
        Btn(f" Bᴜʏ Pʟᴀɴ",    callback_data="menu_buy",      style="primary"),
    )
    kb.add(
        Btn(f"Rᴇꜰᴇʀʀᴀʟ",    callback_data="menu_referral", style="primary"),
        Btn(f"Pʀᴏꜰɪʟᴇ",      callback_data="menu_profile",  style="primary"),
    )
    kb.add(
        Btn(f" Wᴀʟʟᴇᴛ",     callback_data="menu_wallet",   style="primary"),
        Btn(f"Tɪᴄᴋᴇᴛꜱ",    callback_data="menu_tickets",  style="primary"),
    )
    kb.add(
        Btn(f" Fʀᴇᴇ Tʀɪᴀʟ",    callback_data="menu_trial",    style="primary"),
        Btn(f" Cᴏᴜᴘᴏɴ",        callback_data="menu_coupon",   style="primary"),
    )
    kb.add(
        Btn(f"Hᴇʟᴘ",          callback_data="menu_help",     style="primary"),
        Btn(f"Sᴜᴘᴘᴏʀᴛ", callback_data="menu_support",  style="primary"),
    )
    kb.add(
        Btn(f" Mʏ Sᴛᴀᴛꜱ",    callback_data="menu_stats",    style="primary"),
    )
    if admin:
        kb.add(Btn(f"Aᴅᴍɪɴ Pᴀɴᴇʟ", callback_data="menu_admin", style="danger"))

    return kb


def back_main_kb() -> types.InlineKeyboardMarkup:
    return types.InlineKeyboardMarkup().add(
        Btn(f"{G['back']}  Mᴀɪɴ Mᴇɴᴜ", callback_data="menu_main", style="danger"))


def back_admin_kb() -> types.InlineKeyboardMarkup:
    return types.InlineKeyboardMarkup().add(
        Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))


def back_kb(target: str, label: str = "Back") -> types.InlineKeyboardMarkup:
    return types.InlineKeyboardMarkup().add(
        Btn(f"{G['back']}  {sc(label)}", callback_data=target, style="danger"))


def plans_kb() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    for k, v in PLAN_LIMITS.items():
        price = money_or_free(v["price"])
        style = "success" if v["price"] == 0 else "primary"
        kb.add(Btn(
            f"{G['star']}  {sc(v['name'])}  {G['bullet']}  {price}",
            callback_data=f"plan_view_{k}", style=style))
    kb.add(Btn(f"{G['back']}  Mᴀɪɴ Mᴇɴᴜ", callback_data="menu_main", style="danger"))
    return kb


def payments_kb(plan: Optional[str] = None) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    suffix = f"_{plan}" if plan else ""
    for k, v in PAYMENT_METHODS.items():
        if not bool(get_setting(f"pm_enabled_{k}", True)):
            continue
        kb.add(Btn(f"{v['tag']}  {sc(v['name'])}", callback_data=f"pay_{k}{suffix}", style="success"))
    kb.add(Btn(f"{G['back']}  Pʟᴀɴꜱ", callback_data="menu_plans", style="primary"))
    return kb


def admin_kb() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['graph']}  Sᴛᴀᴛꜱ",         callback_data="adm_stats",    style="primary"),
        Btn(f"{G['users']}  Uꜱᴇʀꜱ",         callback_data="adm_users",    style="primary"),
    )
    kb.add(
        Btn(f"{G['diamond']}  Aʟʟ Bᴏᴛꜱ",    callback_data="adm_allbots",  style="primary"),
        Btn(f"{G['wallet']}  Pᴀʏᴍᴇɴᴛꜱ",     callback_data="adm_payments", style="success"),
    )
    kb.add(
        Btn(f"{G['broadcast']}  Bʀᴏᴀᴅᴄᴀꜱᴛ", callback_data="adm_broadcast",style="success"),
        Btn(f"{G['no']}  Bᴀɴ / Uɴʙᴀɴ",      callback_data="adm_ban",      style="danger"),
    )
    kb.add(
        Btn(f"{G['plus']}  Gɪᴠᴇ Pʟᴀɴ",      callback_data="adm_giveplan", style="success"),
        Btn(f"{G['ok']}  Aᴘᴘʀᴏᴠᴇ Pᴀʏ",      callback_data="adm_approve",  style="success"),
    )
    kb.add(
        Btn(f"{G['key']}  Cᴏᴜᴘᴏɴꜱ",         callback_data="adm_coupons",  style="primary"),
        Btn(f"{G['ticket']}  Tɪᴄᴋᴇᴛꜱ",      callback_data="adm_tickets",  style="primary"),
    )
    kb.add(
        Btn(f"{G['shield']}  Aᴅᴍɪɴꜱ",       callback_data="adm_admins",   style="primary"),
        Btn(f"{G['eye']}  Aᴜᴅɪᴛ Lᴏɢ",       callback_data="adm_audit",    style="primary"),
    )
    kb.add(
        Btn(f"{G['cog']}  Gɪᴛʜᴜʙ Bᴀᴄᴋᴜᴘ",   callback_data="adm_github",   style="primary"),
        Btn(f"{G['lock']}  Sᴇᴄᴜʀɪᴛʏ",       callback_data="adm_security", style="danger"),
    )
    kb.add(
        Btn(f"{G['warn']}  Mᴀɪɴᴛᴇɴᴀɴᴄᴇ",    callback_data="adm_maint",    style="danger"),
        Btn(f"{G['settings']}  Sᴇᴛᴛɪɴɢꜱ",   callback_data="adm_settings", style="primary"),
    )
    appr_on = bool(get_setting("approval_required", True))
    pend_n = len(get_setting("pending_uploads", {}) or {})
    kb.add(
        Btn(
            f"{G['ok'] if appr_on else G['no']}  Aᴘᴘʀᴏᴠᴀʟ: {'ON' if appr_on else 'OFF'}",
            callback_data="adm_approval_toggle",
            style="success" if appr_on else "danger"),
        Btn(
            f"{G['eye']}  Pᴇɴᴅɪɴɢ" + (f" ({pend_n})" if pend_n else ""),
            callback_data="adm_pending", style="primary"),
    )
    kb.add(
        Btn(f"{G['upload']}  Mᴇɴᴜ Pʜᴏᴛᴏꜱ",  callback_data="adm_photos",       style="primary"),
        Btn(f"{G['refresh']}  Fᴏʀᴄᴇ Bᴀᴄᴋᴜᴘ", callback_data="adm_force_backup", style="success"),
    )
    # ── Advanced Sub-Panels Row 1 ──────────────────────────────────────
    kb.add(
        Btn("📊  Aɴᴀʟʏᴛɪᴄꜱ",       callback_data="adm_analytics",      style="primary"),
        Btn("👥  Uꜱᴇʀ Tᴏᴏʟꜱ",      callback_data="adm_user_tools",     style="primary"),
    )
    kb.add(
        Btn("🤖  Bᴏᴛ Mᴀɴᴀɢᴇʀ",     callback_data="adm_bot_manager",    style="primary"),
        Btn("🛡️  Sᴇᴄ Cᴇɴᴛᴇʀ",      callback_data="adm_sec_center",     style="danger"),
    )
    kb.add(
        Btn("💬  Nᴏᴛɪꜰɪᴄᴀᴛɪᴏɴꜱ",   callback_data="adm_notify_center",  style="success"),
        Btn("⚙️  Sʏꜱ Tᴏᴏʟꜱ",       callback_data="adm_sys_tools",      style="primary"),
    )
    # ── MEGA ADVANCED PANELS ──────────────────────────────────────────
    kb.add(
        Btn("🐙  Gʜ Bʀᴏᴡꜱᴇʀ",      callback_data="adm_gh_browser",     style="primary"),
        Btn("💳  Pᴀʏ Cᴏɴꜰɪɢ",      callback_data="adm_pay_config",     style="success"),
    )
    kb.add(
        Btn("🔧  Bᴏᴛ Cᴏɴꜰɪɢ",      callback_data="adm_bot_cfg",        style="primary"),
        Btn("🎨  Aᴘᴘᴇᴀʀᴀɴᴄᴇ",      callback_data="adm_appearance",     style="primary"),
    )
    kb.add(
        Btn("🎫  Cᴏᴜᴘᴏɴ+",          callback_data="adm_coupon_plus",    style="primary"),
        Btn("📝  Tᴇᴍᴘʟᴀᴛᴇꜱ",        callback_data="adm_templates",      style="primary"),
    )
    kb.add(
        Btn("🔗  Rᴇꜰᴇʀʀᴀʟ Sʏꜱ",    callback_data="adm_referral_sys",   style="success"),
        Btn("🧹  Jᴀɴɪᴛᴏʀ",          callback_data="adm_janitor",        style="danger"),
    )
    kb.add(
        Btn("🌐  Wᴇʙʜᴏᴏᴋꜱ",         callback_data="adm_webhooks",       style="primary"),
        Btn("🎯  Fᴇᴀᴛᴜʀᴇ Fʟᴀɢꜱ",    callback_data="adm_feature_flags",  style="primary"),
    )
    kb.add(
        Btn("⏱️  Rᴀᴛᴇ Lɪᴍɪᴛꜱ",      callback_data="adm_rate_config",    style="danger"),
        Btn("📡  Lɪᴠᴇ Mᴏɴɪᴛᴏʀ",      callback_data="adm_live_monitor",   style="success"),
    )
    kb.add(
        Btn("💎  Rᴇᴠ Gᴏᴀʟꜱ",        callback_data="adm_rev_goals",      style="success"),
        Btn("⏰  Sᴄʜᴇᴅᴜʟᴇʀ",         callback_data="adm_scheduler",      style="primary"),
    )
    kb.add(
        Btn("📥  Iᴍᴘᴏʀᴛ/Exᴘ",       callback_data="adm_import_export",  style="primary"),
        Btn("🏆  Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ",      callback_data="adm_leaderboard",    style="primary"),
    )
    kb.add(
        Btn("🌍  Lᴀɴɢᴜᴀɢᴇꜱ",         callback_data="adm_languages",      style="primary"),
        Btn("🤖  Bᴏᴛ Cᴏɴᴛʀᴏʟꜱ",     callback_data="adm_bot_controls",   style="primary"),
    )
    kb.add(
        Btn("👤  Sᴜʙꜱᴄʀɪᴘᴛɪᴏɴꜱ",    callback_data="adm_subscriptions",  style="primary"),
        Btn("🔐  Adᴍɪɴ 2FA",         callback_data="adm_admin_2fa",      style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Mᴀɪɴ Mᴇɴᴜ", callback_data="menu_main", style="primary"))
    return kb


def github_kb(status: Dict[str, Any]) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(Btn(f"{G['plus']}  Bᴀᴄᴋᴜᴘ Nᴏᴡ",      callback_data="gh_backup_now",  style="success"))
    kb.add(Btn(f"{G['refresh']}  Rᴇꜱᴛᴏʀᴇ Lᴀᴛᴇꜱᴛ", callback_data="gh_restore_now", style="primary"))
    kb.add(Btn(
        f"{G['rec'] if status['autoEnabled'] else G['rec_off']}  "
        f"Auto Backup: {'ON' if status['autoEnabled'] else 'OFF'}",
        callback_data="gh_toggle_auto",
        style="success" if status["autoEnabled"] else "danger"))
    kb.add(
        Btn(f"{G['key']}  {sc('Change Token' if status['tokenSet'] else 'Set Token')}",
            callback_data="gh_set_token", style="primary"),
        Btn(f"{G['diamond']}  {sc('Change Repo' if status['repoSet'] else 'Set Repo')}",
            callback_data="gh_set_repo",  style="primary"),
    )
    kb.add(
        Btn(f"{G['tri']}  Sᴇᴛ Bʀᴀɴᴄʜ",  callback_data="gh_set_branch",   style="primary"),
        Btn(f"{G['cog']}  Iɴᴛᴇʀᴠᴀʟ",    callback_data="gh_set_interval", style="primary"),
    )
    kb.add(Btn(f"{G['no']}  Cʟᴇᴀʀ Cᴏɴꜰɪɢ", callback_data="gh_clear",     style="danger"))
    kb.add(Btn(f"{G['refresh']}  Rᴇꜰʀᴇꜱʜ",   callback_data="adm_github",  style="primary"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ",       callback_data="menu_admin",  style="primary"))
    return kb


def bot_actions_kb(bot_id: str, running: bool, premium: bool = False) -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    if running:
        kb.add(
            Btn(f"{G['stop']}  Sᴛᴏᴘ",       callback_data=f"bot_stop_{bot_id}",    style="danger"),
            Btn(f"{G['refresh']}  Rᴇꜱᴛᴀʀᴛ", callback_data=f"bot_restart_{bot_id}", style="success"),
        )
    else:
        kb.add(
            Btn(f"{G['play']}  Sᴛᴀʀᴛ",      callback_data=f"bot_start_{bot_id}",   style="success"),
            Btn(f"{G['refresh']}  Rᴇꜱᴛᴀʀᴛ", callback_data=f"bot_restart_{bot_id}", style="primary"),
        )
    kb.add(
        Btn(f"{G['bolt']}  Lɪᴠᴇ Lᴏɢꜱ", callback_data=f"bot_logs_{bot_id}", style="primary"),
        Btn(f"{G['eye']}  Iɴꜰᴏ",       callback_data=f"bot_info_{bot_id}", style="primary"),
    )
    kb.add(
        Btn(f"{G['settings']}  Eɴᴠ Vᴀʀꜱ", callback_data=f"bot_env_{bot_id}",  style="primary"),
        Btn(f"{G['cog']}  Cʀᴏɴ",          callback_data=f"bot_cron_{bot_id}", style="primary"),
    )
    kb.add(
        Btn(f"{G['download']}  Iɴꜱᴛᴀʟʟ Pᴋɢ", callback_data=f"bot_pip_{bot_id}",   style="primary"),
        Btn(f"{G['plus']}  Cʟᴏɴᴇ",           callback_data=f"bot_clone_{bot_id}", style="primary"),
    )
    if premium:
        is_open = bot_id in TUNNELS and TUNNELS[bot_id].get("proc") and TUNNELS[bot_id]["proc"].poll() is None
        label = "Stop Public URL" if is_open else "Public URL"
        glyph = G['no'] if is_open else G['cloud']
        kb.add(Btn(f"{glyph}  {label}", callback_data=f"bot_tunnel_{bot_id}",
                   style="danger" if is_open else "success"))
    kb.add(Btn(f"{G['arrow']}  Dᴏᴡɴʟᴏᴀᴅ", callback_data=f"bot_dl_{bot_id}", style="primary"))
    kb.add(Btn(f"{G['no']}  Dᴇʟᴇᴛᴇ",       callback_data=f"bot_delete_{bot_id}", style="danger"))
    kb.add(Btn(f"{G['back']}  Mʏ Bᴏᴛꜱ",    callback_data="menu_bots",            style="primary"))
    return kb


def confirm_kb(yes_cb: str, no_cb: str = "menu_main", yes_label: str = "Confirm",
               no_label: str = "Cancel") -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  {sc(yes_label)}", callback_data=yes_cb, style="success"),
        Btn(f"{G['no']}  {sc(no_label)}",  callback_data=no_cb,  style="danger"),
    )
    return kb


# ═════════════════════════════════════════════════════════════════
# 10. SANDBOX RUNNER  (subprocess pool, secret-stripped env)
# ═════════════════════════════════════════════════════════════════

RUNNING: Dict[str, Dict[str, Any]] = {}    # bot_id -> {proc, kind, started, log, ...}
START_TIME: float = time.time()            # panel boot time, for uptime card
_LOCK_FH_KEEPALIVE: Any = None             # singleton-lock fd, kept alive for the process lifetime
_runner_lock = threading.Lock()
SECURE_EXEC = BASE_DIR / "secure_exec.py"


_SKIP_DIR_PARTS = {".deps", "node_modules", ".tmp_run", "__pycache__",
                   ".git", "venv", ".venv", "env"}


def _iter_user_files(bot_dir: Path, suffix: str) -> List[Path]:
    """Recursive scan that skips dependency / cache / VCS folders."""
    out: List[Path] = []
    for p in bot_dir.rglob(f"*{suffix}"):
        if any(part in _SKIP_DIR_PARTS for part in p.parts):
            continue
        out.append(p)
    return sorted(out, key=lambda x: (len(x.parts), str(x)))


def detect_entry(bot_dir: Path) -> Tuple[Optional[str], Optional[str]]:
    """Find the entry file. Returns (kind, relative_path_from_bot_dir).
    Searches the bot dir recursively — many users zip their bot inside
    a wrapper folder (e.g. `MyBot/bot.py`), and the old shallow `glob`
    missed those."""
    # 1. Standard entry names — check shallow first, then recursive
    for n in ENTRY_NODE:
        p = bot_dir / n
        if p.exists():
            return ("node", n)
    for n in ENTRY_PY:
        p = bot_dir / n
        if p.exists():
            return ("python", n)
    # Recursive: prefer files closer to the root (shorter path)
    for n in ENTRY_PY:
        for p in _iter_user_files(bot_dir, ".py"):
            if p.name == n:
                return ("python", str(p.relative_to(bot_dir)))
    for n in ENTRY_NODE:
        for p in _iter_user_files(bot_dir, ".js"):
            if p.name == n:
                return ("node", str(p.relative_to(bot_dir)))
    # 2. Any .py file (recursive, skipping deps)
    py_files = _iter_user_files(bot_dir, ".py")
    if py_files:
        return ("python", str(py_files[0].relative_to(bot_dir)))
    # 3. Any .js file (recursive)
    js_files = _iter_user_files(bot_dir, ".js")
    if js_files:
        return ("node", str(js_files[0].relative_to(bot_dir)))
    # 4. Inner .zip — extract once then re-scan
    zip_files = [p for p in bot_dir.rglob("*.zip")
                 if not any(part in _SKIP_DIR_PARTS for part in p.parts)]
    if zip_files:
        import zipfile as _zf
        try:
            with _zf.ZipFile(zip_files[0], "r") as z:
                _safe_extract_archive(z, bot_dir)
        except Exception:
            return (None, None)
        # recursive re-check
        py_files = _iter_user_files(bot_dir, ".py")
        if py_files:
            return ("python", str(py_files[0].relative_to(bot_dir)))
        js_files = _iter_user_files(bot_dir, ".js")
        if js_files:
            return ("node", str(js_files[0].relative_to(bot_dir)))
    return (None, None)


def _read_local_env_files(bot_dir: Path) -> Dict[str, str]:
    """Load simple .env files shipped with a child bot."""
    out: Dict[str, str] = {}
    for path in (bot_dir / ".env", bot_dir / ".env.local", bot_dir / "config.env"):
        if not path.is_file():
            continue
        try:
            for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("export "):
                    line = line[7:].lstrip()
                if "=" not in line:
                    continue
                key, value = line.split("=", 1)
                key = key.strip().upper()
                if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", key):
                    continue
                value = value.strip()
                if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
                    value = value[1:-1]
                if key in {"BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIN_BOT_TOKEN"}:
                    value = "".join(value.split())
                elif key.endswith(("_URL", "_URI", "_ENDPOINT")):
                    value = value.replace("\r", "").replace("\n", "").strip()
                else:
                    value = value.strip()
                out[key] = value
        except Exception as e:
            print(f"[dotenv] skipped {path.name}: {e}", file=sys.stderr)
    return out


# ── Robust child ENV parsing/repair ──────────────────────────────
# Users often paste a complete .env block into the single KEY=VALUE
# prompt.  Older builds stored the whole block as BOT_TOKEN and then
# ``"".join(value.split())`` glued the next variables onto the token,
# producing InvalidToken/InvalidURL errors.  Keep multiline input safe
# and automatically repair already-corrupted saved env dictionaries.
_COMMON_ENV_KEYS = {
    "BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIN_BOT_TOKEN", "OWNER_ID", "OWNER_IDS",
    "LOGGER_ID", "LOG_CHANNEL", "LOG_CHANNEL_ID", "API_ID", "API_HASH",
    "MONGO_URI", "MONGODB_URI", "DATABASE_URL", "DATABASE_URI", "DB_URI",
    "GROQ_API_KEY", "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GOOGLE_API_KEY",
    "GITHUB_TOKEN", "GITHUB_REPO", "GITHUB_BRANCH", "ADMIN_ID", "ADMIN_IDS",
    "SUPPORT_CHAT", "SUPPORT_GROUP", "ANNOUNCE_CHANNEL", "UPDATE_CHANNEL",
    "PORT", "WEBHOOK_URL", "REDIS_URL", "REDIS_URI", "SESSION_STRING",
    "API_KEY", "SECRET_KEY", "WEB_URL", "BASE_URL", "CHAT_ID", "CHANNEL_ID",
}

def _looks_like_env_key(name: str) -> bool:
    """Return True for any syntactically valid dotenv variable name.

    Do not maintain a suffix allow-list here: real projects frequently use
    arbitrary names such as FIREBASE_CONFIG, TELEGRAM_SESSION, DEBUG_MODE,
    S3_BUCKET, etc.  The old allow-list silently dropped those variables.
    """
    n = str(name or "").strip().upper()
    return bool(re.match(r"^[A-Z_][A-Z0-9_]*$", n))


def _clean_env_value(key: str, value: Any) -> str:
    k = str(key).strip().upper()
    v = "" if value is None else str(value).strip()
    # Remove matching wrapping quotes only; do not destroy internal chars.
    if len(v) >= 2 and v[0] == v[-1] and v[0] in {"'", '"'}:
        v = v[1:-1].strip()
    if k in {"BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIN_BOT_TOKEN"}:
        # Telegram tokens contain no whitespace.  Unlike the old code,
        # first remove only whitespace around the token, never concatenate
        # unrelated KEY=VALUE assignments into it.
        v = re.sub(r"\s+", "", v)
    elif k.endswith(("_URL", "_URI", "_ENDPOINT")):
        v = v.replace("\r", "").replace("\n", "").strip()
    else:
        v = v.strip()
    return v


def _parse_dotenv_text(raw: Any) -> Dict[str, str]:
    """Parse a complete pasted .env block without collapsing variables.

    Supports KEY=value, optional export, comments, quoted values and quoted
    values containing spaces/newlines.  It deliberately never treats the
    first assignment as a synthetic ``__PASTED_ENV__`` variable.
    """
    text = "" if raw is None else str(raw)
    out: Dict[str, str] = {}
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    current_key: Optional[str] = None
    current_value: List[str] = []
    quote: Optional[str] = None

    def flush() -> None:
        nonlocal current_key, current_value, quote
        if current_key is not None:
            val = "\n".join(current_value)
            out[current_key] = _clean_env_value(current_key, val)
        current_key = None
        current_value = []
        quote = None

    for raw_line in lines:
        line = raw_line.strip()
        if current_key is None:
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[7:].lstrip()
            m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$", line)
            if not m:
                continue
            current_key = m.group(1).upper()
            val = m.group(2).strip()
            if val[:1] in {"'", '"'}:
                quote = val[0]
                rest = val[1:]
                if rest.endswith(quote) and not rest.endswith("\\" + quote):
                    current_value = [rest[:-1]]
                    flush()
                else:
                    current_value = [rest]
            else:
                # Strip an inline comment only when it is separated by space.
                val = re.sub(r"\s+#.*$", "", val).strip()
                current_value = [val]
                flush()
        else:
            # Continue a quoted multiline value until its closing quote.
            current_value.append(raw_line)
            joined = "\n".join(current_value)
            if joined.endswith(quote or "") and not joined.endswith("\\" + (quote or "")):
                current_value[-1] = current_value[-1][:-1]
                flush()
    flush()
    return out


def _split_embedded_env_value(key: str, value: Any) -> Dict[str, str]:
    """Parse one KEY=value input, including an accidentally pasted .env block."""
    k0 = str(key).strip().upper()
    raw = "" if value is None else str(value).strip()
    if "\n" in raw or "\r" in raw:
        parsed = _parse_dotenv_text(raw)
        return parsed or {k0: _clean_env_value(k0, raw)}

    # Handle legacy corrupted values containing multiple KEY=value assignments.
    pat = re.compile(r"(?<![A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_]*)\s*=\s*")
    matches = [m for m in pat.finditer(raw) if _looks_like_env_key(m.group(1))]
    if not matches or matches[0].start() != 0:
        return {k0: _clean_env_value(k0, raw)}

    # If there is exactly one assignment and it is the supplied key, keep it.
    if len(matches) == 1 and matches[0].group(1).upper() == k0:
        return {k0: _clean_env_value(k0, raw[matches[0].end():])}

    out: Dict[str, str] = {}
    for i, m in enumerate(matches):
        name = m.group(1).strip().upper()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(raw)
        part = raw[m.end():end].strip().strip('"\'').strip()
        out[name] = _clean_env_value(name, part)
    return out


def _repair_env_dict(env: Dict[str, Any]) -> Dict[str, str]:
    """Normalize ENV dictionaries and recover legacy pasted/corrupted blocks."""
    repaired: Dict[str, str] = {}
    for key, value in (env or {}).items():
        k = str(key).strip().upper()
        if not _looks_like_env_key(k):
            continue
        # Synthetic legacy key: parse the whole value as dotenv text.
        if k == "__PASTED_ENV__":
            parsed = _parse_dotenv_text(value)
            if parsed:
                repaired.update(parsed)
            else:
                repaired.update(_split_embedded_env_value(k, value))
            continue
        repaired.update(_split_embedded_env_value(k, value))
    return repaired

def safe_env(bot_dir: Path, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
    # Never inherit the HOST's private secrets, but DO pass the CHILD bot's
    # explicitly configured secrets and its local .env secrets.  The old
    # implementation removed BOT_TOKEN after loading the child environment,
    # which caused otherwise valid uploaded bots to die with:
    #   RuntimeError: BOT_TOKEN env variable missing
    env = {k: v for k, v in os.environ.items() if k not in SECRET_ENV_NAMES}

    # Project-local env files belong to the uploaded bot, so their values are
    # intentionally allowed (including BOT_TOKEN/API_HASH/etc.).
    local = _repair_env_dict(_read_local_env_files(bot_dir))
    child = _repair_env_dict(extra or {})

    # Child settings take precedence over project .env, and both take
    # precedence over the non-secret inherited host environment.
    env.update(local)
    env.update(child)

    # Normalize the three common Telegram token variable names one final time
    # without ever concatenating unrelated KEY=VALUE assignments.
    for key in ("BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIN_BOT_TOKEN"):
        if key in env:
            env[key] = _clean_env_value(key, env[key])

    env["HOME"] = str(bot_dir)
    env["TMPDIR"] = str(bot_dir / ".tmp_run")
    env["PATH"] = "/usr/local/bin:/usr/bin:/bin"
    env.setdefault("NODE_ENV", "production")
    deps_dir = str(bot_dir / ".deps")
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = f"{deps_dir}:{existing_pp}" if existing_pp else deps_dir
    env["PYTHONUNBUFFERED"] = "1"
    env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
    Path(env["TMPDIR"]).mkdir(parents=True, exist_ok=True)
    Path(deps_dir).mkdir(parents=True, exist_ok=True)
    return env

# ── module-name → PyPI package-name mapping ───────────────────────
# Many third-party libs are imported under a name that differs from
# their pip package. Without this mapping pip would 404 (e.g. `cv2` is
# really `opencv-python`). This is the most common reason "auto-install
# nahi chala" — and why uploaded bots crashed at import time.
_PYPI_ALIAS: Dict[str, str] = {
    "telebot":       "pyTelegramBotAPI",
    # `from telegram import Update` belongs to python-telegram-bot.
    # The bare `telegram` package on PyPI is an unrelated tiny shim
    # that does NOT expose Update / Bot — installing it by accident
    # is the most common source of the
    #   ImportError: cannot import name 'Update' from 'telegram'
    # crash. We map it to the real package and additionally validate
    # the installed copy in `_filter_third_party`.
    "telegram":      "python-telegram-bot",
    "telethon":      "Telethon",
    "pyrogram":      "Pyrogram",
    "hydrogram":     "hydrogram",
    "pyromod":       "pyromod",
    "tgcrypto":      "TgCrypto",
    "PIL":           "Pillow",
    "cv2":           "opencv-python",
    "bs4":           "beautifulsoup4",
    "yaml":          "PyYAML",
    "dotenv":        "python-dotenv",
    "Crypto":        "pycryptodome",
    "Cryptodome":    "pycryptodomex",
    "dateutil":      "python-dateutil",
    "magic":         "python-magic",
    "skimage":       "scikit-image",
    "sklearn":       "scikit-learn",
    "google":        "google-api-python-client",
    "googletrans":   "googletrans",
    "OpenSSL":       "pyOpenSSL",
    "wx":            "wxPython",
    "psycopg2":      "psycopg2-binary",
    "MySQLdb":       "mysqlclient",
    "serial":        "pyserial",
    "win32api":      "pywin32",
    "ujson":         "ujson",
    "uvloop":        "uvloop",
    "discord":       "discord.py",
    "httpx":         "httpx",
    "aiohttp":       "aiohttp",
    "aiogram":       "aiogram",
    "fastapi":       "fastapi",
    "flask":         "flask",
    "starlette":     "starlette",
    "redis":         "redis",
    "pymongo":       "pymongo",
    "motor":         "motor",
    "psutil":        "psutil",
    "schedule":      "schedule",
    "apscheduler":   "APScheduler",
    "cryptography":  "cryptography",
    "github":        "PyGithub",
    "requests":      "requests",
    # extra safety net — pip name ≠ import name
    "nacl":          "PyNaCl",
    "git":           "GitPython",
    "jose":          "python-jose",
    "pkg_resources": "setuptools",
    "lxml":          "lxml",
    "chardet":       "chardet",
}


# Modules whose installed copy must expose specific symbols to be
# considered "really installed". Catches the wrong-package-on-PyPI trap
# (e.g. the `telegram` shim that lacks `Update`).
_VALIDATE_SYMBOLS: Dict[str, List[str]] = {
    "telegram": ["Update", "Bot"],
}


def _purge_bad_install(deps_dir: Path, mod_name: str) -> None:
    """Remove a wrong-package install (and its dist-info) from a bot's
    `.deps` so the next pip install can put the correct one in its
    place. Used when `_VALIDATE_SYMBOLS` says the cached package is
    not the one we actually need."""
    try:
        if not deps_dir.exists():
            return
        target = deps_dir / mod_name
        if target.exists():
            try:
                shutil.rmtree(str(target), ignore_errors=True)
            except Exception:
                pass
        for child in list(deps_dir.iterdir()):
            n = child.name.lower()
            if n.endswith((".dist-info", ".egg-info")) and \
                    n.startswith(mod_name.lower()):
                try:
                    shutil.rmtree(str(child), ignore_errors=True)
                except Exception:
                    try:
                        child.unlink()
                    except Exception:
                        pass
    except Exception as e:
        print(f"[purge_bad_install] {mod_name}: {e}", file=sys.stderr)


def _scan_imports(bot_dir: Path) -> List[str]:
    """Recursively scan every .py file for top-level module imports."""
    import ast as _ast
    found: set = set()
    for pyfile in bot_dir.rglob("*.py"):
        # Skip our own .deps cache so we don't mistake installed libs
        # for the bot's own imports.
        if ".deps" in pyfile.parts:
            continue
        try:
            tree = _ast.parse(pyfile.read_text(errors="ignore"))
        except Exception:
            continue
        for node in _ast.walk(tree):
            if isinstance(node, _ast.Import):
                for n in node.names:
                    if n.name:
                        found.add(n.name.split(".")[0])
            elif isinstance(node, _ast.ImportFrom):
                if node.level and node.level > 0:
                    continue  # relative import — local package
                if node.module:
                    found.add(node.module.split(".")[0])
    return sorted(found)


def _needs_kurigram(bot_dir: Path) -> bool:
    """Detect bots that intentionally use Kurigram-only Pyrogram APIs.

    Kurigram provides the ``pyrogram`` import namespace, so these projects
    must never have the ordinary Pyrogram distribution installed by the
    generic import scanner. This detection is deliberately limited to the
    bot directory and does not affect normal Pyrogram bots.
    """
    try:
        for pyfile in bot_dir.rglob("*.py"):
            if ".deps" in pyfile.parts or "__pycache__" in pyfile.parts:
                continue
            text = pyfile.read_text(errors="ignore")
            if "ButtonStyle" in text or "max_concurrent_transmissions" in text:
                return True
    except Exception:
        pass
    try:
        req = bot_dir / "requirements.txt"
        if req.exists():
            for raw in req.read_text(errors="ignore").splitlines():
                line = raw.strip().lower()
                if line and not line.startswith("#") and re.match(r"^kurigram(?:[<>=!~]|$)", line):
                    return True
    except Exception:
        pass
    return False


def _kurigram_ready(bot_dir: Path) -> bool:
    """Return True when this bot's .deps contains a usable Kurigram namespace."""
    try:
        enums_py = bot_dir / ".deps" / "pyrogram" / "enums.py"
        return enums_py.is_file() and "ButtonStyle" in enums_py.read_text(errors="ignore")
    except Exception:
        return False


def _prepare_kurigram_deps(bot_dir: Path, log: List[str]) -> None:
    """Remove only stale standard-Pyrogram files from this bot's cache."""
    deps_dir = bot_dir / ".deps"
    deps_dir.mkdir(parents=True, exist_ok=True)
    removed = False
    try:
        py_pkg = deps_dir / "pyrogram"
        if py_pkg.exists():
            shutil.rmtree(str(py_pkg), ignore_errors=True)
            removed = True
        for child in list(deps_dir.iterdir()):
            low = child.name.lower()
            if low.startswith("pyrogram-") and low.endswith((".dist-info", ".egg-info")):
                try:
                    if child.is_dir():
                        shutil.rmtree(str(child), ignore_errors=True)
                    else:
                        child.unlink()
                    removed = True
                except Exception:
                    pass
    except Exception as e:
        log.append(f"[{G['warn']}] Kurigram cache cleanup warning: {e}")
    if removed:
        log.append(f"[{G['ok']}] removed stale Pyrogram cache; Kurigram will provide pyrogram")


def _filter_third_party(modules: List[str], bot_dir: Path) -> List[str]:
    """Drop stdlib, local module names, and modules already importable
    from the bot's .deps cache. Returns only installable PyPI names that
    are still missing."""
    import importlib.util as _ilu
    stdlib = set(getattr(sys, "stdlib_module_names", set()))
    skip = stdlib | {"__future__", ""}
    # local modules (recursively). Uploaded bots are often wrapped in a
    # subfolder, so `database.py`/`utils.py` may not be at bot_dir itself.
    # Treat every local Python module/package as project code rather than
    # trying to install a same-named PyPI package.
    deps_dir = bot_dir / ".deps"
    for pyfile in bot_dir.rglob("*.py"):
        if deps_dir in pyfile.parents:
            continue
        skip.add(pyfile.stem)
    for init in bot_dir.rglob("__init__.py"):
        if deps_dir in init.parents:
            continue
        skip.add(init.parent.name)
    # Make .deps importable for the find_spec check below so we don't
    # re-install something that's already cached locally.
    deps_str = str(deps_dir)
    deps_in_path = deps_str in sys.path
    if deps_dir.exists() and not deps_in_path:
        sys.path.insert(0, deps_str)

    out: List[str] = []
    seen: set = set()
    try:
        for m in modules:
            if not m or m in skip:
                continue
            # Already importable (stdlib was caught above; this catches
            # things like cv2 already installed in .deps/).
            try:
                if m == "pyrogram" and _needs_kurigram(bot_dir):
                    # Kurigram intentionally owns the pyrogram namespace for
                    # these bots. Never let the generic scanner install the
                    # unrelated Pyrogram distribution over it.
                    continue
                if _ilu.find_spec(m) is not None:
                    # Even if importable, validate that the installed
                    # copy is the RIGHT package (not the wrong-name
                    # PyPI shim). If it isn't, nuke it so pip can
                    # reinstall the correct one below.
                    needed = _VALIDATE_SYMBOLS.get(m)
                    if needed:
                        try:
                            _real = importlib.import_module(m)
                            if all(hasattr(_real, s) for s in needed):
                                continue
                        except Exception:
                            pass
                        # Wrong package — purge and force a reinstall.
                        try:
                            del sys.modules[m]
                        except KeyError:
                            pass
                        _purge_bad_install(deps_dir, m)
                    else:
                        continue
            except (ImportError, ValueError):
                pass
            pip_name = _PYPI_ALIAS.get(m, m)
            if pip_name in seen:
                continue
            seen.add(pip_name)
            out.append(pip_name)
    finally:
        if deps_dir.exists() and not deps_in_path:
            try:
                sys.path.remove(deps_str)
            except ValueError:
                pass
    return out


def _pip_env(deps_dir: Path) -> Dict[str, str]:
    """Env for pip subprocesses: silence root warnings, keep installs
    confined to the bot's `.deps/` so we never trip on permissions.

    NOTE: We intentionally do NOT set PYTHONUSERBASE — that conflicts
    with `--target` and pip refuses to combine them ("Can not combine
    '--user' and '--target'"). We rely on `--target` alone."""
    env = {**os.environ,
           "PIP_DISABLE_PIP_VERSION_CHECK": "1",
           "PIP_NO_INPUT": "1",
           "PIP_ROOT_USER_ACTION": "ignore"}
    env.pop("PYTHONUSERBASE", None)
    env.pop("PIP_USER", None)
    return env


_PIP_BASE_FLAGS = ["--upgrade", "--no-input", "--no-warn-script-location",
                   "--disable-pip-version-check"]


def install_deps(bot_dir: Path, kind: str, log: List[str]) -> bool:
    try:
        if kind == "python":
            deps_dir = bot_dir / ".deps"
            deps_dir.mkdir(parents=True, exist_ok=True)
            req = bot_dir / "requirements.txt"
            pip_env = _pip_env(deps_dir)
            needs_kuri = _needs_kurigram(bot_dir)
            if needs_kuri:
                # Remove an old standard-Pyrogram cache before requirements
                # are installed. This is the only special handling for
                # Kurigram projects; normal Pyrogram bots are untouched.
                _prepare_kurigram_deps(bot_dir, log)

            # 1) requirements.txt (if present)
            if req.exists():
                log.append(f"{G['div']} pip install (requirements.txt) {G['div']}")
                r = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     "--target", str(deps_dir), *_PIP_BASE_FLAGS,
                     "-r", str(req)],
                    cwd=str(bot_dir), timeout=600, capture_output=True, text=True,
                    env=pip_env,
                )
                for line in (r.stdout or "").splitlines()[-15:]:
                    log.append(line)
                for line in (r.stderr or "").splitlines()[-10:]:
                    log.append(line)
                log.append(f"[{G['ok']}] requirements.txt done (rc={r.returncode})")

            # For Kurigram bots, requirements.txt normally provides Kurigram.
            # If it did not, install it explicitly once. Never reinstall a
            # working copy on every restart.
            if needs_kuri and not _kurigram_ready(bot_dir):
                log.append(f"{G['div']} installing missing Kurigram provider {G['div']}")
                rk = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     "--target", str(deps_dir), *_PIP_BASE_FLAGS,
                     "--force-reinstall", "kurigram>=2.2.25"],
                    cwd=str(bot_dir), timeout=600, capture_output=True, text=True,
                    env=pip_env,
                )
                for line in (rk.stdout or "").splitlines()[-10:]:
                    log.append(line)
                for line in (rk.stderr or "").splitlines()[-10:]:
                    log.append(line)
                if rk.returncode != 0:
                    log.append(f"[{G['warn']}] Kurigram install failed (rc={rk.returncode})")

            # 2) AST-scan imports and install anything still missing.
            #    We always do this so a bot that adds a new `import foo`
            #    after upload doesn't crash on next start.
            try:
                modules = _scan_imports(bot_dir)
                third_party = _filter_third_party(modules, bot_dir)
                if third_party:
                    log.append(f"{G['div']} auto-install (scanned imports) {G['div']}")
                    log.append(f"📦 packages: {', '.join(third_party)}")
                    # Install each scanned package independently. A missing/non-PyPI
                    # local import such as `database` must not block valid packages
                    # (for example Hydrogram) from being installed.
                    install_failures = 0
                    for package in third_party:
                        r2 = subprocess.run(
                            [sys.executable, "-m", "pip", "install",
                             "--target", str(deps_dir), *_PIP_BASE_FLAGS, package],
                            cwd=str(bot_dir), timeout=600, capture_output=True, text=True,
                            env=pip_env,
                        )
                        for line in (r2.stdout or "").splitlines()[-8:]:
                            log.append(line)
                        for line in (r2.stderr or "").splitlines()[-8:]:
                            log.append(line)
                        if r2.returncode != 0:
                            install_failures += 1
                            log.append(f"[{G['warn']}] skipped package {package} (rc={r2.returncode}); continuing")
                        else:
                            log.append(f"[{G['ok']}] installed {package}")
                    log.append(
                        f"[{G['ok']}] auto-install scan finished "
                        f"(failed={install_failures})"
                    )
            except Exception as e:
                log.append(f"[{G['warn']}] auto-install scan error: {e}")
            return True
        if kind == "node":
            pkg = bot_dir / "package.json"
            if not pkg.exists():
                return False
            if (bot_dir / "node_modules").exists():
                log.append(f"[{G['ok']}] node_modules cached, skipping npm install")
                return False
            log.append(f"{G['div']} npm install {G['div']}")
            r = subprocess.run(
                ["npm", "install", "--omit=dev", "--no-audit", "--no-fund"],
                cwd=str(bot_dir), timeout=300, capture_output=True, text=True,
            )
            for line in (r.stdout or "").splitlines()[-15:]:
                log.append(line)
            for line in (r.stderr or "").splitlines()[-10:]:
                log.append(line)
            log.append(f"[{G['ok']}] npm done (rc={r.returncode})")
            return True
    except subprocess.TimeoutExpired:
        log.append(f"[{G['warn']}] dependency install timeout (>5min)")
    except FileNotFoundError as e:
        log.append(f"[{G['warn']}] tool not found: {e}")
    except Exception as e:
        log.append(f"[{G['warn']}] install error: {e}")
    return False


_TELEGRAM_TOKEN_REDACT_RE = re.compile(r"\b\d{8,10}:[A-Za-z0-9_-]{30,50}\b")


def _redact_runtime_log(text: str) -> str:
    s = str(text or "")
    s = _TELEGRAM_TOKEN_REDACT_RE.sub("[REDACTED_TELEGRAM_TOKEN]", s)
    # Redact common secret assignments without logging the actual value.
    s = re.sub(r"(?i)(\b(?:BOT_TOKEN|TELEGRAM_BOT_TOKEN|MAIN_BOT_TOKEN|API_KEY|API_HASH|PASSWORD|SECRET|MONGO_URI|MONGODB_URI|GROQ_API_KEY|OPENAI_API_KEY|BHARATPE_TOKEN)\s*[=:]\s*)[^\s]+", r"\1[REDACTED]", s)
    s = re.sub(r"(?i)(mongodb(?:\+srv)?://)[^\s]+", r"\1[REDACTED]", s)
    return s


def _drain_proc(bot_id: str, proc: subprocess.Popen, log: List[str]) -> None:
    try:
        if not proc.stdout:
            return
        for line in iter(proc.stdout.readline, b""):
            try:
                txt = _redact_runtime_log(line.decode("utf-8", "replace").rstrip())
            except Exception:
                txt = repr(line)
            log.append(txt)
            if len(log) > LOG_RING:
                del log[: len(log) - LOG_RING]
    except Exception:
        pass
    # crash-watch — auto-restart if plan supports it
    try:
        rc = proc.wait()
        log.append(f"{G['div']} process exited rc={rc} {G['div']}")
        info = RUNNING.get(bot_id)
        was_manual = (info is None) or info.get("manual_stop", False)
        b_doc = find_bot(bot_id)

        # capture last error lines so the bot view can surface them
        if b_doc is not None:
            tail = [ln for ln in log[-15:] if ln and not ln.startswith(G["div"])]
            err_text = "\n".join(tail[-8:])[:1500]
            b_doc["last_error"] = err_text
            b_doc["last_exit_code"] = int(rc) if rc is not None else None
            b_doc["last_exit_at"] = ts_iso()
            if rc not in (0, None) and not was_manual:
                b_doc["status"] = "crashed"
            try:
                save_bot(b_doc)
            except Exception:
                pass

        if not info:
            return
        if not b_doc:
            return
        owner = db_load()["users"].get(str(b_doc["owner"]))
        plan = (owner or {}).get("plan", "free")
        plan_active = user_plan_active(owner or {})
        memory_limited = bool(info.get("memory_limit_exceeded", False))
        if PLAN_LIMITS.get(plan, {}).get("auto_restart") and plan_active and not was_manual and not memory_limited:
            now = time.time()
            history = [float(x) for x in (b_doc.get("_restart_history") or []) if now - float(x) < 600]
            if len(history) >= 5:
                b_doc["_restart_history"] = history
                b_doc["status"] = "crashed"
                b_doc["last_error"] = (b_doc.get("last_error") or "") + "\nAuto-restart stopped after 5 crashes in 10 minutes."
                save_bot(b_doc)
                log.append(f"[{G['warn']}] auto-restart disabled: crash loop detected")
                return
            history.append(now)
            b_doc["_restart_history"] = history
            save_bot(b_doc)
            log.append(f"[{G['refresh']}] auto-restart in 3s...")
            time.sleep(3)
            start_child(b_doc)
    except Exception:
        pass


def _watch_child_memory(bot_id: str, pid: int, ram_mb: int) -> None:
    """Enforce the purchased plan's per-bot RAM allowance when psutil exists."""
    if psutil is None or ram_mb <= 0:
        return
    limit = int(ram_mb) * 1024 * 1024
    over = 0
    while True:
        time.sleep(2.0)
        with _runner_lock:
            info = RUNNING.get(bot_id)
        if not info or info.get("proc").poll() is not None or int(info.get("proc").pid) != int(pid):
            return
        try:
            rss = int(psutil.Process(pid).memory_info().rss)
        except Exception:
            return
        if rss > limit:
            over += 1
        else:
            over = 0
        # Require several consecutive samples so short-lived spikes do not
        # kill an otherwise healthy bot.
        if over >= 3:
            info["memory_limit_exceeded"] = True
            try:
                log = info.get("log")
                if isinstance(log, list):
                    log.append(f"[{G['warn']}] RAM limit exceeded: {rss // (1024*1024)} MB > {ram_mb} MB; bot stopped")
            except Exception:
                pass
            try:
                bd = find_bot(bot_id)
                if bd:
                    bd["status"] = "crashed"
                    bd["last_error"] = f"RAM limit exceeded ({rss // (1024*1024)} MB > {ram_mb} MB). Upgrade the plan for more RAM."
                    save_bot(bd)
            except Exception:
                pass
            stop_child(bot_id, manual=False)
            return

def start_child(b: Dict[str, Any]) -> Dict[str, Any]:
    bid = str(b["_id"])
    if _is_bot_deleted(bid):
        return {"ok": False, "error": "Bot was deleted."}
    owner_doc = db_load().get("users", {}).get(str(b.get("owner")), {})
    if not user_plan_active(owner_doc):
        return {"ok": False, "error": "Your hosting plan is expired. Upgrade to start this bot."}
    # Approval gate — never start a bot still waiting for admin review.
    if (b or {}).get("approval_status") == "pending":
        return {"ok": False, "error": "Bot is waiting for admin approval."}
    if (b or {}).get("approval_status") == "rejected":
        return {"ok": False, "error": "Bot was rejected by admin."}
    with _runner_lock:
        existing = RUNNING.get(bid)
        if existing and existing["proc"].poll() is None:
            return {"ok": False, "error": "Already running."}
    bot_dir = Path(b["dir"])
    if not bot_dir.exists():
        return {"ok": False, "error": "Bot folder missing."}
    try:
        bot_dir.chmod(0o700)
    except Exception:
        pass

    # decrypt encrypted source files into bot_dir at run time
    try:
        materialize_bot_files(b)
    except Exception as e:
        return {"ok": False, "error": f"decrypt failed: {e}"}

    kind, entry = detect_entry(bot_dir)
    if not kind:
        return {"ok": False, "error": "No entry file (index.js / bot.py)."}

    log: List[str] = [f"{G['div_eq']} START {ts_iso()} {G['div_eq']}"]
    if b.get("status") != "running":
        b.pop("_restart_history", None)
    install_deps(bot_dir, kind, log)
    # Run every untrusted child through secure_exec.py. It disables core
    # dumps/ptrace visibility (PR_SET_DUMPABLE=0 where supported) before
    # exec'ing the real bot, reducing cross-process credential exposure.
    if kind == "node":
        cmd = [sys.executable, str(SECURE_EXEC), "--", "node", entry]
    else:
        cmd = [sys.executable, str(SECURE_EXEC), "--", sys.executable, "-u", entry]

    # Merge/repair saved child ENV.  If BOT_TOKEN is absent from the saved
    # panel variables, the project's own .env files are still valid sources.
    extra_env = _repair_env_dict(dict(b.get("env") or {}))
    local_env = _repair_env_dict(_read_local_env_files(bot_dir))
    for _k, _v in local_env.items():
        extra_env.setdefault(_k, _v)
    if extra_env != (b.get("env") or {}):
        b["env"] = extra_env
        try:
            save_bot(b)
        except Exception:
            pass
    run_env = safe_env(bot_dir, extra_env)
    # Never log the secret itself; only record whether a child token exists.
    if not any(run_env.get(k) for k in ("BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIN_BOT_TOKEN")):
        log.append("[ENV] BOT_TOKEN not found in child panel ENV or local .env")
    # Keep both the project root and the entry file's directory importable.
    # This is important for ZIPs such as MyBot/main.py + database.py.
    entry_parent = (bot_dir / entry).parent
    pp_parts = [str(bot_dir), str(entry_parent), str(bot_dir / ".deps")]
    existing_pp = run_env.get("PYTHONPATH", "")
    if existing_pp:
        pp_parts.append(existing_pp)
    run_env["PYTHONPATH"] = os.pathsep.join(dict.fromkeys(pp_parts))
    try:
        proc = subprocess.Popen(
            cmd, cwd=str(bot_dir), env=run_env,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            preexec_fn=os.setsid if os.name == "posix" else None,
        )
    except Exception as e:
        return {"ok": False, "error": f"spawn: {e}"}

    info = {
        "proc": proc, "kind": kind, "started": time.time() * 1000,
        "log": log, "dir": str(bot_dir), "name": b["name"],
        "owner": b["owner"], "manual_stop": False,
    }
    with _runner_lock:
        RUNNING[bid] = info
    threading.Thread(target=_drain_proc, args=(bid, proc, log), daemon=True).start()

    # Enforce the RAM allowance attached to the owner's active plan.
    try:
        plan_key = str(owner_doc.get("plan", "free") or "free")
        ram_mb = int(PLAN_LIMITS.get(plan_key, PLAN_LIMITS["free"]).get("ram", 0) or 0)
        if psutil is not None and ram_mb > 0:
            threading.Thread(
                target=_watch_child_memory, args=(bid, proc.pid, ram_mb), daemon=True,
            ).start()
    except Exception:
        pass

    # Keep uploaded source/resource files intact while the bot is running.
    # Some legitimate bots import local modules lazily or read config/assets
    # after startup; overwriting .py/.js files after 6 seconds caused silent
    # post-start failures and made /start appear unresponsive.

    # update doc — clear any prior crash so bot view shows clean state
    b["status"] = "running"
    b["last_started"] = ts_iso()
    b["last_error"] = ""
    b["last_exit_code"] = None
    if _is_bot_deleted(bid):
        # Deletion won the race while the child was starting. Stop it and do
        # not recreate the DB record.
        try:
            stop_child(bid, manual=True)
        except Exception:
            pass
        return {"ok": False, "error": "Bot was deleted during startup"}
    save_bot(b)
    return {"ok": True, "pid": proc.pid, "kind": kind}


def stop_child(bot_id: str, manual: bool = True) -> Dict[str, Any]:
    with _runner_lock:
        info = RUNNING.get(bot_id)
    if not info:
        # Even if we don't have it tracked, make sure DB says stopped
        b = find_bot(bot_id)
        if b and b.get("status") != "stopped":
            b["status"] = "stopped"
            save_bot(b)
        return {"ok": True}
    info["manual_stop"] = manual
    proc = info["proc"]

    # Collect every descendant PID *before* we start signalling so a
    # double-fork bot can't escape us.
    child_pids: List[int] = []
    if psutil is not None:
        try:
            parent = psutil.Process(proc.pid)
            for ch in parent.children(recursive=True):
                child_pids.append(ch.pid)
        except Exception:
            pass

    def _kill_pid(pid: int, sig: int) -> None:
        try:
            os.kill(pid, sig)
        except (ProcessLookupError, PermissionError):
            pass
        except Exception:
            pass

    try:
        # 1) polite SIGTERM to the whole process group
        if os.name == "posix":
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                pass
            for pid in child_pids:
                _kill_pid(pid, signal.SIGTERM)
        else:
            proc.terminate()

        # 2) wait briefly — most well-behaved bots exit here
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            # 3) hard SIGKILL the group + every descendant we noted
            if os.name == "posix":
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
                for pid in child_pids:
                    _kill_pid(pid, signal.SIGKILL)
                # one more sweep for any new grand-children spawned
                # between our snapshot and the kill signal
                if psutil is not None:
                    try:
                        for ch in psutil.Process(proc.pid).children(recursive=True):
                            _kill_pid(ch.pid, signal.SIGKILL)
                    except Exception:
                        pass
            else:
                proc.kill()
            try:
                proc.wait(timeout=3)
            except Exception:
                pass
    except ProcessLookupError:
        pass
    except Exception as e:
        # Even on partial failure, drop our handle so the user can
        # try again instead of being stuck "running".
        with _runner_lock:
            RUNNING.pop(bot_id, None)
        b = find_bot(bot_id)
        if b:
            b["status"] = "stopped"
            save_bot(b)
        return {"ok": False, "error": str(e)}

    # Tear down any cloudflared tunnel we opened for this bot
    try:
        _stop_tunnel(bot_id)
    except Exception:
        pass

    with _runner_lock:
        RUNNING.pop(bot_id, None)
    b = find_bot(bot_id)
    if b:
        b["status"] = "stopped"
        save_bot(b)
    return {"ok": True}


# ────────────────────────────── Cloudflared "trycloudflare" tunnels ─
# Premium-only feature: gives a user a public URL like
# https://random-words-1234.trycloudflare.com that proxies straight to
# their bot's local port. We download the official cloudflared binary on
# first use and cache it under ~/.cache/cloudflared so this works on any
# host without the user needing root.

TUNNELS: Dict[str, Dict[str, Any]] = {}     # bot_id -> {proc, port, url, started}
_tunnel_lock = threading.Lock()

CLOUDFLARED_CACHE = Path.home() / ".cache" / "cloudflared"
CLOUDFLARED_BIN   = CLOUDFLARED_CACHE / "cloudflared"

_CF_DOWNLOAD = {
    ("linux",  "x86_64"):  "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
    ("linux",  "aarch64"): "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64",
    ("linux",  "armv7l"):  "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm",
    ("darwin", "x86_64"):  "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tgz",
    ("darwin", "arm64"):   "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-amd64.tgz",
}


def _ensure_cloudflared() -> Optional[Path]:
    """Return path to a working cloudflared binary, downloading once."""
    # Already cached?
    if CLOUDFLARED_BIN.exists() and os.access(CLOUDFLARED_BIN, os.X_OK):
        return CLOUDFLARED_BIN
    # Already on PATH?
    on_path = shutil.which("cloudflared")
    if on_path:
        return Path(on_path)
    # Download a fresh copy
    try:
        import platform
        sysname = platform.system().lower()
        machine = platform.machine().lower()
        url = _CF_DOWNLOAD.get((sysname, machine))
        if not url:
            return None
        CLOUDFLARED_CACHE.mkdir(parents=True, exist_ok=True)
        tmp = CLOUDFLARED_BIN.with_suffix(".part")
        with requests.get(url, stream=True, timeout=120) as r:
            r.raise_for_status()
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(chunk_size=1 << 16):
                    if chunk:
                        f.write(chunk)
        tmp.chmod(0o755)
        tmp.rename(CLOUDFLARED_BIN)
        return CLOUDFLARED_BIN
    except Exception:
        return None


def _port_in_use(port: int) -> bool:
    """True if *something* is already listening on this TCP port."""
    import socket as _s
    for fam, typ, addr in (
        (_s.AF_INET,  _s.SOCK_STREAM, ("127.0.0.1", port)),
        (_s.AF_INET6, _s.SOCK_STREAM, ("::1",       port)),
    ):
        try:
            with _s.socket(fam, typ) as sk:
                sk.settimeout(0.4)
                if sk.connect_ex(addr) == 0:
                    return True
        except Exception:
            continue
    return False


_TRYCLOUDFLARE_RE = re.compile(r"https?://[a-z0-9-]+\.trycloudflare\.com", re.I)


def _start_tunnel(bot_id: str, port: int) -> Dict[str, Any]:
    """Spin up `cloudflared tunnel --url http://localhost:<port>` and
    capture the public trycloudflare URL from its stderr."""
    if not (1 <= port <= 65535):
        return {"ok": False, "error": "Port must be between 1 and 65535"}

    with _tunnel_lock:
        existing = TUNNELS.get(bot_id)
        if existing and existing.get("proc") and existing["proc"].poll() is None:
            return {"ok": False, "error": "Tunnel already running for this bot. Stop it first."}

    if not _port_in_use(port):
        return {"ok": False,
                "error": f"Nothing is listening on port {port}. "
                         f"Start your bot's web server on that port first, "
                         f"or pick another port."}

    bin_path = _ensure_cloudflared()
    if not bin_path:
        return {"ok": False,
                "error": "Could not download cloudflared binary on this host. "
                         "Please install cloudflared manually."}

    log_buf: Deque[str] = deque(maxlen=200)
    try:
        proc = subprocess.Popen(
            [str(bin_path), "tunnel", "--no-autoupdate",
             "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            preexec_fn=os.setsid if os.name == "posix" else None,
        )
    except Exception as e:
        return {"ok": False, "error": f"Failed to launch cloudflared: {e}"}

    rec: Dict[str, Any] = {
        "proc":    proc,
        "port":    port,
        "url":     None,
        "started": int(time.time()),
        "log":     log_buf,
    }
    with _tunnel_lock:
        TUNNELS[bot_id] = rec

    def _drain() -> None:
        assert proc.stdout is not None
        for line in proc.stdout:
            line = line.rstrip()
            log_buf.append(line)
            if rec["url"] is None:
                m = _TRYCLOUDFLARE_RE.search(line)
                if m:
                    rec["url"] = m.group(0)

    threading.Thread(target=_drain, daemon=True, name=f"cf-{bot_id}").start()

    # Wait up to ~15s for the URL to appear
    deadline = time.time() + 15
    while time.time() < deadline and rec["url"] is None and proc.poll() is None:
        time.sleep(0.3)

    if proc.poll() is not None and rec["url"] is None:
        # process died early — usually port issue or network
        tail = "\n".join(list(log_buf)[-6:]) or "(no output)"
        with _tunnel_lock:
            TUNNELS.pop(bot_id, None)
        return {"ok": False, "error": f"cloudflared exited early.\n{tail}"}

    if rec["url"] is None:
        # No URL within 15s and process still alive — kill it so we don't
        # leave an orphan cloudflared process running forever.
        try:
            if os.name == "posix":
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            else:
                proc.terminate()
            try:
                proc.wait(timeout=2)
            except Exception:
                proc.kill()
        except Exception:
            pass
        with _tunnel_lock:
            TUNNELS.pop(bot_id, None)
        tail = "\n".join(list(log_buf)[-6:]) or "(no output)"
        return {"ok": False,
                "error": f"Tunnel timed out — no URL after 15s.\n{tail}"}

    return {"ok": True, "url": rec["url"], "port": port}


def _stop_tunnel(bot_id: str) -> bool:
    with _tunnel_lock:
        rec = TUNNELS.pop(bot_id, None)
    if not rec:
        return False
    proc = rec.get("proc")
    if not proc:
        return True
    try:
        if os.name == "posix":
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            except (ProcessLookupError, PermissionError):
                pass
        else:
            proc.terminate()
        try:
            proc.wait(timeout=3)
        except Exception:
            try:
                if os.name == "posix":
                    os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                else:
                    proc.kill()
            except Exception:
                pass
    except Exception:
        pass
    return True


def restart_child(b: Dict[str, Any]) -> Dict[str, Any]:
    stop_child(b["_id"], manual=True)
    time.sleep(0.5)
    return start_child(b)


def tail_log(bot_id: str, lines: int = 60) -> str:
    """Return the most recent runtime log for a hosted bot.

    The old UI called an undefined tail_log(), which made Live Logs fail
    even when the child process itself was running. Prefer the live ring
    buffer and fall back to the persisted last error after a crash.
    """
    try:
        info = RUNNING.get(bot_id)
        if info:
            entries = list(info.get("log") or [])
            if entries:
                return "\n".join(entries[-max(1, int(lines)):])
        b = find_bot(bot_id)
        if b:
            err = str(b.get("last_error") or "").strip()
            if err:
                return err
    except Exception as e:
        return f"log error: {e}"
    return ""


def child_status(bot_id: str, b_doc: Dict[str, Any]) -> Dict[str, Any]:
    info = RUNNING.get(bot_id)
    running = bool(info and info["proc"].poll() is None)
    bot_dir = Path(b_doc.get("dir") or "")
    kind, _ = detect_entry(bot_dir) if bot_dir.exists() else (None, None)
    sz = 0
    try:
        for root, _, files in os.walk(bot_dir):
            for f in files:
                try:
                    sz += (Path(root) / f).stat().st_size
                except OSError:
                    pass
    except Exception:
        pass
    cpu = mem = 0.0
    if running and psutil is not None:
        try:
            p = psutil.Process(info["proc"].pid)
            cpu = p.cpu_percent(interval=0.05)
            mem = p.memory_info().rss
        except Exception:
            pass
    return {
        "running":   running,
        "pid":       info["proc"].pid if running else None,
        "kind":      (info["kind"] if info else kind) or "—",
        "uptimeMs":  int(time.time() * 1000 - info["started"]) if running else 0,
        "sizeBytes": sz,
        "logs":      info["log"] if info else [],
        "cpuPct":    cpu,
        "memBytes":  mem,
        "sandboxed": True,
    }


# ════════════════════════════════════════════════
# 11. ENCRYPTED  BOT  STORAGE
# ═════════════════════════════════════════════════════

def store_uploaded_file(uploader: types.User, filename: str, plain: bytes, bot_id: str = "") -> Dict[str, Any]:
    """
    Encrypt + persist an uploaded file. Returns metadata describing
    where the encrypted blob lives and which key_id unlocks it.
    """
    safe = safe_name(filename)
    key_id, key, cipher = encrypt_file(plain)
    rel = f"{uploader.id}/{int(time.time())}_{safe}.enc"
    out = DIRS["encfiles"] / rel
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(cipher)

    meta = {
        "filename": filename,
        "uploader_id": uploader.id,
        "uploader_username": uploader.username or "",
        "size": len(plain),
        "uploaded": ts_iso(),
        "stored_at": str(out),
    }
    KEYRING.store(key_id, key, meta)
    # Persist the encrypted bytes outside the ephemeral container too.
    # Failure here is non-fatal for local-only deployments; the normal local
    # ciphertext remains available as a fallback.
    mongo_file_id = _mongo_blob_put(str(bot_id or uploader.id), key_id, filename, cipher)

    # notify_owner HATA DIYA — ab upload handler mein sirf ek summary msg aayega
    result = {"key_id": key_id, "path": str(out), "size": len(plain)}
    if mongo_file_id:
        result["mongo_file_id"] = mongo_file_id
    return result


def materialize_bot_files(b: Dict[str, Any]) -> None:
    """Restore ciphertext from durable Mongo if needed, then decrypt to sandbox."""
    bot_dir = Path(b["dir"])
    bot_dir.mkdir(parents=True, exist_ok=True)
    files = b.get("enc_files") or []
    changed = False
    for f in files:
        # First make sure the encryption key is available. KeyRing now checks
        # Mongo before the ephemeral local cache.
        key = KEYRING.fetch(f["key_id"])
        if not key:
            raise RuntimeError(f"missing key {f['key_id']}")

        enc_path = Path(f.get("enc_path") or "")
        # Redeploys wipe encfiles/. Restore the encrypted blob into the new
        # container and repair its path in the bot metadata.
        if not enc_path.is_file():
            blob = _mongo_blob_get(str(f.get("mongo_file_id") or ""))
            if blob is None:
                # Compatibility: locate by bot/key when older metadata did not
                # yet contain mongo_file_id.
                try:
                    mdb = _mongo_db()
                    if mdb is not None:
                        row = mdb["bot_files.files"].find_one({
                            "metadata.bot_id": str(b.get("_id")),
                            "metadata.key_id": str(f.get("key_id")),
                        })
                        if row and row.get("_id"):
                            f["mongo_file_id"] = str(row["_id"])
                            blob = _mongo_blob_get(f["mongo_file_id"])
                            changed = True
                except Exception:
                    pass
            if blob is None:
                raise RuntimeError(f"uploaded file missing for {f.get('filename')}")
            enc_path.parent.mkdir(parents=True, exist_ok=True)
            enc_path.write_bytes(blob)
            f["enc_path"] = str(enc_path)
            changed = True
        else:
            # If this is an older bot uploaded before Mongo file persistence,
            # migrate its still-available ciphertext now.
            if not f.get("mongo_file_id"):
                fid = _mongo_blob_migrate_local(str(b.get("_id")), f)
                if fid:
                    f["mongo_file_id"] = fid
                    changed = True

        try:
            plain = read_encrypted(enc_path, key)
        except InvalidToken:
            raise RuntimeError(f"key mismatch for {f.get('filename')}")
        rel = f.get("rel_path") or f["filename"]
        rel = rel.lstrip("/")
        try:
            tgt = safe_path_join(bot_dir, rel)
        except ValueError:
            continue
        tgt.parent.mkdir(parents=True, exist_ok=True)
        tgt.write_bytes(plain)
        plain = b""

    for f in files:
        KEYRING.wipe(f["key_id"])
    if changed:
        try:
            save_bot(b)
        except Exception:
            pass


def encrypted_dump_for_download(b: Dict[str, Any]) -> Optional[Path]:
    """Build a zip of the *encrypted* blobs for this bot. Useless without keys."""
    files = b.get("enc_files") or []
    if not files:
        return None
    out = Path(tempfile.gettempdir()) / f"enc_{b['_id']}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            p = Path(f["enc_path"])
            if p.exists():
                z.write(p, arcname=f.get("rel_path") or f["filename"])
        z.writestr(
            "_README.txt",
            f"These files are encrypted with Fernet/AES-128.\n"
            f"They cannot be read without the per-file key, which is\n"
            f"stored in a private GitHub repository owned by {BRAND_TAG}.\n",
        )
    return out



# 12. GITHUB  BACKUP / RESTORE  (panel state)

GH = {
    "token": "", "repo": "", "branch": "main",
    "intervalMin": 360,
    "lastBackup": None, "lastError": None,
    "inProgress": False, "autoEnabled": True,
}


def gh_load_config() -> None:
    GH["token"]  = _HOST_SECRET_ENV.get("GITHUB_TOKEN")  or get_setting("github_token", "")  or ""
    GH["repo"]   = _HOST_SECRET_ENV.get("GITHUB_REPO")   or get_setting("github_repo", "")   or ""
    GH["branch"] = _HOST_SECRET_ENV.get("GITHUB_BRANCH") or get_setting("github_branch", "main") or "main"
    try:
        ivl = int(os.environ.get("GITHUB_AUTO_INTERVAL_MIN") or get_setting("github_interval_min", 360))
    except Exception:
        ivl = 360
    GH["intervalMin"] = ivl if ivl > 0 else 360


def gh_set_config(patch: Dict[str, Any]) -> None:
    keymap = {"token": "github_token", "repo": "github_repo",
              "branch": "github_branch", "intervalMin": "github_interval_min"}
    for k, v in patch.items():
        if k not in keymap:
            continue
        if k == "intervalMin":
            try:
                v = int(v)
            except Exception:
                v = 360
        GH[k] = v
        set_setting(keymap[k], v)


def gh_enabled() -> bool:
    return bool(GH["token"] and GH["repo"] and "/" in GH["repo"])


def gh_status() -> Dict[str, Any]:
    return {
        "enabled":     gh_enabled(),
        "repo":        GH["repo"], "branch": GH["branch"],
        "intervalMin": GH["intervalMin"],
        "autoEnabled": GH["autoEnabled"],
        "lastBackup":  GH["lastBackup"],
        "lastError":   GH["lastError"],
        "inProgress":  GH["inProgress"],
        "tokenSet":    bool(GH["token"]),
        "repoSet":     bool(GH["repo"]),
    }


def _gh(method: str, url: str, **kw) -> requests.Response:
    h = kw.pop("headers", {}) or {}
    h.setdefault("Authorization", f"token {GH['token']}")
    h.setdefault("Accept", "application/vnd.github+json")
    h.setdefault("User-Agent", "kryon-host/1.0")
    return requests.request(method, url, headers=h, timeout=60, **kw)


def _gh_repo_url(p: str = "") -> str:
    return f"https://api.github.com/repos/{GH['repo']}/{p.lstrip('/')}"


def _gh_ensure_branch() -> bool:
    r = _gh("GET", _gh_repo_url(f"branches/{GH['branch']}"))
    if r.status_code == 200:
        return True
    if r.status_code != 404:
        return False
    info = _gh("GET", _gh_repo_url())
    if info.status_code != 200:
        return False
    default = info.json().get("default_branch", "main")
    ref = _gh("GET", _gh_repo_url(f"git/ref/heads/{default}"))
    if ref.status_code != 200:
        return False
    sha = ref.json()["object"]["sha"]
    _gh("POST", _gh_repo_url("git/refs"),
        json={"ref": f"refs/heads/{GH['branch']}", "sha": sha})
    return True


def _gh_put_file(path: str, content: bytes, message: str) -> bool:
    sha: Optional[str] = None
    g = _gh("GET", _gh_repo_url(f"contents/{path}"), params={"ref": GH["branch"]})
    if g.status_code == 200:
        sha = g.json().get("sha")
    elif g.status_code != 404:
        return False
    body: Dict[str, Any] = {
        "message": message, "branch": GH["branch"],
        "content": base64.b64encode(content).decode(),
    }
    if sha:
        body["sha"] = sha
    r = _gh("PUT", _gh_repo_url(f"contents/{path}"), json=body)
    return r.status_code in (200, 201)


def _make_tarball() -> Path:
    tmp = Path(tempfile.gettempdir()) / f"panel-backup-{int(time.time())}.tar.gz"
    excludes = ("node_modules", ".deps", ".tmp_run", "__pycache__")

    def _filter(ti: tarfile.TarInfo) -> Optional[tarfile.TarInfo]:
        if any(x in ti.name.split("/") for x in excludes):
            return None
        if ti.name.endswith(".log"):
            return None
        return ti

    with tarfile.open(tmp, "w:gz") as tf:
        # Backup storage/ — users, bots DB, encrypted files, keys, tickets
        storage_dir = BASE_DIR / "storage"
        if storage_dir.exists():
            tf.add(str(storage_dir), arcname="storage", filter=_filter)
        # NEVER back up sandbox/. It contains decrypted child source and any
        # project-local .env files while a bot is running. The durable backup
        # already contains encrypted uploads under storage/encfiles and the
        # DB metadata; restoring sandbox would create a secret-exfiltration
        # path to GitHub. Runtime directories are recreated on demand.
    return tmp


def gh_backup_now() -> Dict[str, Any]:
    if not gh_enabled():
        return {"ok": False, "error": "Not configured."}
    if GH["inProgress"]:
        return {"ok": False, "error": "Backup already running."}
    GH["inProgress"] = True
    tar: Optional[Path] = None
    try:
        if not _gh_ensure_branch():
            raise RuntimeError(f"Branch {GH['branch']} unavailable")
        tar = _make_tarball()
        buf = tar.read_bytes()
        size_mb = len(buf) / 1024 / 1024
        if size_mb > 95:
            raise RuntimeError(f"Backup {size_mb:.1f} MB > 95 MB GitHub limit")
        ts = ts_iso().replace(":", "-").replace(".", "-")
        ok1 = _gh_put_file("backups/latest.tar.gz", buf, f"chore(panel): backup {ts}")
        ok2 = _gh_put_file(f"backups/{ts}.tar.gz", buf, f"chore(panel): snapshot {ts}")
        manifest = json.dumps({"lastBackup": ts, "sizeBytes": len(buf)}, indent=2)
        _gh_put_file("backups/manifest.json", manifest.encode(), f"chore(panel): manifest {ts}")
        if not (ok1 and ok2):
            raise RuntimeError("upload failed")
        GH["lastBackup"] = ts
        GH["lastError"] = None
        return {"ok": True, "sizeMB": f"{size_mb:.2f}", "ts": ts}
    except Exception as e:
        GH["lastError"] = str(e)
        return {"ok": False, "error": str(e)}
    finally:
        if tar and tar.exists():
            try:
                tar.unlink()
            except Exception:
                pass
        GH["inProgress"] = False


def gh_restore_now(overwrite: bool = True) -> Dict[str, Any]:
    if not gh_enabled():
        return {"ok": False, "error": "Not configured."}
    r = _gh("GET", _gh_repo_url("contents/backups/latest.tar.gz"),
            params={"ref": GH["branch"]})
    if r.status_code == 404:
        return {"ok": False, "error": "No backup found yet."}
    if r.status_code != 200:
        return {"ok": False, "error": f"GitHub HTTP {r.status_code}"}
    buf = base64.b64decode(r.json()["content"])
    tmp = Path(tempfile.gettempdir()) / f"panel-restore-{int(time.time())}.tar.gz"
    tmp.write_bytes(buf)
    try:
        if overwrite:
            # Wipe both storage and sandbox before restoring
            for folder in ("storage", "sandbox"):
                d = BASE_DIR / folder
                if d.exists():
                    for sub in d.iterdir():
                        rmrf(sub)
        with tarfile.open(tmp, "r:gz") as tf:
            _safe_extract_tar(tf, BASE_DIR)
        # Re-create required dirs in case they were missing in backup
        for _p in DIRS.values():
            _p.mkdir(parents=True, exist_ok=True)
        return {"ok": True, "sizeBytes": len(buf)}
    except Exception as e:
        return {"ok": False, "error": str(e)}
    finally:
        try:
            tmp.unlink()
        except Exception:
            pass


def gh_auto_loop() -> None:
    while True:
        try:
            time.sleep(max(60, GH["intervalMin"] * 60))
            if gh_enabled() and GH["autoEnabled"]:
                res = gh_backup_now()
                if not res.get("ok"):
                    err = res.get("error", "unknown")
                    print(f"[gh_auto_loop] backup failed: {err}", flush=True)
                    try:
                        notify_owner(
                            f"<b>{G['warn']} {sc('GitHub auto-backup failed')}</b>\n"
                            f"{bullet('Error', esc(err))}"
                        )
                    except Exception:
                        pass
                else:
                    print(f"[gh_auto_loop] backup ok ({res.get('sizeMB')} MB)",
                          flush=True)
        except Exception as e:
            print(f"[gh_auto_loop] loop error: {e}", flush=True)
            traceback.print_exc()


_GH_UPTIME_BACKUP_THRESHOLD = 10 * 60  # seconds — only back up bots running >=10 min


_GH_USER_DATA_LAST_PUSH = [0.0]


def gh_uptime_backup_loop() -> None:
    """Per-bot GitHub backup that fires only after a bot has been
    running uninterrupted for >=10 minutes. This avoids polluting the
    backup repo with broken uploads / quick test runs.

    Re-syncs a bot only when its encrypted files have been modified
    since the last successful sync (so editing env vars or restarting
    doesn't spam GitHub)."""
    while True:
        try:
            time.sleep(60)
            if not (gh_enabled() and GH.get("autoEnabled", True)):
                continue
            now = time.time()
            # Refresh the master DB index every 5 minutes so plan
            # changes / new users / approval toggles get backed up
            # even if no bot files changed.
            if now - _GH_USER_DATA_LAST_PUSH[0] > 5 * 60:
                try:
                    if gh_sync_user_data():
                        _GH_USER_DATA_LAST_PUSH[0] = now
                except Exception:
                    pass
            with _runner_lock:
                items = list(RUNNING.items())
            for bot_id, info in items:
                proc = info.get("proc")
                if not proc or proc.poll() is not None:
                    continue
                started = info.get("started", now)
                if (now - started) < _GH_UPTIME_BACKUP_THRESHOLD:
                    continue
                b = find_bot(bot_id)
                if not b:
                    continue
                last = float(b.get("gh_synced_at") or 0)
                # Latest mtime across all encrypted files
                file_mtime = 0.0
                for f in b.get("enc_files") or []:
                    p = Path(f.get("enc_path", ""))
                    try:
                        if p.exists():
                            file_mtime = max(file_mtime, p.stat().st_mtime)
                    except Exception:
                        pass
                if last and file_mtime and file_mtime <= last:
                    continue   # nothing new since last successful sync
                try:
                    _gh_sync_bot_files(b)
                    b["gh_synced_at"] = int(now)
                    save_bot(b)
                    print(f"[gh_uptime_backup] synced bot={bot_id} "
                          f"(uptime={int(now - started)}s)", flush=True)
                except Exception as e:
                    print(f"[gh_uptime_backup] {bot_id} failed: {e}", flush=True)
                # Pace the loop: GitHub's contents API rate-limits at
                # ~5000 req/hr per token. With many bots running, hammering
                # the API back-to-back risks 403s. A small inter-bot sleep
                # spreads the load and gives other threads CPU room.
                time.sleep(1.5)
        except Exception as e:
            print(f"[gh_uptime_backup] loop error: {e}", flush=True)
            traceback.print_exc()


def gh_auto_restore_on_boot() -> Optional[Dict[str, Any]]:
    """Restore from GitHub on boot ONLY when local storage is empty.

    Order of preference:
      1) New per-file layout (user_data.json + user_uploads/<uid>/<bid>/...)
      2) Legacy tarball at backups/latest.tar.gz  (full overwrite)

    We never overwrite a non-empty local DB — that would clobber any
    changes the user made between the last sync and this restart.

    Custom admin banner photos (storage/photos/custom_*.png) are ALWAYS
    pulled from GitHub on boot when missing locally — independent of the
    DB-empty check — so a wiped photos folder is rebuilt on restart."""
    if not gh_enabled():
        return None
    if not GH.get("autoEnabled", False):
        return None
    # Always try to repopulate admin-set banner photos first; this is safe
    # because gh_restore_custom_photos() never overwrites an existing local
    # file and only ever touches storage/photos/.
    try:
        photos_res = gh_restore_custom_photos()
        if photos_res.get("ok") and photos_res.get("restored", 0):
            print(f"[gh_restore] photos: {photos_res['restored']} banners restored",
                  flush=True)
    except Exception as _pe:
        print(f"[gh_restore] photos failed: {_pe}", flush=True)
    try:
        if DB_FILE.exists():
            data = json.loads(DB_FILE.read_text(encoding="utf-8") or "{}")
            users = data.get("users") or {}
            bots = data.get("bots") or {}
            if users or bots:
                return {"ok": False, "skip": True,
                        "reason": "local data present, not restoring"}
    except Exception:
        pass
    # Try new layout first
    res = gh_restore_user_uploads()
    if res.get("ok"):
        try:
            print(f"[gh_restore] new-layout: {res.get('bots',0)} bots, "
                  f"{res.get('files',0)} files restored", flush=True)
        except Exception:
            pass
        return res
    # Fallback: legacy tarball
    return gh_restore_now(overwrite=True)

def _gh_bot_dir(b: Dict[str, Any]) -> str:
    """Per-bot folder layout requested by the user:
       user_uploads/<user_id>/<bot_id>/..."""
    return f"user_uploads/{b.get('owner', 0)}/{b['_id']}"


def _gh_get_file(path: str) -> Optional[bytes]:
    if not gh_enabled():
        return None
    try:
        r = _gh("GET", _gh_repo_url(f"contents/{path}"),
                params={"ref": GH["branch"]})
        if r.status_code != 200:
            return None
        return base64.b64decode(r.json()["content"])
    except Exception:
        return None


def _gh_delete_path(path: str, message: str) -> bool:
    """Best-effort delete of a single file path."""
    try:
        r = _gh("GET", _gh_repo_url(f"contents/{path}"),
                params={"ref": GH["branch"]})
        if r.status_code != 200:
            return False
        sha = r.json().get("sha")
        if not sha:
            return False
        d = _gh("DELETE", _gh_repo_url(f"contents/{path}"),
                json={"message": message, "sha": sha, "branch": GH["branch"]})
        return d.status_code in (200, 204)
    except Exception:
        return False


def gh_sync_user_data() -> bool:
    """Push the master DB (user_data.json) to the backup repo. This is
    the single source of truth for users + bot metadata, and is small
    enough that we can re-upload it whenever something stable changes."""
    if not gh_enabled():
        return False
    try:
        if not _gh_ensure_branch():
            return False
        if not DB_FILE.exists():
            return False
        # Never upload the raw database: legacy installs may still contain
        # plaintext child ENV. Re-serialize through the vault first.
        buf = _backup_db_bytes()
        ok = _gh_put_file("user_data.json", buf,
                          f"sync: user_data {ts_iso()}")
        # Settings can contain GitHub tokens from the optional panel config.
        # Back up only non-secret settings.
        if SETTINGS_FILE.exists():
            try:
                safe_settings = _safe_settings_for_backup(settings_load_ro())
                _gh_put_file("settings.json",
                             json.dumps(safe_settings, ensure_ascii=False, indent=2).encode("utf-8"),
                             f"sync: settings {ts_iso()}")
            except Exception:
                pass
        return ok
    except Exception as e:
        print(f"[gh_sync_user_data] {e}")
        return False


def _gh_sync_bot_files(b: Dict[str, Any]) -> None:
    """Per-bot file sync to user_uploads/<owner>/<bot_id>/.
    Triggered from the uptime loop only AFTER the bot has been running
    for >=10 min — so broken/test uploads never reach GitHub."""
    if not gh_enabled():
        return
    try:
        _gh_ensure_branch()
        bot_dir = _gh_bot_dir(b)
        for f in b.get("enc_files") or []:
            p = Path(f["enc_path"])
            if not p.exists():
                continue
            # Use the on-disk filename (already includes timestamp suffix
            # via store_uploaded_file -> "<ts>_<name>.enc")
            gh_path = f"{bot_dir}/{p.name}"
            _gh_put_file(gh_path, p.read_bytes(),
                         f"upload: bot={b['_id']} file={p.name}")
        meta = json.dumps({
            "bot_id":    b["_id"],
            "owner":     b.get("owner"),
            "name":      b.get("name"),
            "enc_files": b.get("enc_files", []),
            "env_keys":  sorted((b.get("env") or {}).keys()),
            "cron":      b.get("cron", {}),
            "status":    b.get("status"),
            "created":   b.get("created"),
            "synced":    ts_iso(),
        }, indent=2).encode()
        _gh_put_file(f"{bot_dir}/bot_meta.json", meta,
                     f"meta: bot={b['_id']}")
        # Each successful per-bot sync also pushes the latest user_data.json
        # so that on a full restore we get an up-to-date users + bots index.
        gh_sync_user_data()
    except Exception as e:
        print(f"[gh_sync] {e}")


def _gh_delete_bot_files(b: Dict[str, Any]) -> None:
    if not gh_enabled():
        return
    try:
        bot_dir = _gh_bot_dir(b)
        for f in b.get("enc_files") or []:
            p = Path(f["enc_path"])
            _gh_delete_path(f"{bot_dir}/{p.name}",
                            f"delete: bot={b['_id']} file={p.name}")
        _gh_delete_path(f"{bot_dir}/bot_meta.json",
                        f"delete: bot={b['_id']} meta")
    except Exception as e:
        print(f"[gh_delete] {e}")


def _gh_list_dir(path: str) -> List[Dict[str, Any]]:
    """List immediate children of a directory in the repo."""
    if not gh_enabled():
        return []
    try:
        r = _gh("GET", _gh_repo_url(f"contents/{path}"),
                params={"ref": GH["branch"]})
        if r.status_code != 200:
            return []
        data = r.json()
        return data if isinstance(data, list) else []
    except Exception:
        return []


def gh_restore_user_uploads() -> Dict[str, Any]:
    """Restore the new-style backup: user_data.json + the per-bot
    encrypted files under user_uploads/<uid>/<bot_id>/*.

    Falls back gracefully if the layout isn't present (e.g. a fresh
    repo) — caller can then try the legacy tarball restore."""
    if not gh_enabled():
        return {"ok": False, "error": "Not configured."}
    user_data = _gh_get_file("user_data.json")
    if user_data is None:
        return {"ok": False, "error": "No user_data.json in repo (new-style backup not found)."}
    files_restored = 0
    bots_restored = 0
    try:
        # 1) Restore the master DB first so we know which bots/owners exist.
        DB_FILE.parent.mkdir(parents=True, exist_ok=True)
        DB_FILE.write_bytes(user_data)
        _cache_invalidate(DB_FILE)
        # Restore settings if present
        s_buf = _gh_get_file("settings.json")
        if s_buf is not None:
            SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
            SETTINGS_FILE.write_bytes(s_buf)
            _cache_invalidate(SETTINGS_FILE)
        # 2) Walk every bot in the DB and pull its encrypted files back.
        db = db_load()
        for bot_id, b in (db.get("bots") or {}).items():
            owner = b.get("owner") or 0
            bot_dir_local = Path(b.get("dir") or (DIRS["sandbox"] / f"{owner}_{bot_id}"))
            bot_dir_local.mkdir(parents=True, exist_ok=True)
            gh_dir = f"user_uploads/{owner}/{bot_id}"
            entries = _gh_list_dir(gh_dir)
            for ent in entries:
                name = ent.get("name") or ""
                if not name.endswith(".enc"):
                    continue  # bot_meta.json etc. handled separately
                buf = _gh_get_file(f"{gh_dir}/{name}")
                if buf is None:
                    continue
                # Restore encrypted blob to its original location
                # (DIRS["encfiles"]/<owner>/<filename>.enc) so that the
                # paths stored inside enc_files[].enc_path keep working.
                target_dir = DIRS["encfiles"] / str(owner)
                target_dir.mkdir(parents=True, exist_ok=True)
                (target_dir / name).write_bytes(buf)
                files_restored += 1
            bots_restored += 1
        return {"ok": True, "bots": bots_restored, "files": files_restored}
    except Exception as e:
        return {"ok": False, "error": f"restore error: {e}"}


# 13. NOTIFY OWNER  /  ANNOUNCEMENTS

def notify_owner(html: str) -> None:
    if not OWNER_ID:
        return
    try:
        bot.send_message(OWNER_ID, html, parse_mode="HTML")
    except Exception as e:
        print(f"[notify_owner] {e}")


def _message_contains_secret(message: Optional[types.Message]) -> bool:
    """Return True if a Telegram message appears to contain credentials/ENV."""
    if message is None:
        return False
    text = "\n".join(filter(None, [getattr(message, "text", None), getattr(message, "caption", None)]))
    if re.search(r"(?im)^\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_]*\s*=", text):
        return True
    if _SEC_TOKEN_RE.search(text):
        return True
    return bool(re.search(r"(?i)\b(?:api[_-]?hash|session(?:_string)?|password|secret|private[_-]?key|api[_-]?key)\s*[=:]", text))


def _safe_forward_message(chat_id: Any, from_chat_id: Any, message: Optional[types.Message]) -> bool:
    """Forward only messages that do not look like ENV/credential payloads."""
    if _message_contains_secret(message):
        return False
    try:
        bot.forward_message(chat_id, from_chat_id, message.message_id)
        return True
    except Exception:
        return False


def _normalize_chat_ref(value: Any) -> Any:
    """Convert public t.me URLs to Telegram @username chat references."""
    try:
        v = str(value or "").strip()
        if v.startswith("https://t.me/") or v.startswith("http://t.me/"):
            tail = v.split("t.me/", 1)[1].strip("/")
            # Invite links (+xxxx) are not valid send_message chat refs.
            if tail and not tail.startswith("+") and "/" not in tail:
                return "@" + tail.lstrip("@")
        return value
    except Exception:
        return value


def post_announcement(html: str) -> None:
    if not ANNOUNCE_CHANNEL:
        return
    try:
        bot.send_message(_normalize_chat_ref(ANNOUNCE_CHANNEL), html, parse_mode="HTML")
    except Exception as e:
        print(f"[announce] {e}")



# 14. USER  MANAGEMENT

def get_or_create_user(u: types.User, ref: Optional[int] = None) -> Tuple[Dict[str, Any], bool]:
    db = db_load()
    key = str(u.id)
    is_new = key not in db["users"]
    if is_new:
        db["users"][key] = {
            "_id": u.id, "name": u.first_name or "", "username": u.username or "",
            "plan": "free", "plan_expires": None,
            "joined": ts_iso(), "last_seen": ts_iso(),
            "banned": False, "ban_reason": "",
            "wallet": 0, "kyc": False,
            "purchases": [],
            "verified": False, "verified_at": None,
            "ref_by": ref if ref and ref != u.id else None,
            "ref_count": 0, "ref_credit": 0, "trial_used": False,
            "bot_slots_bonus": 0,
            "stats": {"commands": 0, "bots_uploaded": 0, "logins": 1},
        }
        db_save(db)
        if ref and ref != u.id and str(ref) in db["users"]:
            db["users"][str(ref)]["ref_count"] = int(db["users"][str(ref)].get("ref_count", 0)) + 1
            db["users"][str(ref)]["ref_credit"] = int(db["users"][str(ref)].get("ref_credit", 0)) + 1
            db["users"][str(ref)]["bot_slots_bonus"] = int(
                db["users"][str(ref)].get("bot_slots_bonus", 0)) + 1
            db_save(db)
            try:
                bot.send_message(
                    ref,
                    f"<b>{G['plus']} {sc('You earned a referral bonus')}</b>\n"
                    f"{bullet('From', f'@{u.username or u.first_name}')}\n"
                    f"{bullet('Bonus', '+1 bot slot, +1 wallet credit')}",
                )
            except Exception:
                pass
        notify_owner(
            f"<b>{G['plus']} {sc('New user joined')}</b>\n"
            f"{bullet('Name', u.first_name)}\n"
            f"{bullet('Username', '@' + (u.username or '—'))}\n"
            f"{bullet('User ID', u.id)}"
        )
    else:
        db["users"][key]["last_seen"] = ts_iso()
        db["users"][key]["stats"]["logins"] = int(
            db["users"][key]["stats"].get("logins", 0)) + 1
        db_save(db)
    return db["users"][key], is_new


def list_user_bots(uid: int) -> List[Dict[str, Any]]:
    # Return deep-copies so callers can mutate without corrupting the
    # shared cache.
    return [copy.deepcopy(b) for b in db_load_ro()["bots"].values()
            if b.get("owner") == uid]


def _env_sidecar_path(bot_id: str) -> Path:
    # ENV is kept in a dedicated encrypted sidecar so unrelated DB writes can
    # never accidentally replace a bot's secrets with a stale bot document.
    return DIRS["bot_data"] / f"{bot_id}.env.enc"


def _write_env_sidecar(bot_id: str, env: Dict[str, Any]) -> None:
    clean = _repair_env_dict(env or {})
    payload = json.dumps(clean, ensure_ascii=False, separators=(",", ":"))
    _atomic_write(_env_sidecar_path(bot_id), _vault_encrypt(payload))


def _read_env_sidecar(bot_id: str) -> Dict[str, str]:
    path = _env_sidecar_path(bot_id)
    if not path.exists():
        return {}
    try:
        raw = path.read_text(encoding="utf-8")
        decoded = _vault_decrypt(raw)
        data = json.loads(decoded)
        return _repair_env_dict(data if isinstance(data, dict) else {})
    except Exception:
        return {}


def find_bot(bot_id: str) -> Optional[Dict[str, Any]]:
    b = db_load_ro()["bots"].get(bot_id)
    if b is None:
        return None
    out = copy.deepcopy(b)
    sidecar = _read_env_sidecar(bot_id)
    db_env = _repair_env_dict(out.get("env") or {})
    # Sidecar is authoritative when it has a complete ENV map. This prevents
    # a stale DB bot document from making the UI show zero variables after a
    # successful ENV save. DB remains a compatibility/backup copy.
    if sidecar:
        db_env.update(sidecar)
    out["env"] = db_env
    out["env_keys"] = sorted(db_env.keys(), key=str.upper)
    return out


def save_bot(doc: Dict[str, Any]) -> Dict[str, Any]:
    """Persist a bot without allowing stale workers to resurrect deletions.

    ENV is independently managed by _persist_bot_env().  Runtime status updates
    often operate on older copies of a bot document.  A persistent delete
    tombstone is checked before *any* save, so a late worker callback cannot
    recreate a record that the user already removed.
    """
    bid = str(doc["_id"])
    if _is_bot_deleted(bid):
        # Deliberately do not raise: background threads may call save_bot()
        # after deletion. Returning the document keeps those workers harmless.
        return doc
    with _db_lock:
        d = _cached_load(DB_FILE, {})
        d = _ensure_db_defaults(copy.deepcopy(d))
    existing = d.get("bots", {}).get(bid) or {}
    incoming = copy.deepcopy(doc)

    existing_env = _repair_env_dict(existing.get("env") or {})
    incoming_env = _repair_env_dict(incoming.get("env") or {})
    sidecar_env = _read_env_sidecar(bid)

    # Prefer the dedicated ENV vault.  If the caller has a real non-empty ENV
    # map, merge it in; never let an empty/stale runtime copy clear the vault.
    authoritative_env = dict(existing_env)
    if sidecar_env:
        authoritative_env.update(sidecar_env)
    if incoming_env:
        authoritative_env.update(incoming_env)
    incoming["env"] = authoritative_env
    incoming["env_keys"] = sorted(authoritative_env.keys(), key=str.upper)

    d["bots"][bid] = incoming
    # We already hold _db_lock; write directly to avoid releasing the lock
    # between the read and write. This prevents concurrent status updates from
    # losing a deletion or another bot's update.
    protected_db = _encrypt_db_copy(d)
    _atomic_write(DB_FILE, protected_db)
    _cache_invalidate(DB_FILE)
    _mongo_put("db", protected_db)
    try:
        _write_env_sidecar(bid, authoritative_env)
    except Exception:
        pass
    # Per-bot JSON backup
    try:
        bot_json = DIRS["bot_data"] / f"{doc['_id']}.json"
        _atomic_write(bot_json, {
            "bot_id":    doc["_id"],
            "owner":     doc.get("owner"),
            "name":      doc.get("name"),
            "status":    doc.get("status"),
            "env":       {},  # secrets are stored only in encrypted panel DB
            "env_keys":  sorted((doc.get("env") or {}).keys()),
            "cron":      doc.get("cron", {}),
            "enc_files": doc.get("enc_files", []),
            "dir":       doc.get("dir"),
            "created":   doc.get("created"),
            "last_started": doc.get("last_started"),
            "updated":   ts_iso(),
        })
    except Exception:
        pass
    return doc


def delete_bot_doc(bot_id: str) -> None:
    # Mark the id BEFORE touching the DB. Any worker that wakes between the
    # stop request and the DB deletion is therefore prevented from saving the
    # stale document back.
    _mark_bot_deleted(bot_id)
    with _db_lock:
        d = _cached_load(DB_FILE, {})
        d = _ensure_db_defaults(copy.deepcopy(d))
        d["bots"].pop(str(bot_id), None)
        protected_db = _encrypt_db_copy(d)
        _atomic_write(DB_FILE, protected_db)
        _cache_invalidate(DB_FILE)
        _mongo_put("db", protected_db)
    # Remove local metadata/ENV. Source files are intentionally left alone for
    # the existing "Delete Record" semantics; Delete Everything removes them.
    try:
        (DIRS["bot_data"] / f"{bot_id}.json").unlink(missing_ok=True)
        _env_sidecar_path(bot_id).unlink(missing_ok=True)
    except Exception:
        pass


def user_max_bots(u: Dict[str, Any]) -> int:
    # Expired subscriptions immediately fall back to Free limits. Lifetime
    # remains active because user_plan_active() treats it as non-expiring.
    plan = str(u.get("plan", "free") or "free")
    if not user_plan_active(u):
        plan = "free"
    default = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])["max_bots"]
    # Honor admin override from Settings → Plans Editor.
    base = int(get_setting(f"plan_max_bots_{plan}", default))
    return base + int(u.get("bot_slots_bonus", 0))


def user_plan_active(u: Dict[str, Any]) -> bool:
    """Return whether the user's current plan is usable.

    Lifetime plans intentionally have no expiry timestamp, so a missing
    ``plan_expires`` value is valid for lifetime and must not be treated as
    expired.
    """
    plan = str(u.get("plan", "free") or "free").lower()
    if plan in {"free", "lifetime"}:
        return True
    exp = u.get("plan_expires")
    if not exp:
        return False
    try:
        return datetime.fromisoformat(str(exp).replace("Z", "+00:00")) > now_utc()
    except Exception:
        return False


def downgrade_expired_users() -> None:
    d = db_load()
    changed = False
    for uid, u in d["users"].items():
        if u.get("plan") == "free":
            continue
        if not user_plan_active(u):
            u["plan"] = "free"
            u["plan_expires"] = None
            changed = True
            try:
                bot.send_message(
                    int(uid),
                    f"<b>{G['warn']} {sc('Plan expired')}</b>\n\n"
                    f"Your plan has expired. You have been downgraded to <b>Free</b>.\n"
                    f"Renew anytime from the Buy Plan menu.{FOOTER}",
                )
            except Exception:
                pass
    if changed:
        db_save(d)


def expiry_reminders() -> None:
    d = db_load()
    today = now_utc()
    for uid, u in d["users"].items():
        if u.get("plan") == "free":
            continue
        exp = u.get("plan_expires")
        if not exp:
            continue
        try:
            ed = datetime.fromisoformat(str(exp).replace("Z", "+00:00"))
        except Exception:
            continue
        days_left = (ed - today).days
        last_warn = u.get("last_expiry_warn", -1)
        for threshold in (7, 3, 1):
            if days_left == threshold and last_warn != threshold:
                try:
                    bot.send_message(
                        int(uid),
                        f"<b>{G['warn']} {sc('Plan ending soon')}</b>\n\n"
                        f"Your <b>{esc(PLAN_LIMITS.get(u['plan'], {}).get('name'))}</b> plan "
                        f"expires in <b>{days_left} day(s)</b>.\n"
                        f"Renew now to avoid downgrade.{FOOTER}",
                    )
                    u["last_expiry_warn"] = threshold
                    db_save(d)
                except Exception:
                    pass


def _record_purchased_plan(uid: int, plan: str, payment: Optional[Dict[str, Any]] = None) -> None:
    """Persist a successful plan purchase on the user's account.

    This is purchase history, separate from the currently active plan.  It is
    deliberately keyed by payment id so retries/callbacks cannot duplicate a
    purchase.
    """
    if plan not in PLAN_LIMITS:
        return
    d = db_load()
    u = d.get("users", {}).get(str(uid))
    if not u:
        return
    purchases = u.setdefault("purchases", [])
    payment_id = str((payment or {}).get("id") or "")
    if payment_id and any(str(x.get("payment_id")) == payment_id for x in purchases):
        return
    purchases.append({
        "payment_id": payment_id or None,
        "plan": plan,
        "plan_name": PLAN_LIMITS[plan].get("name", plan),
        "amount": float((payment or {}).get("amount", PLAN_LIMITS[plan].get("price", 0)) or 0),
        "method": (payment or {}).get("method"),
        "purchased_at": ts_iso(),
        "status": "completed",
    })
    # Keep history bounded while retaining enough history for the account.
    if len(purchases) > 100:
        u["purchases"] = purchases[-100:]
    db_save(d)


def grant_plan(uid: int, plan: str, days: Optional[int] = None) -> bool:
    d = db_load()
    key = str(uid)
    if key not in d["users"] or plan not in PLAN_LIMITS:
        return False
    u = d["users"][key]
    pl = PLAN_LIMITS[plan]
    days = days if days is not None else pl["days"]
    if plan == "free":
        u["plan"] = "free"
        u["plan_expires"] = None
    elif plan == "lifetime":
        u["plan"] = plan
        u["plan_expires"] = None
        u["last_expiry_warn"] = -1
    else:
        old_plan = u.get("plan", "free")
        expires = u.get("plan_expires")
        try:
            cur_exp = datetime.fromisoformat(str(expires or "").replace("Z", "+00:00"))
        except Exception:
            cur_exp = now_utc()
        # A different/expired plan starts a fresh subscription; the same
        # active plan is extended from its existing expiry.
        if old_plan != plan or cur_exp <= now_utc():
            cur_exp = now_utc()
        u["plan"] = plan
        u["plan_expires"] = (cur_exp + timedelta(days=int(days))).isoformat()
        u["last_expiry_warn"] = -1
    db_save(d)
    try:
        bot.send_message(
            uid,
            f"<b>{G['ok']} {sc('Plan activated')}</b>\n\n"
            f"{bullet('Plan', pl['name'])}\n"
            f"{bullet('Bots',  pl['max_bots'])}\n"
            f"{bullet('RAM',   '{} MB'.format(pl['ram']))}\n"
            f"{bullet('Until', fmt_ts(u.get('plan_expires')) if u.get('plan_expires') else 'Lifetime')}"
            f"{FOOTER}",
        )
    except Exception:
        pass
    return True


# ═════════════════════════════════════════════════════════════════
# 15. CALLBACK / HANDLER  COMMON HELPERS
# ═════════════════════════════════════════════════════════════════

def ack(call: types.CallbackQuery, text: str = "") -> None:
    """Always acknowledge a callback; never let an ack failure hide routing."""
    try:
        bot.answer_callback_query(call.id, text=text or "")
    except Exception as e:
        print(f"[callback] answer failed: {e}", flush=True)


# ── Animated progress-bar loading indicator ──────────────────────
# Active per-message animations live here so we can stop them when the
# real menu re-renders. Key: (chat_id, message_id) → threading.Event.
_LOADING_STOPS: Dict[Tuple[int, int], "threading.Event"] = {}
_LOADING_LOCK = threading.Lock()




def _cancel_loading(chat_id: int, message_id: int) -> None:
    """Stop any animation thread attached to this message."""
    with _LOADING_LOCK:
        evt = _LOADING_STOPS.pop((chat_id, message_id), None)
    if evt:
        evt.set()


def loading(call: types.CallbackQuery, label: str = "Loading") -> None:
    """Show an animated progress bar (▓▓▓░░░ 45 %) the instant a slow
    callback starts, so the user sees their tap was received.

    The bar is rendered into the same message that triggered the
    callback (caption-edit for photo menus, text-edit for plain
    messages) and is then advanced by a daemon thread until the
    handler finishes. The next show_menu / show_text call on that
    message stops the animation automatically — handlers do not need
    to call anything to clean up.
    """
    if not (call and call.message):
        try:
            bot.answer_callback_query(call.id, text=f"⏳ {label}…")
        except Exception:
            pass
        return

    chat_id = call.message.chat.id
    msg_id = call.message.message_id
    is_photo = call.message.content_type == "photo"
    label_safe = esc(label)

    # Cancel any previous animation on this message before starting a
    # new one (defensive — show_menu also cancels on re-render).
    _cancel_loading(chat_id, msg_id)

    # Toast on the button itself.
    try:
        bot.answer_callback_query(call.id, text=f"↻ {label}…")
    except Exception:
        pass

    def _render(pct: int) -> bool:
        """Push the current bar to Telegram. Returns False if the
        message can no longer be edited (deleted, replaced, etc.) so
        the caller can stop the animation early."""
        body = (
            f"<b>↻ {label_safe}…</b>\n"
            f"{G['div']}\n"
            f"<code>{_progress_bar(pct)}</code>\n"
            f"<i>{sc('Please wait')}</i>{FOOTER}"
        )
        try:
            if is_photo:
                bot.edit_message_caption(
                    body, chat_id=chat_id, message_id=msg_id,
                    parse_mode="HTML",
                )
            else:
                bot.edit_message_text(
                    body, chat_id=chat_id, message_id=msg_id,
                    parse_mode="HTML", disable_web_page_preview=True,
                )
            return True
        except ApiTelegramException as e:
            s = str(e).lower()
            if "message is not modified" in s:
                return True
            if "message to edit not found" in s or "message can't be edited" in s:
                return False
            return True
        except Exception:
            return True

    # Register the stop event BEFORE the first render so a very fast handler
    # can never finish between the initial edit and event registration.
    stop_evt = threading.Event()
    with _LOADING_LOCK:
        _LOADING_STOPS[(chat_id, msg_id)] = stop_evt

    # Initial frame: visible feedback within ~1 telegram round-trip.
    if not _render(15):
        _cancel_loading(chat_id, msg_id)
        return

    def _animate() -> None:
        # Advance from 15% → ~92% over a few seconds. We never reach
        # 100% on our own — the handler completing and re-rendering is
        # the real "done" signal.
        steps = [25, 38, 52, 65, 78, 88, 92]
        for pct in steps:
            if stop_evt.wait(0.7):
                return
            if not _render(pct):
                return
        # Hold at 92% until cancelled.
        while not stop_evt.wait(1.5):
            pass

    threading.Thread(target=_animate, daemon=True).start()


def admin_only_call(call: types.CallbackQuery, action: str = "view_stats") -> bool:
    if not is_admin(call.from_user.id):
        ack(call, "Owner / admin only.")
        return False
    if not admin_can(call.from_user.id, action):
        ack(call, "Insufficient permission.")
        return False
    return True


def maintenance_block(uid: int) -> bool:
    """Return True if user is blocked by maintenance mode."""
    if get_setting("maintenance", False) and not is_admin(uid):
        return True
    return False


def banned_block(call_or_msg: Any) -> bool:
    uid = call_or_msg.from_user.id
    u = db_load_ro()["users"].get(str(uid))
    if u and u.get("banned"):
        try:
            chat = call_or_msg.message.chat.id if hasattr(call_or_msg, "message") else call_or_msg.chat.id
            bot.send_message(
                chat,
                f"<b>{G['no']} {sc('You are banned')}</b>\n"
                f"{bullet('Reason', u.get('ban_reason') or '—')}\n"
                f"Contact {SUPPORT_USR} to appeal.",
            )
        except Exception:
            pass
        return True
    return False


# ═════════════════════════════════════════════════════════════════
# 15.5  HUMAN VERIFICATION  (captcha + animated progress bar)
# ═════════════════════════════════════════════════════════════════
#
# Flow on a brand-new user's first /start:
#   1. an "loading 10% → 100%" progress bar (one message, edited live)
#   2. a CAPTCHA photo: 4 random characters, ONE has a red circle on it
#   3. inline buttons (the 4 chars + 2 distractors, shuffled) — user
#      must tap the *circled* one
#   4. on success → user.verified = True, main menu shown
# After verification the captcha is never shown again for that user.

VERIFY_STATES: Dict[int, Dict[str, Any]] = {}
_verify_lock = threading.Lock()

# Visually unambiguous alphanumeric pool (no I/O/0/1, no Q vs O confusion)
_CAPTCHA_POOL = "ABCDEFGHJKLMNPRSTUVWXYZ23456789"

# Try a few well-known TTF locations; fall back to PIL's default bitmap
_CAPTCHA_FONT_PATHS = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)














# ─── Group Join Verification ─────────────────────────────────────
# No legacy third-party groups are required by the KRYON_HOST build.
# Add your own groups here only if you intentionally want join verification.
REQUIRED_GROUPS = []



# ─────────────────────────────────────────────────────────────────







# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# ═════════════════════════════════════════════════════════════════
# 16. /start  AND  MAIN MENU
# ═════════════════════════════════════════════════════════════════



# ─── Silent mode in groups — bot will not respond in any group/channel ───────
# ─────────────────────────────────────────────────────────────────────────────

# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# ═════════════════════════════════════════════════════════════════
# 17. CALLBACK ROUTER  (top level)
# ═════════════════════════════════════════════════════════════════

# ─── callback de-duplication ─────────────────────────────────────
# Telegram occasionally re-delivers the same callback (rapid double-clicks,
# leftover webhook still active alongside polling, two bot instances polling
# the same token, etc.). We keep a tiny in-memory cache of recently-seen
# callback IDs and silently drop duplicates so the user only ever sees a
# single response per button press.
_CB_SEEN: "deque[Tuple[str, float]]" = deque(maxlen=512)
_CB_SEEN_LOCK = threading.Lock()
_CB_DEDUP_WINDOW = 12.0  # seconds




# Legacy duplicate registration disabled.





# ═════════════════════════════════════════════════════════════════
# 18. MENU RENDERS
# ═════════════════════════════════════════════════════════════════









































# ═════════════════════════════════════════════════════════════════
# 19. BOT MANAGEMENT VIEWS
# ═════════════════════════════════════════════════════════════════











































# ═════════════════════════════════════════════════════════════════
# 20. ADMIN PANEL  RENDERS
# ═════════════════════════════════════════════════════════════════































def render_adm_photo_one(call: types.CallbackQuery, key: str) -> None:
    """Prompt the admin to send the next photo as the banner for `key`."""
    if not is_owner(call.from_user.id) and not admin_can(call.from_user.id, "manage_admins"):
        ack(call, "Owner / full-access only.")
        return
    if key not in _PHOTO_SPECS:
        ack(call, "Unknown photo key.")
        return
    USER_STATES[call.from_user.id] = {"flow": "await_admin_photo", "photo_key": key}
    label = PHOTO_KEYS_FRIENDLY.get(key, key)
    cap = (
        f"<b>{G['upload']} {sc('Replace banner')}: {esc(label)}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send the new photo now (as a photo, not a file)')}.\n"
        f"{sc('Send /cancel to abort')}.\n"
        f"{G['div']}{FOOTER}"
    )
    # Show the current banner so the admin sees what they're replacing.
    cur = PHOTOS.get(key) or PHOTOS.get("admin", "")
    show_menu(call.message.chat.id, cur, cap, back_admin_kb(), call=call)






def _gh_backup_thread(call: types.CallbackQuery) -> None:
    res = gh_backup_now()
    msg = (f"{G['ok']} {sc('backup ok')} ({res.get('sizeMB')} MB)"
           if res["ok"] else f"{G['no']} {esc(res.get('error'))}")
    try:
        bot.send_message(call.message.chat.id, msg)
    except Exception:
        pass


def _gh_restore_thread(call: types.CallbackQuery) -> None:
    res = gh_restore_now(overwrite=True)
    msg = (f"{G['ok']} {sc('restore ok')} ({fmt_bytes(res.get('sizeBytes', 0))})"
           if res["ok"] else f"{G['no']} {esc(res.get('error'))}")
    try:
        bot.send_message(call.message.chat.id, msg)
    except Exception:
        pass








# ───────────────────────────────────────────────────────────────────
#  Advanced settings — sub-renderers + handlers
# ───────────────────────────────────────────────────────────────────

def _set_back_kb() -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(
        f"{G['back']}  {sc('Settings')}", callback_data="adm_settings"))
    return kb










# ═══════════════════════════════════════════════════════════════════
#  ADVANCED ADMIN SUB-PANELS  (35+ new features)
# ═══════════════════════════════════════════════════════════════════

def _adm_back(dest: str = "menu_admin") -> types.InlineKeyboardMarkup:
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{G['back']}  {sc('Back')}", callback_data=dest, style="primary"))
    return kb


# ─── 1. ANALYTICS ────────────────────────────────────────────────────────────

def render_adm_analytics(call: types.CallbackQuery) -> None:
    d = db_load()
    total_rev = sum(p.get("amount", 0) for p in d["payments"] if p.get("status") == "approved")
    running_n = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    cap = (
        f"<b>📊 {sc('Analytics Dashboard')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Revenue',   money(total_rev))}\n"
        f"{bullet('Total Users',     len(d['users']))}\n"
        f"{bullet('Total Bots',      len(d['bots']))}\n"
        f"{bullet('Bots Running',    running_n)}\n"
        f"{G['div']}\n{sc('Choose a report below')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📈  Rᴇᴠᴇɴᴜᴇ Rᴇᴘᴏʀᴛ",  callback_data="adm_revenue_report", style="success"),
        Btn("📉  Gʀᴏᴡᴛʜ Sᴛᴀᴛꜱ",    callback_data="adm_growth_stats",   style="primary"),
    )
    kb.add(
        Btn("🏆  Tᴏᴘ Uꜱᴇʀꜱ",       callback_data="adm_top_users",      style="primary"),
        Btn("🥧  Pʟᴀɴ Dɪꜱᴛ",       callback_data="adm_plan_dist",      style="primary"),
    )
    kb.add(
        Btn("🤖  Bᴏᴛ Aᴄᴛɪᴠɪᴛʏ",   callback_data="adm_bot_activity",   style="primary"),
        Btn("📊  Sᴛᴀᴛꜱ Oᴠᴇʀᴠɪᴇᴡ",  callback_data="adm_stats",          style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_revenue_report(call: types.CallbackQuery) -> None:
    pays = db_load()["payments"]
    now = now_utc()
    today   = now.strftime("%Y-%m-%d")
    week_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d")
    month_ago = (now - timedelta(days=30)).strftime("%Y-%m-%d")
    def _sum(since: str) -> float:
        return sum(p.get("amount", 0) for p in pays
                   if p.get("status") == "approved" and str(p.get("ts", "")) >= since)
    rev_day   = _sum(today)
    rev_week  = _sum(week_ago)
    rev_month = _sum(month_ago)
    rev_all   = sum(p.get("amount", 0) for p in pays if p.get("status") == "approved")
    plan_rev: Dict[str, float] = defaultdict(float)
    for p in pays:
        if p.get("status") == "approved":
            plan_rev[p.get("plan", "unknown")] += p.get("amount", 0)
    by_plan = "\n".join(f"{bullet(k, money(v))}" for k, v in sorted(plan_rev.items()))
    cap = (
        f"<b>📈 {sc('Revenue Report')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Today',        money(rev_day))}\n"
        f"{bullet('Last 7 days',  money(rev_week))}\n"
        f"{bullet('Last 30 days', money(rev_month))}\n"
        f"{bullet('All time',     money(rev_all))}\n"
        f"{G['div']}\n<b>{sc('By Plan')}:</b>\n{by_plan}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_analytics"), call=call)


def render_adm_growth_stats(call: types.CallbackQuery) -> None:
    users = db_load()["users"].values()
    now = now_utc()
    def _count(days: int) -> int:
        since = (now - timedelta(days=days)).strftime("%Y-%m-%d")
        return sum(1 for u in users if str(u.get("joined", "")) >= since)
    bar = lambda n, mx: "█" * int(n / max(mx, 1) * 10) + "░" * (10 - int(n / max(mx, 1) * 10))
    d1, d7, d30, all_ = _count(1), _count(7), _count(30), len(list(users))
    cap = (
        f"<b>📉 {sc('User Growth')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Today',        f'{d1}  {bar(d1, d30)}')}\n"
        f"{bullet('Last 7 days',  f'{d7}  {bar(d7, all_)}')}\n"
        f"{bullet('Last 30 days', f'{d30}  {bar(d30, all_)}')}\n"
        f"{bullet('Total users',  all_)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_analytics"), call=call)


def render_adm_top_users(call: types.CallbackQuery) -> None:
    d = db_load()
    pays = d["payments"]
    spend: Dict[str, float] = defaultdict(float)
    for p in pays:
        if p.get("status") == "approved":
            spend[str(p.get("uid", ""))] += p.get("amount", 0)
    top = sorted(spend.items(), key=lambda x: x[1], reverse=True)[:10]
    rows = []
    for i, (uid, amt) in enumerate(top, 1):
        u = d["users"].get(uid, {})
        name = esc(u.get("name") or uid)
        bot_count = sum(1 for b in d["bots"].values() if str(b.get("owner")) == uid)
        rows.append(f"{i}. {name} — <b>{money(amt)}</b> {G['bullet']} {bot_count} bots")
    cap = (
        f"<b>🏆 {sc('Top Users by Spending')}</b>\n"
        f"{G['div_eq']}\n"
        + ("\n".join(rows) or f"<i>{sc('No payments yet')}</i>")
        + FOOTER
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_analytics"), call=call)


def render_adm_plan_dist(call: types.CallbackQuery) -> None:
    users = list(db_load()["users"].values())
    total = max(len(users), 1)
    counts: Dict[str, int] = defaultdict(int)
    for u in users:
        counts[u.get("plan", "free")] += 1
    bar = lambda n: "█" * int(n / total * 12) + "░" * (12 - int(n / total * 12))
    rows = "\n".join(
        f"{bullet(PLAN_LIMITS.get(p, {}).get('name', p), f'{n} ({n*100//total}%) {bar(n)}')}"
        for p, n in sorted(counts.items(), key=lambda x: x[1], reverse=True)
    )
    cap = (
        f"<b>🥧 {sc('Plan Distribution')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_analytics"), call=call)


def render_adm_bot_activity(call: types.CallbackQuery) -> None:
    bots = list(db_load()["bots"].values())
    total   = len(bots)
    running = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    stopped = total - running
    crashed = sum(1 for b in bots if b.get("last_exit_code") not in (None, 0, ""))
    never   = sum(1 for b in bots if not b.get("last_started"))
    bar = lambda n: "█" * int(n / max(total, 1) * 10)
    cap = (
        f"<b>🤖 {sc('Bot Activity')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total bots',   total)}\n"
        f"{bullet('▶ Running',    f'{running}  {bar(running)}')}\n"
        f"{bullet('⏹ Stopped',    f'{stopped}  {bar(stopped)}')}\n"
        f"{bullet('💥 Crashed',   f'{crashed}  {bar(crashed)}')}\n"
        f"{bullet('⬜ Never run', never)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_analytics"), call=call)


# ─── 2. USER TOOLS ───────────────────────────────────────────────────────────

def render_adm_user_tools(call: types.CallbackQuery) -> None:
    d = db_load()
    banned_n = sum(1 for u in d["users"].values() if u.get("banned"))
    cap = (
        f"<b>👥 {sc('User Tools')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total users', len(d['users']))}\n"
        f"{bullet('Banned',      banned_n)}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🔍  Sᴇᴀʀᴄʜ Uꜱᴇʀ",    callback_data="adm_user_search",     style="primary"),
        Btn("🚫  Bᴀɴɴᴇᴅ Lɪꜱᴛ",    callback_data="adm_banned_list",     style="danger"),
    )
    kb.add(
        Btn("💰  Wᴀʟʟᴇᴛ Aᴅᴊᴜꜱᴛ",  callback_data="adm_wallet_admin",    style="success"),
        Btn("📤  Exᴘᴏʀᴛ CSV",      callback_data="adm_user_export_csv", style="primary"),
    )
    kb.add(
        Btn("📨  Nᴏᴛɪꜰʏ Uꜱᴇʀ",    callback_data="adm_notify_user",     style="primary"),
        Btn("🔄  Rᴇꜱᴇᴛ Uꜱᴇʀ",     callback_data="adm_user_reset",      style="danger"),
    )
    kb.add(
        Btn("🎁  Gɪᴠᴇ Pʟᴀɴ",      callback_data="adm_giveplan",        style="success"),
        Btn("🚫  Bᴀɴ/Uɴʙᴀɴ",      callback_data="adm_ban",             style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_user_search(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🔍 {sc('Search User')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send a user ID, @username or part of their name')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_user_search"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_user_tools"), call=call)


def render_adm_banned_list(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    banned = [(uid, u) for uid, u in users.items() if u.get("banned")]
    rows = "\n".join(
        f"{G['bullet']} <code>{uid}</code> — {esc(u.get('name','?'))} "
        f"({esc(u.get('ban_reason','—'))})"
        for uid, u in banned[:20]
    ) or f"<i>{sc('No banned users')}</i>"
    cap = (
        f"<b>🚫 {sc('Banned Users')} ({len(banned)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_user_tools"), call=call)


def render_adm_wallet_admin(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>💰 {sc('Adjust User Wallet')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send')}: <code>&lt;user_id&gt; +amount</code> {sc('to add')}\n"
        f"{sc('Send')}: <code>&lt;user_id&gt; -amount</code> {sc('to deduct')}\n"
        f"{sc('Send')}: <code>&lt;user_id&gt; =amount</code> {sc('to set exact')}{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_wallet_adjust"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_user_tools"), call=call)


def render_adm_user_export_csv(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    ack(call, "Building CSV…")
    def _bg() -> None:
        try:
            d = db_load()
            lines = ["id,name,username,plan,joined,bots,wallet,banned"]
            bots_by_owner: Dict[str, int] = defaultdict(int)
            for b in d["bots"].values():
                bots_by_owner[str(b.get("owner", ""))] += 1
            for uid, u in d["users"].items():
                lines.append(",".join(str(x).replace(",", " ") for x in [
                    uid,
                    u.get("name", ""),
                    u.get("username", ""),
                    u.get("plan", "free"),
                    str(u.get("joined", ""))[:10],
                    bots_by_owner.get(uid, 0),
                    u.get("wallet", 0),
                    "yes" if u.get("banned") else "no",
                ]))
            csv_bytes = "\n".join(lines).encode("utf-8")
            tmp = Path(tempfile.mktemp(suffix="_users.csv"))
            tmp.write_bytes(csv_bytes)
            with tmp.open("rb") as fh:
                bot.send_document(
                    call.from_user.id, fh,
                    caption=f"{G['ok']} {sc('Users CSV')} ({len(d['users'])} rows)",
                    visible_file_name="users_export.csv")
            tmp.unlink(missing_ok=True)
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} CSV error: <code>{esc(e)}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def render_adm_notify_user(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>📨 {sc('Notify Specific User')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send')}: <code>&lt;user_id&gt; Your message here</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_notify_user"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_user_tools"), call=call)


def render_adm_user_reset_prompt(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🔄 {sc('Reset User')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('This will stop all bots, delete bot records, and reset plan to free')}.\n"
        f"{sc('Send')}: <code>&lt;user_id&gt;</code> {sc('to reset')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_user_reset"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_user_tools"), call=call)


# ─── 3. BOT MANAGER ──────────────────────────────────────────────────────────

def render_adm_bot_manager(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"]
    running_n = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    crashed_n = sum(1 for b in bots.values()
                    if b.get("last_exit_code") not in (None, 0, "") and
                    b["_id"] not in RUNNING)
    cap = (
        f"<b>🤖 {sc('Bot Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total bots',  len(bots))}\n"
        f"{bullet('Running',     running_n)}\n"
        f"{bullet('Crashed',     crashed_n)}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("💥  Cʀᴀꜱʜᴇᴅ Bᴏᴛꜱ",     callback_data="adm_crashed_bots",        style="danger"),
        Btn("🔄  Rᴇꜱᴛᴀʀᴛ Sᴛᴏᴘᴘᴇᴅ",   callback_data="adm_mass_restart_stopped", style="success"),
    )
    kb.add(
        Btn("🔍  Sᴇᴀʀᴄʜ Bᴏᴛ",        callback_data="adm_bot_search",          style="primary"),
        Btn("📦  Sɪᴢᴇ Rᴇᴘᴏʀᴛ",       callback_data="adm_bot_size_report",     style="primary"),
    )
    kb.add(
        Btn("🧪  AI Sᴄᴀɴ Pᴇɴᴅɪɴɢ",   callback_data="adm_force_scan_all",      style="primary"),
        Btn("📋  Aʟʟ Bᴏᴛꜱ",          callback_data="adm_allbots",             style="primary"),
    )
    kb.add(
        Btn("🔴  Kɪʟʟ Aʟʟ Nᴏᴡ",     callback_data="adm_kill_all_now",        style="danger"),
        Btn("🗑️  Cʟᴇᴀɴ Oʀᴘʜᴀɴꜱ",    callback_data="adm_set_clean_orphans",   style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_crashed_bots(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"].values()
    crashed = [b for b in bots
               if b.get("last_exit_code") not in (None, 0, "")
               and b["_id"] not in RUNNING]
    rows = "\n".join(
        f"{G['bullet']} <code>{b['_id']}</code> {esc(b['name'][:20])} "
        f"— exit <b>{b.get('last_exit_code')}</b> "
        f"uid {b.get('owner')}"
        for b in crashed[:20]
    ) or f"<i>{sc('No crashed bots')}</i>"
    cap = (
        f"<b>💥 {sc('Crashed Bots')} ({len(crashed)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_bot_manager"), call=call)


def render_adm_mass_restart_stopped(call: types.CallbackQuery) -> None:
    stopped = [b for b in db_load()["bots"].values()
               if b["_id"] not in RUNNING
               and b.get("approval_status") != "pending"
               and b.get("status") != "stopped"]
    cap = (
        f"<b>🔄 {sc('Mass Restart Stopped Bots')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Eligible bots', len(stopped))}\n"
        f"{sc('This will try to start all idle/crashed bots')}.\n"
        f"{sc('Continue')}?{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  {sc('Yes, Start All')}", callback_data="adm_mass_restart_stopped_yes", style="success"),
        Btn(f"{G['no']}  {sc('Cancel')}",          callback_data="adm_bot_manager",              style="primary"),
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def action_adm_mass_restart_stopped(call: types.CallbackQuery) -> None:
    ack(call, "Starting bots…")
    def _bg() -> None:
        ok = fail = 0
        for b in list(db_load()["bots"].values()):
            if b["_id"] in RUNNING:
                continue
            if b.get("approval_status") in ("pending", "rejected"):
                continue
            try:
                r = start_child(b)
                if r.get("ok"):
                    ok += 1
                else:
                    fail += 1
            except Exception:
                fail += 1
        audit(call.from_user.id, "mass_restart_stopped", f"ok={ok} fail={fail}")
        try:
            bot.send_message(call.from_user.id,
                             f"{G['ok']} {sc('Mass restart done')}: {ok} started, {fail} failed.")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


def render_adm_bot_search(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🔍 {sc('Search Bot')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send a bot name or bot ID to find it')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_bot_search"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_bot_manager"), call=call)


def render_adm_bot_size_report(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"].values()
    usage: List[Tuple[float, str, str]] = []
    sandbox_root = BASE_DIR / "sandbox"
    for b in bots:
        bot_dir = Path(b.get("dir", ""))
        total = 0
        if bot_dir.exists():
            for root, _, files in os.walk(bot_dir):
                for f in files:
                    try:
                        total += (Path(root) / f).stat().st_size
                    except OSError:
                        pass
        usage.append((total, b["_id"], b.get("name", "?")))
    usage.sort(reverse=True)
    rows = "\n".join(
        f"{G['bullet']} {esc(name[:20])} — <b>{fmt_bytes(size)}</b>"
        for size, _, name in usage[:15]
    ) or f"<i>{sc('No sandboxes found')}</i>"
    total_all = sum(s for s, _, _ in usage)
    cap = (
        f"<b>📦 {sc('Bot Storage Report')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total storage', fmt_bytes(total_all))}\n"
        f"{bullet('Bot count',     len(usage))}\n"
        f"{G['div']}\n{rows}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_bot_manager"), call=call)


def action_adm_force_scan_all(call: types.CallbackQuery) -> None:
    ack(call, "Scanning pending bots with AI…")
    def _bg() -> None:
        pending = pending_list()
        scanned = flagged = 0
        results = []
        for bid, info in pending[:5]:
            b = find_bot(bid)
            if not b or not b.get("enc_files"):
                continue
            scanned += 1
            try:
                files_added = [(r, cipher_decrypt(enc)) for r, enc in
                               list(b["enc_files"].items())[:3]]
                result = _run_security_scan(files_added)
                verdict = result.get("verdict", "SAFE")
                if verdict in ("DANGEROUS", "SUSPICIOUS"):
                    flagged += 1
                    results.append(f"⚠️ {b['name'][:20]}: {verdict}")
                else:
                    results.append(f"✅ {b['name'][:20]}: SAFE")
            except Exception as e:
                results.append(f"❌ {bid[:8]}: error")
        summary = "\n".join(results) or "No pending bots to scan."
        audit(call.from_user.id, "force_scan_all", f"scanned={scanned} flagged={flagged}")
        try:
            bot.send_message(
                call.from_user.id,
                f"<b>🧪 {sc('AI Scan Report')}</b>\n"
                f"{G['div_eq']}\n"
                f"{bullet('Scanned', scanned)}\n"
                f"{bullet('Flagged', flagged)}\n"
                f"{G['div']}\n{summary}",
                parse_mode="HTML")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


def action_adm_kill_all(call: types.CallbackQuery) -> None:
    ack(call, "Killing all bots…")
    def _bg() -> None:
        n = _do_stop_all_bots(call.from_user.id)
        try:
            bot.send_message(call.from_user.id,
                             f"{G['ok']} {sc('Killed')} {n} {sc('bot(s)')}.")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


# ─── 4. SECURITY CENTER ──────────────────────────────────────────────────────

def render_adm_sec_center(call: types.CallbackQuery) -> None:
    d = db_load()
    scan_log = d.get("scan_log", [])
    blocked  = sum(1 for s in scan_log if s.get("verdict") == "DANGEROUS")
    reviewed = sum(1 for s in scan_log if s.get("verdict") == "SUSPICIOUS")
    banned_n = sum(1 for u in d["users"].values() if u.get("banned"))
    cap = (
        f"<b>🛡️ {sc('Security Center')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Files Blocked',     blocked)}\n"
        f"{bullet('Manual Reviews',    reviewed)}\n"
        f"{bullet('Banned Users',      banned_n)}\n"
        f"{bullet('AI Scanner',        'Active' if os.environ.get('AI_INTEGRATIONS_OPENROUTER_BASE_URL') else 'No URL')}\n"
        f"{bullet('Pattern Scanner',   'Active')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📋  Tʜʀᴇᴀᴛ Lᴏɢ",      callback_data="adm_threat_log",     style="danger"),
        Btn("📊  Sᴇᴄ Sᴛᴀᴛꜱ",        callback_data="adm_sec_stats",      style="primary"),
    )
    kb.add(
        Btn("✅  Wʜɪᴛᴇʟɪꜱᴛ Uꜱᴇʀ",  callback_data="adm_sec_whitelist",  style="success"),
        Btn("🚫  Bʟᴀᴄᴋʟɪꜱᴛ",        callback_data="adm_sec_blacklist",  style="danger"),
    )
    kb.add(
        Btn("🔍  Sᴄᴀɴ Rᴇᴘᴏʀᴛ",     callback_data="adm_scan_report",    style="primary"),
        Btn("🚫  Bᴀɴɴᴇᴅ Lɪꜱᴛ",     callback_data="adm_banned_list",    style="primary"),
    )
    kb.add(
        Btn("🛡️  Sᴇᴄᴜʀɪᴛʏ Iɴꜰᴏ",   callback_data="adm_security",       style="primary"),
        Btn("📋  Aᴜᴅɪᴛ Lᴏɢ",        callback_data="adm_audit",          style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["security"], cap, kb, call=call)


def render_adm_threat_log(call: types.CallbackQuery) -> None:
    scan_log = db_load().get("scan_log", [])
    flagged = [s for s in scan_log if s.get("verdict") in ("DANGEROUS", "SUSPICIOUS")][-20:]
    rows = "\n".join(
        f"{G['bullet']} <b>{esc(s.get('verdict'))}</b> "
        f"risk={s.get('risk_score',0)} "
        f"uid {s.get('uid','?')} "
        f"— {esc(s.get('filename','?'))[:25]} "
        f"<i>{str(s.get('ts',''))[:10]}</i>"
        for s in reversed(flagged)
    ) or f"<i>{sc('No threats logged')}</i>"
    cap = (
        f"<b>📋 {sc('Threat Log')} ({len(flagged)} {sc('entries')})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["security"], cap, _adm_back("adm_sec_center"), call=call)


def render_adm_sec_stats(call: types.CallbackQuery) -> None:
    scan_log = db_load().get("scan_log", [])
    total    = len(scan_log)
    blocked  = sum(1 for s in scan_log if s.get("verdict") == "DANGEROUS")
    sus      = sum(1 for s in scan_log if s.get("verdict") == "SUSPICIOUS")
    safe_n   = sum(1 for s in scan_log if s.get("verdict") == "SAFE")
    avg_risk = int(sum(s.get("risk_score", 0) for s in scan_log) / max(total, 1))
    cap = (
        f"<b>📊 {sc('Security Statistics')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total scans',    total)}\n"
        f"{bullet('🔴 Blocked',     blocked)}\n"
        f"{bullet('🟡 Suspicious',  sus)}\n"
        f"{bullet('✅ Safe',        safe_n)}\n"
        f"{bullet('Avg risk score', avg_risk)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["security"], cap, _adm_back("adm_sec_center"), call=call)


def render_adm_sec_whitelist_prompt(call: types.CallbackQuery) -> None:
    wl = get_setting("scan_whitelist", []) or []
    rows = ", ".join(f"<code>{uid}</code>" for uid in wl) or f"<i>{sc('Empty')}</i>"
    cap = (
        f"<b>✅ {sc('Scan Whitelist')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Whitelisted users skip AI + pattern scan')}.\n"
        f"{sc('Current')}: {rows}\n"
        f"{G['div']}\n"
        f"{sc('Send')}: <code>add &lt;uid&gt;</code> {sc('or')} <code>del &lt;uid&gt;</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_whitelist"}
    show_menu(call.message.chat.id, PHOTOS["security"], cap, _adm_back("adm_sec_center"), call=call)


def render_adm_scan_report(call: types.CallbackQuery) -> None:
    scan_log = db_load().get("scan_log", [])
    last10 = scan_log[-10:]
    rows = "\n".join(
        f"{G['bullet']} {esc(s.get('verdict','?'))[:4]} "
        f"risk={s.get('risk_score',0):>3} "
        f"{esc(s.get('filename','?')[:22])} "
        f"<i>uid {s.get('uid','?')}</i>"
        for s in reversed(last10)
    ) or f"<i>{sc('No scans yet')}</i>"
    cap = (
        f"<b>🔍 {sc('Recent Scan Report')} (last {len(last10)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["security"], cap, _adm_back("adm_sec_center"), call=call)


def render_adm_sec_blacklist(call: types.CallbackQuery) -> None:
    bl = get_setting("domain_blacklist", []) or []
    rows = "\n".join(f"{G['bullet']} <code>{esc(d)}</code>" for d in bl) or f"<i>{sc('Empty')}</i>"
    cap = (
        f"<b>🚫 {sc('Domain Blacklist')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Bots containing these domains auto-flag as SUSPICIOUS')}.\n"
        f"{sc('Current')}: {rows}\n"
        f"{G['div']}\n"
        f"{sc('Send')}: <code>add domain.com</code> {sc('or')} <code>del domain.com</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_blacklist"}
    show_menu(call.message.chat.id, PHOTOS["security"], cap, _adm_back("adm_sec_center"), call=call)


# ─── 5. NOTIFICATIONS ────────────────────────────────────────────────────────

def render_adm_notify_center(call: types.CallbackQuery) -> None:
    users_n  = len(db_load()["users"])
    running_n = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    cap = (
        f"<b>💬 {sc('Notifications Center')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total users',    users_n)}\n"
        f"{bullet('Running bots',   running_n)}\n"
        f"{G['div']}\n{sc('Choose notification type')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📢  Nᴏᴛɪꜰʏ Eᴠᴇʀʏᴏɴᴇ", callback_data="adm_notify_all",        style="success"),
        Btn("▶️  Bᴏᴛ Uꜱᴇʀꜱ Oɴʟʏ",  callback_data="adm_notify_running",     style="primary"),
    )
    kb.add(
        Btn("📊  Bʏ Pʟᴀɴ",          callback_data="adm_notify_plan_select", style="primary"),
        Btn("📨  Sɪɴɢʟᴇ Uꜱᴇʀ",     callback_data="adm_notify_user",        style="primary"),
    )
    kb.add(
        Btn("⏰  Sᴄʜᴇᴅᴜʟᴇ Mꜱɢ",    callback_data="adm_schedule_msg",       style="primary"),
        Btn("📣  Qᴜɪᴄᴋ Aɴɴᴏᴜɴᴄᴇ",  callback_data="adm_quick_announce",     style="success"),
    )
    kb.add(
        Btn("📡  Bʀᴏᴀᴅᴄᴀꜱᴛ",        callback_data="adm_broadcast",          style="success"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, kb, call=call)


def render_adm_notify_all(call: types.CallbackQuery) -> None:
    total = len(db_load()["users"])
    cap = (
        f"<b>📢 {sc('Notify All Users')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Recipients', total)}\n"
        f"{sc('Send your message now — it will be delivered to every user')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_broadcast"}
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, _adm_back("adm_notify_center"), call=call)


def render_adm_notify_running(call: types.CallbackQuery) -> None:
    running_owner_ids: set = {str(info["owner"]) for info in RUNNING.values()
                               if info["proc"].poll() is None}
    cap = (
        f"<b>▶️ {sc('Notify Active Bot Users')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Recipients', len(running_owner_ids))}\n"
        f"{sc('Send your message now')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_notify_running",
                                       "target_uids": list(running_owner_ids)}
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, _adm_back("adm_notify_center"), call=call)


def render_adm_notify_plan_select(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>📊 {sc('Notify By Plan')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Choose which plan to message')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, v in PLAN_LIMITS.items():
        cnt = sum(1 for u in db_load()["users"].values() if u.get("plan") == k)
        kb.add(Btn(f"{esc(v['name'])} ({cnt})", callback_data=f"adm_notify_plan_{k}"))
    kb.add(Btn(f"{G['back']}  {sc('Back')}", callback_data="adm_notify_center"))
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, kb, call=call)


def render_adm_notify_plan(call: types.CallbackQuery, plan_key: str) -> None:
    users = db_load()["users"]
    targets = [uid for uid, u in users.items() if u.get("plan") == plan_key]
    plan_name = PLAN_LIMITS.get(plan_key, {}).get("name", plan_key)
    cap = (
        f"<b>📊 {sc('Notify')} {esc(plan_name)} {sc('Users')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Recipients', len(targets))}\n"
        f"{sc('Send your message now')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_notify_running",
                                       "target_uids": targets}
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, _adm_back("adm_notify_center"), call=call)


def render_adm_schedule_msg(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>⏰ {sc('Schedule Message')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send in format')}:\n"
        f"<code>at:YYYY-MM-DD HH:MM Your message text</code>\n"
        f"{sc('Example')}: <code>at:2025-12-31 10:00 Happy New Year!</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_broadcast"}
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, _adm_back("adm_notify_center"), call=call)


def render_adm_quick_announce(call: types.CallbackQuery) -> None:
    chan = ANNOUNCE_CHANNEL or "—"
    cap = (
        f"<b>📣 {sc('Quick Announce')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Channel', chan)}\n"
        f"{sc('Send your message — it will be pinned in the announce channel')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_quick_announce"}
    show_menu(call.message.chat.id, PHOTOS["broadcast"], cap, _adm_back("adm_notify_center"), call=call)


# ─── 6. SYSTEM TOOLS ─────────────────────────────────────────────────────────

def render_adm_sys_tools(call: types.CallbackQuery) -> None:
    rss = 0
    if psutil is not None:
        try:
            rss = psutil.Process(os.getpid()).memory_info().rss
        except Exception:
            pass
    up_secs = int(time.time() - START_TIME) if "START_TIME" in globals() else 0
    cap = (
        f"<b>⚙️ {sc('System Tools')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Uptime',   fmt_dur(up_secs * 1000))}\n"
        f"{bullet('RAM',      fmt_bytes(rss))}\n"
        f"{bullet('PID',      os.getpid())}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🖥️  Sʏꜱ Hᴇᴀʟᴛʜ",    callback_data="adm_sys_health",      style="primary"),
        Btn("💾  Dɪꜱᴋ Uꜱᴀɢᴇ",    callback_data="adm_disk_usage",      style="primary"),
    )
    kb.add(
        Btn("🗄️  DB Iɴꜰᴏ",       callback_data="adm_db_info",         style="primary"),
        Btn("🧹  Cʟᴇᴀʀ Cᴀᴄʜᴇ",   callback_data="adm_clear_cache",     style="danger"),
    )
    kb.add(
        Btn("🔑  Tᴏᴋᴇɴ Cʜᴇᴄᴋ",   callback_data="adm_token_check",     style="primary"),
        Btn("📤  Exᴘᴏʀᴛ Dᴀᴛᴀ",   callback_data="adm_set_export",      style="primary"),
    )
    kb.add(
        Btn("🔄  Rᴇʟᴏᴀᴅ Cᴀᴄʜᴇ",  callback_data="adm_set_reload",      style="success"),
        Btn("👁️  Sʏꜱᴛᴇᴍ Iɴꜰᴏ",   callback_data="adm_set_sysinfo",     style="primary"),
    )
    kb.add(
        Btn("✏️  Fᴏᴏᴛᴇʀ Tᴇxᴛ",   callback_data="adm_set_footer_text", style="primary"),
        Btn("👋  Wᴇʟᴄᴏᴍᴇ Mꜱɢ",   callback_data="adm_set_welcome_text",style="primary"),
    )
    kb.add(
        Btn("📜  Rᴜʟᴇꜱ Tᴇxᴛ",    callback_data="adm_set_rules_text",  style="primary"),
        Btn("📦  Gɪᴛʜᴜʙ",         callback_data="adm_github",          style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_sys_health(call: types.CallbackQuery) -> None:
    rss = vms = cpu_p = 0.0
    disk_total = disk_used = disk_free = 0
    if psutil is not None:
        try:
            p = psutil.Process(os.getpid())
            mi = p.memory_info()
            rss, vms = mi.rss, mi.vms
            cpu_p = p.cpu_percent(interval=0.3)
            du = psutil.disk_usage("/")
            disk_total, disk_used, disk_free = du.total, du.used, du.free
        except Exception:
            pass
    # Child bot CPU/RAM
    child_rss = 0
    child_n   = 0
    if psutil is not None:
        for info in RUNNING.values():
            if info["proc"].poll() is not None:
                continue
            try:
                cp = psutil.Process(info["proc"].pid)
                child_rss += cp.memory_info().rss
                child_n += 1
            except Exception:
                pass
    up_secs = int(time.time() - START_TIME) if "START_TIME" in globals() else 0
    cap = (
        f"<b>🖥️ {sc('System Health')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Uptime',          fmt_dur(up_secs * 1000))}\n"
        f"{bullet('Panel RAM (RSS)', fmt_bytes(int(rss)))}\n"
        f"{bullet('Panel RAM (VMS)', fmt_bytes(int(vms)))}\n"
        f"{bullet('Panel CPU',       f'{cpu_p:.1f}%')}\n"
        f"{bullet('Child bots',      f'{child_n} running')}\n"
        f"{bullet('Child RAM total', fmt_bytes(child_rss))}\n"
        f"{bullet('Disk total',      fmt_bytes(disk_total))}\n"
        f"{bullet('Disk used',       fmt_bytes(disk_used))}\n"
        f"{bullet('Disk free',       fmt_bytes(disk_free))}\n"
        f"{bullet('PID',             os.getpid())}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_sys_tools"), call=call)


def render_adm_disk_usage(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"].values()
    by_user: Dict[str, int] = defaultdict(int)
    for b in bots:
        bot_dir = Path(b.get("dir", ""))
        if not bot_dir.exists():
            continue
        size = 0
        for root, _, files in os.walk(bot_dir):
            for f in files:
                try:
                    size += (Path(root) / f).stat().st_size
                except OSError:
                    pass
        by_user[str(b.get("owner", "unknown"))] += size
    top = sorted(by_user.items(), key=lambda x: x[1], reverse=True)[:12]
    d = db_load()
    rows = "\n".join(
        f"{G['bullet']} uid <code>{uid}</code> "
        f"({esc(d['users'].get(uid, {}).get('name', '?')[:15])}) — <b>{fmt_bytes(sz)}</b>"
        for uid, sz in top
    ) or f"<i>{sc('No data')}</i>"
    cap = (
        f"<b>💾 {sc('Disk Usage by User')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_sys_tools"), call=call)


def render_adm_db_info(call: types.CallbackQuery) -> None:
    d = db_load()
    db_file = DB_FILE
    db_size = db_file.stat().st_size if db_file.exists() else 0
    settings_size = SETTINGS_FILE.stat().st_size if SETTINGS_FILE.exists() else 0
    cap = (
        f"<b>🗄️ {sc('Database Info')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('DB file',       db_file.name)}\n"
        f"{bullet('DB size',       fmt_bytes(db_size))}\n"
        f"{bullet('Settings size', fmt_bytes(settings_size))}\n"
        f"{bullet('Users',         len(d['users']))}\n"
        f"{bullet('Bots',          len(d['bots']))}\n"
        f"{bullet('Payments',      len(d['payments']))}\n"
        f"{bullet('Coupons',       len(d['coupons']))}\n"
        f"{bullet('Tickets',       len(d.get('tickets', {})))}\n"
        f"{bullet('Audit entries', len(d.get('audit', [])))}\n"
        f"{bullet('Scan log',      len(d.get('scan_log', [])))}\n"
        f"{bullet('Cache entries', len(_DB_CACHE))}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_sys_tools"), call=call)


def render_adm_token_check(call: types.CallbackQuery) -> None:
    ack(call, "Checking tokens…")
    def _bg() -> None:
        bots = list(db_load()["bots"].values())
        valid = invalid = missing = 0
        bad_list: List[str] = []
        for b in bots[:20]:
            tok = b.get("env", {}).get("BOT_TOKEN")
            if not tok:
                missing += 1
                continue
            try:
                resp = _urllib_req.urlopen(
                    f"https://api.telegram.org/bot{tok}/getMe", timeout=5)
                data = _json.loads(resp.read())
                if data.get("ok"):
                    valid += 1
                else:
                    invalid += 1
                    bad_list.append(b.get("name", b["_id"])[:20])
            except Exception:
                invalid += 1
                bad_list.append(b.get("name", b["_id"])[:20])
        bad_txt = "\n".join(f"  ❌ {n}" for n in bad_list) or "  (none)"
        audit(call.from_user.id, "token_check", f"valid={valid} invalid={invalid}")
        try:
            bot.send_message(
                call.from_user.id,
                f"<b>🔑 {sc('Token Check Report')}</b>\n"
                f"{G['div_eq']}\n"
                f"{bullet('Valid',   valid)}\n"
                f"{bullet('Invalid', invalid)}\n"
                f"{bullet('Missing', missing)}\n"
                f"{G['div']}\n<b>Invalid bots:</b>\n{bad_txt}",
                parse_mode="HTML")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()

# ═══════════════════════ END NEW ADMIN SUB-PANELS ═══════════════════════════


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║          MEGA ADVANCED ADMIN PANELS  (20+ new panels, 200+ features)     ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

# ─────────────────────────────────────────────────────────────────────────────
# CONSTANTS / DEFAULTS for new systems
# ─────────────────────────────────────────────────────────────────────────────

_FEATURE_FLAG_DEFAULTS: Dict[str, bool] = {
    "user_registration":    True,   # allow new users to register
    "bot_upload":           True,   # allow users to upload bots
    "bot_auto_start":       True,   # auto-start bots after approval
    "payment_system":       True,   # enable the payment panel
    "coupon_system":        True,   # allow coupon redemption
    "referral_system":      True,   # enable referrals
    "ticket_system":        True,   # enable support tickets
    "wallet_topup":         True,   # allow wallet top-up
    "gift_plan":            True,   # allow gifting plans
    "trial_plan":           True,   # allow free trials
    "public_stats":         False,  # show stats to regular users
    "bot_logs_user":        True,   # users can view their own bot logs
    "multi_file_upload":    True,   # allow zip uploads with multiple files
    "github_backup":        True,   # enable GitHub backup
    "cloudflare_tunnel":    True,   # enable Cloudflare tunnel feature
    "ai_scanner":           True,   # enable AI security scan
    "approval_system":      True,   # require admin approval for uploads
    "maintenance_bypass":   False,  # admins bypass maintenance mode
    "sandbox_wipe":         True,   # wipe source files after start
    "rate_limiting":        True,   # enable rate limiting
    "audit_logging":        True,   # log admin actions to audit trail
    "auto_restart_bots":    True,   # auto-restart crashed bots
    "broadcast_enabled":    True,   # enable broadcast messages
    "webhook_notifications":False,  # send events to external webhook
    "2fa_required":         False,  # require 2FA for admin actions
}

_BOT_CONFIG_DEFAULTS: Dict[str, Any] = {
    "sandbox_wipe_delay":   6,      # seconds before wiping source files
    "max_upload_mb":        75,     # max upload size in MB
    "allowed_extensions":   ".py,.js,.zip,.txt,.json,.env",
    "bot_start_timeout":    30,     # seconds to wait for bot to start
    "bot_stop_timeout":     10,     # seconds for graceful stop
    "crash_restart_delay":  5,      # seconds before auto-restart after crash
    "max_crash_restarts":   5,      # max auto-restarts per bot per hour
    "log_ring_size":        200,    # lines kept in memory log ring
    "zip_max_files":        50,     # max files in a zip upload
    "env_strip_secrets":    True,   # strip BOT_TOKEN etc from child env
    "sandbox_network":      True,   # allow bots to use network
    "idle_timeout_mins":    0,      # 0 = no idle timeout
    "resource_check_secs":  30,     # interval for resource checks
}

_RATE_LIMIT_DEFAULTS: Dict[str, Dict[str, int]] = {
    "free":       {"uploads_per_day": 3,  "starts_per_hour": 5,  "msgs_per_min": 20},
    "starter":    {"uploads_per_day": 10, "starts_per_hour": 15, "msgs_per_min": 40},
    "basic":      {"uploads_per_day": 20, "starts_per_hour": 30, "msgs_per_min": 60},
    "pro":        {"uploads_per_day": 50, "starts_per_hour": 60, "msgs_per_min": 120},
    "enterprise": {"uploads_per_day": 100,"starts_per_hour": 120,"msgs_per_min": 240},
    "lifetime":   {"uploads_per_day": 999,"starts_per_hour": 999,"msgs_per_min": 999},
}

_MESSAGE_TEMPLATES: Dict[str, Dict[str, str]] = {
    "welcome": {
        "label": "Welcome Message",
        "default": "Welcome {name}! 🎉 You're now registered on {brand}. Use /start to explore.",
        "vars": "{name}, {brand}, {plan}",
    },
    "payment_received": {
        "label": "Payment Received",
        "default": "✅ Payment of {amount}{currency_symbol} received for {plan} plan. Your account has been upgraded!",
        "vars": "{name}, {amount}, {plan}, {tx_id}, {date}",
    },
    "plan_expired": {
        "label": "Plan Expiry Warning",
        "default": "⚠️ Your {plan} plan expires in {days} days. Renew now to avoid service interruption!",
        "vars": "{name}, {plan}, {days}, {expiry_date}",
    },
    "bot_approved": {
        "label": "Bot Approved",
        "default": "✅ Your bot '{bot_name}' has been approved and is now running!",
        "vars": "{name}, {bot_name}, {bot_id}",
    },
    "bot_rejected": {
        "label": "Bot Rejected",
        "default": "❌ Your bot '{bot_name}' was rejected. Reason: {reason}",
        "vars": "{name}, {bot_name}, {reason}",
    },
    "referral_reward": {
        "label": "Referral Reward",
        "default": "🎁 You earned {amount}{currency_symbol} for referring {referred_name}! Keep sharing!",
        "vars": "{name}, {amount}, {referred_name}",
    },
    "ticket_reply": {
        "label": "Ticket Reply",
        "default": "📩 Admin replied to your ticket #{ticket_id}: {reply}",
        "vars": "{name}, {ticket_id}, {reply}",
    },
    "bot_crashed": {
        "label": "Bot Crashed Alert",
        "default": "💥 Your bot '{bot_name}' crashed (exit code {exit_code}). Check logs or re-upload.",
        "vars": "{name}, {bot_name}, {exit_code}",
    },
    "maintenance": {
        "label": "Maintenance Notice",
        "default": "🔧 {brand} is currently under maintenance. We'll be back soon!",
        "vars": "{brand}, {eta}",
    },
    "upgrade_prompt": {
        "label": "Upgrade Prompt",
        "default": "💎 Upgrade to {plan} and get {max_bots} bots, {ram}MB RAM, and more!",
        "vars": "{name}, {plan}, {max_bots}, {ram}, {price}",
    },
}

_SUPPORTED_LANGUAGES: Dict[str, str] = {
    "en":    "🇬🇧 English",
    "bn":    "🇧🇩 বাংলা (Bengali)",
    "hi":    "🇮🇳 हिन्दी (Hindi)",
    "ar":    "🇸🇦 العربية (Arabic)",
    "ur":    "🇵🇰 اردو (Urdu)",
    "tr":    "🇹🇷 Türkçe",
    "ru":    "🇷🇺 Русский",
    "es":    "🇪🇸 Español",
    "fr":    "🇫🇷 Français",
    "de":    "🇩🇪 Deutsch",
    "pt":    "🇧🇷 Português",
    "id":    "🇮🇩 Bahasa Indonesia",
    "ms":    "🇲🇾 Bahasa Melayu",
    "fa":    "🇮🇷 فارسی (Persian)",
    "zh":    "🇨🇳 中文 (Chinese)",
}

_APPEARANCE_THEMES: Dict[str, Dict[str, str]] = {
    "dark":      {"name": "Dark",       "header": "#0F172A", "accent": "#6366F1", "emoji_ok": "✅"},
    "midnight":  {"name": "Midnight",   "header": "#020617", "accent": "#818CF8", "emoji_ok": "💫"},
    "ocean":     {"name": "Ocean",      "header": "#0E4472", "accent": "#38BDF8", "emoji_ok": "🌊"},
    "forest":    {"name": "Forest",     "header": "#14532D", "accent": "#4ADE80", "emoji_ok": "🌿"},
    "sunset":    {"name": "Sunset",     "header": "#7C2D12", "accent": "#FB923C", "emoji_ok": "🌅"},
    "royal":     {"name": "Royal",      "header": "#3B0764", "accent": "#C084FC", "emoji_ok": "👑"},
    "neon":      {"name": "Neon",       "header": "#0A0A0A", "accent": "#39FF14", "emoji_ok": "⚡"},
    "rose":      {"name": "Rose",       "header": "#881337", "accent": "#FB7185", "emoji_ok": "🌹"},
    "gold":      {"name": "Gold",       "header": "#451A03", "accent": "#FBBF24", "emoji_ok": "💰"},
    "ice":       {"name": "Ice",        "header": "#1E3A5F", "accent": "#BAE6FD", "emoji_ok": "❄️"},
}

# ─────────────────────────────────────────────────────────────────────────────
# GITHUB FILE BROWSER & RUNNER
# ─────────────────────────────────────────────────────────────────────────────

def _gh_api(endpoint: str, token: Optional[str] = None,
            method: str = "GET", body: Optional[bytes] = None) -> Any:
    """Make a GitHub API call. Returns parsed JSON or raises."""
    import urllib.request as _ur
    import json as _j
    tok = token or GH.get("token", "")
    url = endpoint if endpoint.startswith("http") else f"https://api.github.com{endpoint}"
    req = _ur.Request(url, method=method, data=body)
    req.add_header("Authorization", f"token {tok}")
    req.add_header("Accept",        "application/vnd.github.v3+json")
    req.add_header("User-Agent",    "KRYON_HOST/1.0")
    if body:
        req.add_header("Content-Type", "application/json")
    with _ur.urlopen(req, timeout=15) as resp:
        return _j.loads(resp.read().decode("utf-8"))


def _gh_api_safe(endpoint: str, token: Optional[str] = None) -> Tuple[bool, Any]:
    """GitHub API call returning (ok, data_or_error_str)."""
    try:
        return True, _gh_api(endpoint, token)
    except Exception as e:
        return False, str(e)




def render_adm_gh_repos(call: types.CallbackQuery, force: bool = False) -> None:
    """List all accessible GitHub repositories."""
    if not GH.get("token"):
        ack(call, "Set GitHub token first"); return render_adm_gh_browser(call)
    ack(call, "Fetching repos…")
    def _bg() -> None:
        ok, data = _gh_api_safe("/user/repos?per_page=50&sort=updated&type=all")
        if not ok:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('GitHub API error')}: <code>{esc(str(data)[:200])}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
            return
        repos = data if isinstance(data, list) else []
        if not repos:
            try:
                bot.send_message(call.from_user.id, f"<i>{sc('No repos found.')}</i>", parse_mode="HTML")
            except Exception:
                pass
            return
        rows = "\n".join(
            f"{G['bullet']} <b>{esc(r['full_name'])}</b> "
            f"{'🔒' if r.get('private') else '🌐'} "
            f"⭐{r.get('stargazers_count',0)} "
            f"<i>{esc((r.get('description') or '')[:40])}</i>"
            for r in repos[:20]
        )
        cap = (
            f"<b>🐙 {sc('Your GitHub Repos')} ({len(repos)})</b>\n"
            f"{G['div_eq']}\n{rows}\n{G['div']}\n"
            f"{sc('Tap a repo to browse its files')}.{FOOTER}"
        )
        kb = types.InlineKeyboardMarkup(row_width=1)
        for r in repos[:15]:
            name = r["full_name"]
            short = name[:35]
            icon = "🔒" if r.get("private") else "🌐"
            # Store repo in state, use index-based callback
            kb.add(Btn(f"{icon} {short}", callback_data=f"adm_ghrepo_{name[:40]}", style="primary"))
        kb.add(Btn(f"{G['back']}  Gʜ Bʀᴏᴡꜱᴇʀ", callback_data="adm_gh_browser", style="primary"))
        try:
            bot.send_message(call.from_user.id, cap, reply_markup=kb, parse_mode="HTML")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


def render_adm_gh_files(call: types.CallbackQuery, repo: str, path: str = "") -> None:
    """Browse files in a GitHub repo at a given path."""
    if not GH.get("token") or not repo:
        ack(call, "Set token and repo first"); return
    ack(call, f"Loading {repo}/{path or 'root'}…")
    def _bg() -> None:
        branch = GH.get("branch", "main")
        ep = f"/repos/{repo}/contents/{path}?ref={branch}"
        ok, data = _gh_api_safe(ep)
        if not ok:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('Error loading files')}: <code>{esc(str(data)[:200])}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
            return
        items = data if isinstance(data, list) else [data]
        items.sort(key=lambda x: (0 if x.get("type") == "dir" else 1, x.get("name", "")))
        # Save file list in state for index-based navigation
        USER_STATES[call.from_user.id] = USER_STATES.get(call.from_user.id, {})
        USER_STATES[call.from_user.id].update({
            "gh_repo": repo,
            "gh_path": path,
            "gh_files_list": items,
        })
        breadcrumb = f"{repo}/{path}" if path else repo
        rows = "\n".join(
            f"{'📁' if it.get('type')=='dir' else '📄'} {esc(it.get('name','?'))} "
            + (f"<i>({fmt_bytes(it.get('size',0))})</i>" if it.get('type') != 'dir' else "")
            for it in items[:25]
        )
        cap = (
            f"<b>📂 {esc(breadcrumb[:50])}</b>\n"
            f"{G['div_eq']}\n{rows}\n"
            f"{G['div']}\n{len(items)} items{FOOTER}"
        )
        kb = types.InlineKeyboardMarkup(row_width=2)
        if path:
            kb.add(Btn("⬆️  Uᴘ",  callback_data="adm_gh_up", style="primary"))
        for i, it in enumerate(items[:12]):
            icon = "📁" if it.get("type") == "dir" else _file_icon(it.get("name",""))
            kb.add(Btn(f"{icon} {esc(it.get('name','?'))[:28]}", callback_data=f"adm_ghfile_{i}", style="primary"))
        kb.add(Btn(f"{G['back']}  Rᴇᴘᴏꜱ", callback_data="adm_gh_repos", style="primary"))
        try:
            bot.send_message(call.from_user.id, cap, reply_markup=kb, parse_mode="HTML")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


def _file_icon(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    return {"py":"🐍",".js":"📜",".json":"📋",".env":"🔐",".txt":"📝",
            ".md":"📝",".zip":"📦",".sh":"⚙️",".yaml":"📋",".yml":"📋",
            ".toml":"📋",".cfg":"⚙️",".ini":"⚙️",".html":"🌐",".css":"🎨"}.get(ext, "📄")


def render_adm_gh_file_view(call: types.CallbackQuery, repo: str, path: str) -> None:
    """View a single file from GitHub and optionally run it."""
    ack(call, f"Loading {Path(path).name}…")
    USER_STATES[call.from_user.id] = USER_STATES.get(call.from_user.id, {})
    USER_STATES[call.from_user.id]["gh_view_path"] = path
    USER_STATES[call.from_user.id]["gh_repo"] = repo
    def _bg() -> None:
        branch = GH.get("branch", "main")
        ep = f"/repos/{repo}/contents/{path}?ref={branch}"
        ok, data = _gh_api_safe(ep)
        if not ok or isinstance(data, list):
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('Cannot read file')}: <code>{esc(str(data)[:200])}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
            return
        fname   = data.get("name", path)
        size    = data.get("size", 0)
        sha     = data.get("sha", "")[:7]
        dl_url  = data.get("download_url", "")
        content_b64 = data.get("content", "")
        try:
            raw = base64.b64decode(content_b64.replace("\n", ""))
            preview = raw[:1000].decode("utf-8", errors="replace")
        except Exception:
            preview = "(binary file — cannot preview)"
        ext = Path(fname).suffix.lower()
        runnable = ext in (".py", ".js")
        cap = (
            f"<b>{_file_icon(fname)} {esc(fname)}</b>\n"
            f"{G['div_eq']}\n"
            f"{bullet('Repo',   esc(repo))}\n"
            f"{bullet('Path',   esc(path))}\n"
            f"{bullet('Size',   fmt_bytes(size))}\n"
            f"{bullet('SHA',    sha)}\n"
            f"{bullet('Branch', GH.get('branch','main'))}\n"
            f"{G['div']}\n"
            f"<pre>{esc(preview[:800])}</pre>"
            f"{'...(truncated)' if len(raw) > 1000 else ''}{FOOTER}"
        )
        kb = types.InlineKeyboardMarkup(row_width=2)
        if runnable:
            kb.add(Btn("▶️  Rᴜɴ Aꜱ Bᴏᴛ",  callback_data="adm_gh_run_file",  style="success"))
        kb.add(
            Btn("📥  Dᴏᴡɴʟᴏᴀᴅ",        callback_data="adm_gh_dl_file",   style="primary"),
            Btn("📁  Bᴀᴄᴋ ᴛᴏ Fᴏʟᴅᴇʀ",  callback_data="adm_gh_browse_repo",style="primary"),
        )
        kb.add(Btn(f"{G['back']}  Gʜ Bʀᴏᴡꜱᴇʀ", callback_data="adm_gh_browser", style="primary"))
        try:
            bot.send_message(call.from_user.id, cap, reply_markup=kb, parse_mode="HTML")
        except Exception:
            pass
    threading.Thread(target=_bg, daemon=True).start()


def action_adm_gh_run_file(call: types.CallbackQuery, repo: str, path: str) -> None:
    """Download a file from GitHub and register + start it as a bot."""
    if not repo or not path:
        ack(call, "No file selected"); return
    ack(call, f"Downloading and deploying {Path(path).name}…")
    def _bg() -> None:
        try:
            branch = GH.get("branch", "main")
            ep = f"/repos/{repo}/contents/{path}?ref={branch}"
            ok, data = _gh_api_safe(ep)
            if not ok:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} API error: <code>{esc(str(data)[:200])}</code>",
                                 parse_mode="HTML"); return
            fname = data.get("name", Path(path).name)
            content_b64 = data.get("content", "")
            raw = base64.b64decode(content_b64.replace("\n", ""))
            # Create a new bot entry
            bid   = secrets.token_hex(8)
            d_db  = db_load()
            owner = call.from_user.id
            bot_name = Path(fname).stem[:30]
            # Build the bot record
            bot_dir = BASE_DIR / "sandbox" / bid
            bot_dir.mkdir(parents=True, exist_ok=True)
            src_file = bot_dir / fname
            src_file.write_bytes(raw)
            # Encrypt the file for storage
            enc_files: Dict[str, str] = {}
            try:
                enc_files[fname] = cipher_encrypt(raw)
            except Exception:
                enc_files[fname] = base64.b64encode(raw).decode()
            new_bot: Dict[str, Any] = {
                "_id":          bid,
                "name":         bot_name,
                "owner":        owner,
                "dir":          str(bot_dir),
                "files":        [fname],
                "enc_files":    enc_files,
                "env":          {},
                "plan":         d_db["users"].get(str(owner), {}).get("plan", "free"),
                "status":       "stopped",
                "approval_status": "approved",  # admin-deployed
                "created_at":   ts_iso(),
                "source":       f"github:{repo}/{path}",
                "last_exit_code": None,
            }
            d_db["bots"][bid] = new_bot
            db_save(d_db)
            audit(owner, "gh_run_file", f"repo={repo} path={path} bid={bid}")
            # Start the bot
            result = start_child(new_bot)
            if result.get("ok"):
                msg = (f"✅ <b>{esc(bot_name)}</b> {sc('deployed and started from GitHub!')}\n"
                       f"{bullet('Bot ID', f'<code>{bid}</code>')}\n"
                       f"{bullet('Source', f'{esc(repo)}/{esc(path)}')} ")
            else:
                msg = (f"⚠️ <b>{esc(bot_name)}</b> {sc('uploaded but failed to start')}.\n"
                       f"{bullet('Error', esc(str(result.get('error','?'))[:100]))}")
            bot.send_message(call.from_user.id, msg, parse_mode="HTML")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('Deploy error')}: <code>{esc(e)}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def action_adm_gh_dl_file(call: types.CallbackQuery, repo: str, path: str) -> None:
    """Download a raw file from GitHub and send it to admin."""
    if not repo or not path:
        ack(call, "No file selected"); return
    ack(call, "Downloading…")
    def _bg() -> None:
        try:
            branch = GH.get("branch", "main")
            ep = f"/repos/{repo}/contents/{path}?ref={branch}"
            ok, data = _gh_api_safe(ep)
            if not ok:
                bot.send_message(call.from_user.id, f"{G['no']} {esc(str(data)[:200])}"); return
            fname = data.get("name", Path(path).name)
            raw = base64.b64decode(data.get("content","").replace("\n",""))
            tmp = Path(tempfile.mktemp(suffix=f"_{fname}"))
            tmp.write_bytes(raw)
            with tmp.open("rb") as fh:
                bot.send_document(call.from_user.id, fh,
                                  caption=f"📥 {esc(fname)} ({fmt_bytes(len(raw))})\n"
                                          f"<code>{esc(repo)}/{esc(path)}</code>",
                                  visible_file_name=fname, parse_mode="HTML")
            tmp.unlink(missing_ok=True)
        except Exception as e:
            try:
                bot.send_message(call.from_user.id, f"{G['no']} {esc(e)}")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


# ─────────────────────────────────────────────────────────────────────────────
# PAYMENT CONFIG PANEL
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_pay_config(call: types.CallbackQuery) -> None:
    """Full payment configuration panel."""
    auto_approve = bool(get_setting("auto_approve_payments", False))
    min_amt = get_setting("min_payment_amount", 50)
    max_amt = get_setting("max_payment_amount", 10000)
    currency = get_setting("payment_currency", "INR")
    currency_sym = get_setting("currency_symbol", "₹")
    tax_pct = get_setting("payment_tax_pct", 0)
    methods_enabled = sum(1 for k in PAYMENT_METHODS if get_setting(f"pm_enabled_{k}", True))
    notif_chan = get_setting("payment_notif_channel", "") or "—"
    merchant_name = get_setting("payment_merchant_name", BRAND) or BRAND
    cap = (
        f"<b>💳 {sc('Payment Configuration')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Auto-Approve',   '✅ ON' if auto_approve else '❌ OFF')}\n"
        f"{bullet('Min Amount',     f'{min_amt}{currency_sym}')}\n"
        f"{bullet('Max Amount',     f'{max_amt}{currency_sym}')}\n"
        f"{bullet('Currency',       f'{currency} ({currency_sym})')}\n"
        f"{bullet('Tax/Fee %',      f'{tax_pct}%')}\n"
        f"{bullet('Active Methods', methods_enabled)}\n"
        f"{bullet('Merchant Name',  esc(merchant_name))}\n"
        f"{bullet('Notif Channel',  esc(notif_chan))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅' if auto_approve else '❌'}  Aᴜᴛᴏ-Aᴘᴘʀ",
            callback_data="adm_pay_auto_approve",
            style="success" if auto_approve else "danger"),
        Btn("💰  Pᴀʏ Mᴇᴛʜᴏᴅꜱ",   callback_data="adm_pay_methods",      style="primary"),
    )
    kb.add(
        Btn("📊  Aᴍᴏᴜɴᴛ Lɪᴍɪᴛꜱ",  callback_data="adm_pay_limits",       style="primary"),
        Btn("💱  Cᴜʀʀᴇɴᴄʏ",        callback_data="adm_pay_currency",     style="primary"),
    )
    kb.add(
        Btn("🧾  Rᴇᴄᴇɪᴘᴛ Tᴇᴍᴘʟ",  callback_data="adm_pay_receipt_tmpl", style="primary"),
        Btn("🔔  Nᴏᴛɪꜰ Sᴇᴛᴛɪɴɢꜱ",  callback_data="adm_pay_notif",        style="primary"),
    )
    kb.add(
        Btn("🏷️  Sᴇᴛ Tᴀx %",       callback_data="adm_bc_set_payment_tax_pct",  style="primary"),
        Btn("🏪  Mᴇʀᴄʜᴀɴᴛ Nᴀᴍᴇ", callback_data="adm_pay_merchant_name",      style="primary"),
    )
    kb.add(Btn("📋  Pᴀʏ Hɪꜱᴛᴏʀʏ", callback_data="adm_payments", style="primary"))
    kb.add(
        Btn("✅  Aᴘᴘʀᴏᴠᴇ Pᴀʏ",     callback_data="adm_approve",          style="success"),
        Btn("📤  Exᴘᴏʀᴛ CSV",       callback_data="adm_user_export_csv",  style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_methods(call: types.CallbackQuery) -> None:
    """Show all payment methods with enable/disable toggle."""
    rows = []
    for key, m in PAYMENT_METHODS.items():
        enabled = bool(get_setting(f"pm_enabled_{key}", True))
        rows.append(f"{'✅' if enabled else '❌'} <b>{esc(m['name'])}</b> — "
                    f"<code>{esc(_payment_value(key))}</code> ({esc(m['type'])})")
    cap = (
        f"<b>💰 {sc('Payment Methods')}</b>\n"
        f"{G['div_eq']}\n"
        + "\n".join(rows)
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for key, m in PAYMENT_METHODS.items():
        enabled = bool(get_setting(f"pm_enabled_{key}", True))
        kb.add(
            Btn(f"{'✅' if enabled else '❌'} {esc(m['name'])}",
                callback_data=f"adm_pay_edit_{key}", style="primary"),
        )
    kb.add(Btn(f"{G['back']}  Pᴀʏ Cᴏɴꜰɪɢ", callback_data="adm_pay_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_method_edit(call: types.CallbackQuery, key: str) -> None:
    """Edit a single payment method."""
    m = PAYMENT_METHODS.get(key)
    if not m:
        ack(call, "Unknown method"); return
    enabled = bool(get_setting(f"pm_enabled_{key}", True))
    stored_num = get_setting(f"pm_number_{key}", m["number"]) or m["number"]
    cap = (
        f"<b>💰 {sc('Edit')} {esc(m['name'])}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status',  '✅ Enabled' if enabled else '❌ Disabled')}\n"
        f"{bullet(_payment_admin_label(key),  esc(stored_num))}\n"
        f"{bullet('Type',    esc(m['type']))}\n"
        f"{bullet('Tag',     esc(m['tag']))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'❌ Disable' if enabled else '✅ Enable'}",
            callback_data=f"adm_pay_method_toggle_{key}",
            style="danger" if enabled else "success"),
        Btn("✏️  Cʜᴀɴɢᴇ UPI / DETAILS",
            callback_data=f"adm_pay_method_setnumber_{key}", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Pᴀʏ Mᴇᴛʜᴏᴅꜱ", callback_data="adm_pay_methods", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_limits(call: types.CallbackQuery) -> None:
    min_amt = get_setting("min_payment_amount", 50)
    max_amt = get_setting("max_payment_amount", 10000)
    disc_threshold = get_setting("discount_threshold", 500)
    disc_pct  = get_setting("discount_pct", 5)
    cap = (
        f"<b>📊 {sc('Payment Amount Limits')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Min Payment',      money(min_amt))}\n"
        f"{bullet('Max Payment',      money(max_amt))}\n"
        f"{bullet('Discount >= ' + currency_symbol(), disc_threshold)}\n"
        f"{bullet('Discount %',       f'{disc_pct}%')}\n"
        f"{G['div']}\n"
        f"{sc('Set limits below. All values in your currency unit.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📉  Sᴇᴛ Mɪɴ",         callback_data="adm_bc_set_min_payment_amount",  style="primary"),
        Btn("📈  Sᴇᴛ Mᴀx",         callback_data="adm_bc_set_max_payment_amount",  style="primary"),
    )
    kb.add(
        Btn("🎯  Dɪꜱᴄ Tʜʀᴇꜱʜᴏʟᴅ", callback_data="adm_bc_set_discount_threshold",  style="primary"),
        Btn("💸  Dɪꜱᴄ %",           callback_data="adm_bc_set_discount_pct",        style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Pᴀʏ Cᴏɴꜰɪɢ", callback_data="adm_pay_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_currency(call: types.CallbackQuery) -> None:
    cur = get_setting("payment_currency", "INR")
    sym = get_setting("currency_symbol",  "₹")
    cap = (
        f"<b>💱 {sc('Currency Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Currency Code', cur)}\n"
        f"{bullet('Symbol',        sym)}\n"
        f"{G['div']}\n"
        f"{sc('Examples')}: INR/₹, USD/$, EUR/€, PKR/₨{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🔤  Sᴇᴛ Cᴏᴅᴇ",     callback_data="adm_bc_set_payment_currency", style="primary"),
        Btn("💲  Sᴇᴛ Sʏᴍʙᴏʟ",   callback_data="adm_bc_set_currency_symbol",  style="primary"),
    )
    kb.add(Btn("INR ₹", callback_data="adm_bc_set_currency_INR_₹", style="primary"))
    kb.add(Btn(f"{G['back']}  Pᴀʏ Cᴏɴꜰɪɢ", callback_data="adm_pay_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_receipt_tmpl(call: types.CallbackQuery) -> None:
    cur = get_setting("tmpl_payment_received", "") or _MESSAGE_TEMPLATES["payment_received"]["default"]
    cap = (
        f"<b>🧾 {sc('Payment Receipt Template')}</b>\n"
        f"{G['div_eq']}\n"
        f"<i>{sc('Current template')}:</i>\n<code>{esc(cur[:300])}</code>\n"
        f"{G['div']}\n{sc('Variables')}: <code>{{name}}, {{amount}}, {{plan}}, {{tx_id}}, {{date}}</code>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("✏️  Eᴅɪᴛ",      callback_data="adm_tmpl_edit_payment_received", style="primary"),
        Btn("🔄  Rᴇꜱᴇᴛ",     callback_data="adm_tmpl_reset_payment_received", style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Pᴀʏ Cᴏɴꜰɪɢ", callback_data="adm_pay_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_pay_notif_settings(call: types.CallbackQuery) -> None:
    chan = get_setting("payment_notif_channel", "") or "—"
    on_new   = bool(get_setting("notif_on_new_payment", True))
    on_appr  = bool(get_setting("notif_on_approved",    True))
    on_rej   = bool(get_setting("notif_on_rejected",    True))
    cap = (
        f"<b>🔔 {sc('Payment Notifications')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Channel',    esc(chan))}\n"
        f"{bullet('New payment', '✅' if on_new else '❌')}\n"
        f"{bullet('Approved',   '✅' if on_appr else '❌')}\n"
        f"{bullet('Rejected',   '✅' if on_rej else '❌')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(Btn("📣  Sᴇᴛ Cʜᴀɴɴᴇʟ", callback_data="adm_bc_set_payment_notif_channel", style="primary"))
    kb.add(
        Btn(f"{'✅' if on_new else '❌'}  Nᴇᴡ Pᴀʏ",  callback_data="adm_bc_toggle_notif_on_new_payment",  style="primary"),
        Btn(f"{'✅' if on_appr else '❌'}  Aᴘᴘʀᴏᴠᴇᴅ",callback_data="adm_bc_toggle_notif_on_approved",    style="primary"),
    )
    kb.add(Btn(f"{'✅' if on_rej else '❌'}  Rᴇᴊᴇᴄᴛᴇᴅ", callback_data="adm_bc_toggle_notif_on_rejected", style="primary"))
    kb.add(Btn(f"{G['back']}  Pᴀʏ Cᴏɴꜰɪɢ", callback_data="adm_pay_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def action_adm_pay_method_number(call: types.CallbackQuery, data: str) -> None:
    """Handle toggle or set-number for a payment method."""
    if data.startswith("adm_pay_method_toggle_"):
        key = data[len("adm_pay_method_toggle_"):]
        cur = bool(get_setting(f"pm_enabled_{key}", True))
        set_setting(f"pm_enabled_{key}", not cur)
        audit(call.from_user.id, f"pm_toggle_{key}", f"now={not cur}")
        ack(call, f"{key}: {'enabled' if not cur else 'disabled'}")
        return render_adm_pay_method_edit(call, key)
    if data.startswith("adm_pay_method_setnumber_"):
        key = data[len("adm_pay_method_setnumber_"):]
        USER_STATES[call.from_user.id] = {"flow": "await_adm_pay_number", "pm_key": key}
        bot.send_message(call.message.chat.id,
                         f"{G['settings']} {sc('Send new UPI ID / payment details for')} "
                         f"<b>{esc(PAYMENT_METHODS.get(key,{}).get('name',key))}</b>:",
                         parse_mode="HTML")
        return


# ─────────────────────────────────────────────────────────────────────────────
# BOT CONFIG PANEL
# ─────────────────────────────────────────────────────────────────────────────

def _bc_get(key: str) -> Any:
    """Get a bot config value from settings, falling back to defaults."""
    return get_setting(f"bc_{key}", _BOT_CONFIG_DEFAULTS.get(key))


def _bc_set(key: str, val: Any) -> None:
    set_setting(f"bc_{key}", val)


def render_adm_bot_cfg(call: types.CallbackQuery) -> None:
    """Full bot configuration panel."""
    _mu  = str(_bc_get("max_upload_mb")) + " MB"
    _swd = str(_bc_get("sandbox_wipe_delay")) + "s"
    _bst = str(_bc_get("bot_start_timeout")) + "s"
    _bso = str(_bc_get("bot_stop_timeout")) + "s"
    _crd = str(_bc_get("crash_restart_delay")) + "s"
    cap = (
        f"<b>🔧 {sc('Bot Configuration')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Max Upload',          _mu)}\n"
        f"{bullet('Sandbox Wipe Delay',  _swd)}\n"
        f"{bullet('Start Timeout',       _bst)}\n"
        f"{bullet('Stop Timeout',        _bso)}\n"
        f"{bullet('Crash Restart Delay', _crd)}\n"
        f"{bullet('Max Crash Restarts',  _bc_get('max_crash_restarts'))}\n"
        f"{bullet('Log Ring Size',       _bc_get('log_ring_size'))}\n"
        f"{bullet('Zip Max Files',       _bc_get('zip_max_files'))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("⏱️  Tɪᴍᴇᴏᴜᴛꜱ",       callback_data="adm_bc_timeouts",  style="primary"),
        Btn("📊  Lɪᴍɪᴛꜱ",           callback_data="adm_bc_limits",    style="primary"),
    )
    kb.add(
        Btn("📦  Uᴘʟᴏᴀᴅ Rᴜʟᴇꜱ",    callback_data="adm_bc_upload",    style="primary"),
        Btn("🔐  Eɴᴠ Sᴛʀɪᴘ",        callback_data="adm_bc_env",       style="danger"),
    )
    kb.add(
        Btn("🔄  Rᴇꜱᴛᴀʀᴛ Pᴏʟɪᴄʏ",  callback_data="adm_bc_policy",    style="primary"),
        Btn("🧱  Sᴀɴᴅʙᴏx",           callback_data="adm_bc_sandbox",   style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_timeouts(call: types.CallbackQuery) -> None:
    _t1 = str(_bc_get("bot_start_timeout")) + "s"
    _t2 = str(_bc_get("bot_stop_timeout")) + "s"
    _t3 = str(_bc_get("crash_restart_delay")) + "s"
    _t4 = str(_bc_get("idle_timeout_mins") or "Off")
    _t5 = str(_bc_get("resource_check_secs")) + "s"
    cap = (
        f"<b>⏱️ {sc('Timeout Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Bot Start Timeout',       _t1)}\n"
        f"{bullet('Bot Stop Timeout',        _t2)}\n"
        f"{bullet('Crash Restart Delay',     _t3)}\n"
        f"{bullet('Idle Timeout (mins)',      _t4)}\n"
        f"{bullet('Resource Check Interval', _t5)}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, label in [
        ("bot_start_timeout",   "Start Timeout"),
        ("bot_stop_timeout",    "Stop Timeout"),
        ("crash_restart_delay", "Crash Delay"),
        ("idle_timeout_mins",   "Idle Timeout"),
        ("resource_check_secs", "Res Check"),
    ]:
        kb.add(Btn(f"✏️  {label}", callback_data=f"adm_bc_set_{k}", style="primary"))
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_limits(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>📊 {sc('Resource Limits')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Max Upload MB',       _bc_get('max_upload_mb'))}\n"
        f"{bullet('Max Crash Restarts',  _bc_get('max_crash_restarts'))}\n"
        f"{bullet('Log Ring Size',       _bc_get('log_ring_size'))}\n"
        f"{bullet('Zip Max Files',       _bc_get('zip_max_files'))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, label in [
        ("max_upload_mb",     "Max Upload MB"),
        ("max_crash_restarts","Max Crash Restarts"),
        ("log_ring_size",     "Log Ring Size"),
        ("zip_max_files",     "Zip Max Files"),
    ]:
        kb.add(Btn(f"✏️  {label}", callback_data=f"adm_bc_set_{k}", style="primary"))
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_upload(call: types.CallbackQuery) -> None:
    exts = _bc_get("allowed_extensions") or ".py,.js,.zip"
    cap = (
        f"<b>📦 {sc('Upload Rules')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Max Upload',        str(_bc_get('max_upload_mb')) + ' MB')}\n"
        f"{bullet('Allowed Ext',       esc(str(exts)))}\n"
        f"{bullet('Zip Max Files',     _bc_get('zip_max_files'))}\n"
        f"{G['div']}\n"
        f"{sc('Allowed extensions are comma-separated. E.g.')} <code>.py,.js,.zip</code>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("✏️  Max Upload MB",    callback_data="adm_bc_set_max_upload_mb",       style="primary"),
        Btn("✏️  Allowed Ext",      callback_data="adm_bc_set_allowed_extensions",  style="primary"),
    )
    kb.add(
        Btn("✏️  Zip Max Files",    callback_data="adm_bc_set_zip_max_files",       style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_env(call: types.CallbackQuery) -> None:
    strip = bool(_bc_get("env_strip_secrets"))
    names = list(SECRET_ENV_NAMES)
    cap = (
        f"<b>🔐 {sc('Environment Variable Control')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Strip Secrets', '✅ ON' if strip else '❌ OFF')}\n"
        f"{G['div']}\n"
        f"<b>{sc('Currently stripped env names')}:</b>\n"
        f"<code>{', '.join(names[:10])}</code>"
        f"{('...' if len(names) > 10 else '')}\n"
        f"{G['div']}\n{sc('When ON, child bots cannot access these env vars.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅' if strip else '❌'}  Sᴛʀɪᴘ Sᴇᴄʀᴇᴛꜱ",
            callback_data="adm_bc_toggle_env_strip_secrets",
            style="success" if strip else "danger"),
        Btn("➕  Aᴅᴅ Sᴇᴄʀᴇᴛ Nᴀᴍᴇ",  callback_data="adm_bc_set_add_secret_name",   style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_sandbox(call: types.CallbackQuery) -> None:
    wipe   = bool(get_setting("ff_sandbox_wipe", True))
    delay  = _bc_get("sandbox_wipe_delay")
    net    = bool(_bc_get("sandbox_network"))
    cap = (
        f"<b>🧱 {sc('Sandbox Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('File Wipe',   '✅ ON' if wipe else '❌ OFF')}\n"
        f"{bullet('Wipe Delay',  f'{delay}s after start')}\n"
        f"{bullet('Network',     '✅ Allowed' if net else '❌ Blocked')}\n"
        f"{G['div']}\n"
        f"<i>{sc('File Wipe removes source .py/.js files after bot starts so child bots cannot read their own code.')}</i>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅' if wipe else '❌'}  Fɪʟᴇ Wɪᴘᴇ",
            callback_data="adm_ff_toggle_sandbox_wipe",
            style="success" if wipe else "danger"),
        Btn("✏️  Wɪᴘᴇ Dᴇʟᴀʏ",     callback_data="adm_bc_set_sandbox_wipe_delay", style="primary"),
    )
    kb.add(
        Btn(f"{'✅' if net else '❌'}  Nᴇᴛᴡᴏʀᴋ",
            callback_data="adm_bc_toggle_sandbox_network",
            style="success" if net else "danger"),
    )
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_policy(call: types.CallbackQuery) -> None:
    auto_r  = bool(get_setting("ff_auto_restart_bots", True))
    max_r   = _bc_get("max_crash_restarts")
    delay_r = _bc_get("crash_restart_delay")
    auto_dg = bool(get_setting("auto_downgrade_expired", True))
    cap = (
        f"<b>🔄 {sc('Restart & Policy')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Auto-Restart Crashed', '✅ ON' if auto_r else '❌ OFF')}\n"
        f"{bullet('Max Restarts/hour',    max_r)}\n"
        f"{bullet('Restart Delay',        str(delay_r) + 's')}\n"
        f"{bullet('Auto-Downgrade Expiry','✅ ON' if auto_dg else '❌ OFF')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅' if auto_r else '❌'}  Aᴜᴛᴏ-Rᴇꜱᴛᴀʀᴛ",
            callback_data="adm_ff_toggle_auto_restart_bots",
            style="success" if auto_r else "danger"),
        Btn("✏️  Mᴀx Rᴇꜱᴛᴀʀᴛꜱ",   callback_data="adm_bc_set_max_crash_restarts", style="primary"),
    )
    kb.add(
        Btn("✏️  Rᴇꜱᴛᴀʀᴛ Dᴇʟᴀʏ",  callback_data="adm_bc_set_crash_restart_delay", style="primary"),
        Btn(f"{'✅' if auto_dg else '❌'}  Aᴜᴛᴏ-Dɢ",
            callback_data="adm_sub_auto_downgrade",
            style="success" if auto_dg else "danger"),
    )
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴꜰɪɢ", callback_data="adm_bot_cfg", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_config", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# APPEARANCE PANEL
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_appearance(call: types.CallbackQuery) -> None:
    theme    = get_setting("ui_theme", "dark")
    brand    = BRAND_TAG
    footer   = (get_setting("custom_footer", "") or "")[:40]
    welcome  = bool(get_setting("custom_welcome", ""))
    rules    = bool(get_setting("hosting_rules",  ""))
    cap = (
        f"<b>🎨 {sc('Appearance & Branding')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Theme',     esc(theme))}\n"
        f"{bullet('Brand Tag', esc(brand))}\n"
        f"{bullet('Footer',    esc(footer or '(default)'))}\n"
        f"{bullet('Custom Welcome', '✅' if welcome else '❌ (default)')}\n"
        f"{bullet('Custom Rules',   '✅' if rules else '❌ (default)')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🎭  Tʜᴇᴍᴇꜱ",            callback_data="adm_app_theme",      style="primary"),
        Btn("🏷️  Bʀᴀɴᴅ Tᴀɢ",         callback_data="adm_set_brand",      style="primary"),
    )
    kb.add(
        Btn("📝  Fᴏᴏᴛᴇʀ Tᴇxᴛ",       callback_data="adm_set_footer_text",    style="primary"),
        Btn("👋  Wᴇʟᴄᴏᴍᴇ Mꜱɢ",      callback_data="adm_set_welcome_text",   style="primary"),
    )
    kb.add(
        Btn("📜  Rᴜʟᴇꜱ Tᴇxᴛ",        callback_data="adm_set_rules_text",     style="primary"),
        Btn("😀  Cᴜꜱᴛᴏᴍ Eᴍᴏᴊɪꜱ",     callback_data="adm_app_emojis",         style="primary"),
    )
    kb.add(
        Btn("🖼️  Mᴇɴᴜ Pʜᴏᴛᴏꜱ",      callback_data="adm_photos",             style="primary"),
        Btn("📣  Aɴɴ Cʜᴀɴɴᴇʟ",       callback_data="adm_set_announce",       style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("appearance", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_app_theme(call: types.CallbackQuery) -> None:
    cur = get_setting("ui_theme", "dark")
    cap = (
        f"<b>🎭 {sc('UI Themes')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Current')}: <b>{esc(cur)}</b>\n"
        f"{G['div']}\n"
        + "\n".join(
            f"{'✅' if k == cur else '  '} <b>{v['name']}</b> — "
            f"header={v['header']} accent={v['accent']} ok={v['emoji_ok']}"
            for k, v in _APPEARANCE_THEMES.items()
        )
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, v in _APPEARANCE_THEMES.items():
        kb.add(Btn(f"{'✅' if k == cur else '  '} {v['name']}",
                   callback_data=f"adm_app_theme_{k}", style="primary"))
    kb.add(Btn(f"{G['back']}  Aᴘᴘᴇᴀʀᴀɴᴄᴇ", callback_data="adm_appearance", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("appearance", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_app_emojis(call: types.CallbackQuery) -> None:
    custom_emojis = get_setting("custom_emojis", {}) or {}
    sample_keys = ["ok", "no", "warn", "bullet", "div", "shield", "key"]
    rows = "\n".join(
        f"{G['bullet']} <code>{k}</code>: {custom_emojis.get(k, G.get(k, '?'))} "
        f"{'<i>(custom)</i>' if k in custom_emojis else '<i>(default)</i>'}"
        for k in sample_keys
    )
    cap = (
        f"<b>😀 {sc('Custom Emojis')}</b>\n"
        f"{G['div_eq']}\n"
        f"{rows}\n"
        f"{G['div']}\n"
        f"{sc('Tap a key to set a custom emoji. Use')} <code>-</code> {sc('to reset.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k in sample_keys:
        kb.add(Btn(f"✏️ {k}: {custom_emojis.get(k, G.get(k,'?'))}",
                   callback_data=f"adm_app_emoji_set_{k}", style="primary"))
    kb.add(Btn("🔄  Rᴇꜱᴇᴛ Aʟʟ", callback_data="adm_app_emoji_reset", style="danger"))
    kb.add(Btn(f"{G['back']}  Aᴘᴘᴇᴀʀᴀɴᴄᴇ", callback_data="adm_appearance", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("appearance", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_app_banner(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🖼️ {sc('Banner / Photo Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Each menu section has its own banner image.')}\n"
        f"{sc('Use Menu Photos to update each one by name.')}\n"
        f"{G['div']}\n"
        f"{bullet('Sections', len(PHOTOS))}\n"
        f"{bullet('Cached file IDs', len(_PHOTO_FILE_IDS))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(Btn("🖼️  Mᴇɴᴜ Pʜᴏᴛᴏꜱ", callback_data="adm_photos",     style="primary"))
    kb.add(Btn("🔄  Rᴇʙᴜɪʟᴅ Bᴀɴɴᴇʀꜱ", callback_data="adm_rebuild_banners", style="danger"))
    kb.add(Btn(f"{G['back']}  Aᴘᴘᴇᴀʀᴀɴᴄᴇ", callback_data="adm_appearance", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("appearance", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# ADVANCED COUPON MANAGER
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_coupon_plus(call: types.CallbackQuery) -> None:
    d = db_load()
    coupons = d["coupons"]
    total     = len(coupons)
    now_s     = ts_iso()
    active    = sum(1 for c in coupons.values()
                    if not (c.get("expiry") and c["expiry"] < now_s)
                    and c.get("uses_left", 1) != 0)
    expired   = total - active
    used_total = sum((c.get("max_uses", 1) - c.get("uses_left", 1))
                     for c in coupons.values() if c.get("max_uses"))
    cap = (
        f"<b>🎫 {sc('Advanced Coupon Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Coupons',   total)}\n"
        f"{bullet('Active',          active)}\n"
        f"{bullet('Expired/Used',    expired)}\n"
        f"{bullet('Total Redemptions', used_total)}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("➕  Cʀᴇᴀᴛᴇ Cᴏᴜᴘᴏɴ",   callback_data="adm_coupons",          style="success"),
        Btn("🗂️  Bᴜʟᴋ Cʀᴇᴀᴛᴇ",      callback_data="adm_coupon_bulk",      style="primary"),
    )
    kb.add(
        Btn("📊  Aɴᴀʟʏᴛɪᴄꜱ",        callback_data="adm_coupon_analytics", style="primary"),
        Btn("⏰  Exᴘɪʀʏ Mɢʀ",        callback_data="adm_coupon_expiry",    style="primary"),
    )
    kb.add(
        Btn("🗑️  Cʟᴇᴀʀ Exᴘɪʀᴇᴅ",   callback_data="adm_coupon_clearexp",  style="danger"),
        Btn("📋  Aʟʟ Cᴏᴜᴘᴏɴꜱ",      callback_data="adm_coupons",          style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("coupon_plus", PHOTOS["coupon"]), cap, kb, call=call)


def render_adm_coupon_bulk(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🗂️ {sc('Bulk Create Coupons')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Format (one per line or send count')}:\n"
        f"<code>count plan discount_pct [max_uses] [days_valid]</code>\n"
        f"{sc('Example')}:\n"
        f"<code>10 pro 20 1 30</code>\n"
        f"→ {sc('Creates 10 single-use coupons for pro plan at 20% off, valid 30 days')}{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_coupon_bulk"}
    show_menu(call.message.chat.id, PHOTOS.get("coupon_plus", PHOTOS["coupon"]), cap,
              _adm_back("adm_coupon_plus"), call=call)


def render_adm_coupon_analytics(call: types.CallbackQuery) -> None:
    coupons = db_load()["coupons"]
    now_s = ts_iso()
    by_plan: Dict[str, int] = defaultdict(int)
    by_discount: Dict[int, int] = defaultdict(int)
    total_savings: float = 0.0
    for c in coupons.values():
        pl = c.get("plan", "any")
        by_plan[pl] += 1
        disc = int(c.get("discount", c.get("pct", 0)))
        by_discount[disc] += 1
        used = c.get("max_uses", 1) - c.get("uses_left", 1)
        if used and c.get("plan") and PLAN_LIMITS.get(c["plan"]):
            price = PLAN_LIMITS[c["plan"]]["price"]
            total_savings += price * disc / 100 * used
    plan_rows = "\n".join(f"  {G['bullet']} {k}: {v}" for k, v in sorted(by_plan.items()))
    cap = (
        f"<b>📊 {sc('Coupon Analytics')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Coupons',    len(coupons))}\n"
        f"{bullet('Total Savings Given', money(total_savings))}\n"
        f"{G['div']}\n<b>{sc('By Plan')}:</b>\n{plan_rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("coupon_plus", PHOTOS["coupon"]), cap,
              _adm_back("adm_coupon_plus"), call=call)


def render_adm_coupon_expiry(call: types.CallbackQuery) -> None:
    coupons = db_load()["coupons"]
    now_s = ts_iso()
    expiring_soon = [
        (code, c) for code, c in coupons.items()
        if c.get("expiry") and c["expiry"] > now_s
        and c["expiry"] <= (now_utc() + timedelta(days=7)).isoformat()
    ]
    expired = [
        (code, c) for code, c in coupons.items()
        if c.get("expiry") and c["expiry"] < now_s
    ]
    rows_soon = "\n".join(
        f"{G['bullet']} <code>{esc(code)}</code> expires <i>{str(c['expiry'])[:10]}</i>"
        for code, c in expiring_soon[:10]
    ) or f"<i>{sc('None expiring soon')}</i>"
    cap = (
        f"<b>⏰ {sc('Coupon Expiry Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Expiring in 7 days', len(expiring_soon))}\n"
        f"{bullet('Already expired',    len(expired))}\n"
        f"{G['div']}\n<b>{sc('Expiring soon')}:</b>\n{rows_soon}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(Btn("🗑️  Cʟᴇᴀʀ Exᴘɪʀᴇᴅ", callback_data="adm_coupon_clearexp", style="danger"))
    kb.add(Btn(f"{G['back']}  Cᴏᴜᴘᴏɴ Mɢʀ", callback_data="adm_coupon_plus", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("coupon_plus", PHOTOS["coupon"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# TEMPLATE MANAGER
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_templates(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>📝 {sc('Message Template Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Customize every message the bot sends. Use placeholders like')} "
        f"<code>{{name}}</code>, <code>{{plan}}</code>, <code>{{amount}}</code> {sc('etc.')}\n"
        f"{G['div']}\n"
        + "\n".join(
            f"{G['bullet']} <b>{esc(v['label'])}</b> "
            f"{'✅ custom' if get_setting(f'tmpl_{k}') else '📄 default'}"
            for k, v in _MESSAGE_TEMPLATES.items()
        )
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, v in _MESSAGE_TEMPLATES.items():
        has_custom = bool(get_setting(f"tmpl_{k}"))
        kb.add(Btn(f"{'✅' if has_custom else '📄'} {v['label'][:25]}",
                   callback_data=f"adm_tmpl_edit_{k}", style="primary"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("templates", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# REFERRAL SYSTEM
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_referral_sys(call: types.CallbackQuery) -> None:
    enabled   = bool(get_setting("referral_enabled", True))
    reward    = get_setting("referral_reward_amount", 20)
    min_plan  = get_setting("referral_min_plan", "free")
    d = db_load()
    total_refs = sum(len(u.get("referrals", [])) for u in d["users"].values())
    total_paid = sum(u.get("referral_earnings", 0) for u in d["users"].values())
    cap = (
        f"<b>🔗 {sc('Referral System')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status',        '✅ Enabled' if enabled else '❌ Disabled')}\n"
        f"{bullet('Reward/Refer',  f'{money(reward)} wallet credit')}\n"
        f"{bullet('Min Plan',      min_plan)}\n"
        f"{bullet('Total Referrals', total_refs)}\n"
        f"{bullet('Total Paid Out',  money(total_paid))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅ Enabled' if enabled else '❌ Disabled'}",
            callback_data="adm_ref_toggle",
            style="success" if enabled else "danger"),
        Btn("📊  Rᴇꜰ Sᴛᴀᴛꜱ",    callback_data="adm_ref_stats",       style="primary"),
    )
    kb.add(
        Btn("🎁  Rᴇᴡᴀʀᴅ Cᴏɴꜰɪɢ",callback_data="adm_ref_rewards",     style="primary"),
        Btn("🏆  Lᴇᴀᴅᴇʀʙᴏᴀʀᴅ",   callback_data="adm_ref_leaderboard", style="primary"),
    )
    kb.add(
        Btn(f"✏️  Sᴇᴛ Rᴇᴡᴀʀᴅ {currency_symbol()}", callback_data="adm_ref_set_reward",   style="primary"),
        Btn("✏️  Sᴇᴛ Mɪɴ Pʟᴀɴ", callback_data="adm_ref_set_min_plan", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("referral_adm", PHOTOS["referral"]), cap, kb, call=call)


def render_adm_ref_stats(call: types.CallbackQuery) -> None:
    d = db_load()
    users = d["users"]
    top_refs   = sorted(users.items(), key=lambda x: len(x[1].get("referrals",[])), reverse=True)[:5]
    total_refs = sum(len(u.get("referrals",[])) for u in users.values())
    total_paid = sum(u.get("referral_earnings",0) for u in users.values())
    today_s    = now_utc().strftime("%Y-%m-%d")
    today_refs = sum(
        sum(1 for r in u.get("referrals",[]) if str(r.get("ts","")).startswith(today_s))
        for u in users.values()
    )
    rows = "\n".join(
        f"{i}. {esc(u.get('name','?')[:20])} — {len(u.get('referrals',[]))} refs "
        f"| earned {money(u.get('referral_earnings',0))}"
        for i, (uid, u) in enumerate(top_refs, 1)
    ) or f"<i>{sc('No referrals yet')}</i>"
    cap = (
        f"<b>📊 {sc('Referral Statistics')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Referrals', total_refs)}\n"
        f"{bullet('Today',           today_refs)}\n"
        f"{bullet('Total Paid',      money(total_paid))}\n"
        f"{G['div']}\n<b>{sc('Top Referrers')}:</b>\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("referral_adm", PHOTOS["referral"]), cap,
              _adm_back("adm_referral_sys"), call=call)


def render_adm_ref_rewards(call: types.CallbackQuery) -> None:
    reward = get_setting("referral_reward_amount", 20)
    bonus_plan = get_setting("referral_bonus_plan", "")
    bonus_refs = get_setting("referral_bonus_threshold", 10)
    cap = (
        f"<b>🎁 {sc('Referral Reward Config')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Base Reward', f'{money(reward)} per referral')}\n"
        f"{bullet('Bonus Plan',          bonus_plan or 'None')}\n"
        f"{bullet('Bonus Threshold',     f'{bonus_refs} refs needed for bonus')}\n"
        f"{G['div']}\n"
        f"{sc('Set a bonus plan reward for power referrers who hit the threshold.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("💰  Sᴇᴛ Bᴀꜱᴇ Rᴇᴡᴀʀᴅ",   callback_data="adm_ref_set_reward",      style="primary"),
        Btn("✏️  Sᴇᴛ Bᴏɴᴜꜱ Tʜʀ",     callback_data="adm_bc_set_referral_bonus_threshold", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Rᴇꜰᴇʀʀᴀʟ Sʏꜱ", callback_data="adm_referral_sys", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("referral_adm", PHOTOS["referral"]), cap, kb, call=call)


def render_adm_ref_leaderboard(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    top = sorted(users.items(),
                 key=lambda x: len(x[1].get("referrals",[])), reverse=True)[:15]
    rows = "\n".join(
        f"{i}. <b>{esc(u.get('name','?')[:20])}</b> — "
        f"{len(u.get('referrals',[]))} {sc('refs')} | "
        f"{money(u.get('referral_earnings',0))} {sc('earned')}"
        for i, (uid, u) in enumerate(top, 1)
    ) or f"<i>{sc('No referrals yet')}</i>"
    cap = (
        f"<b>🏆 {sc('Referral Leaderboard')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("referral_adm", PHOTOS["referral"]), cap,
              _adm_back("adm_referral_sys"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# JANITOR (AUTO-CLEANUP)
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_janitor(call: types.CallbackQuery) -> None:
    flags = {
        "clean_orphan_dirs":    "Auto-clean orphan sandboxes",
        "clean_old_logs":       "Auto-clear old logs (>7 days)",
        "clean_expired_coupons":"Auto-remove expired coupons",
        "auto_ban_rate_abuse":  "Auto-ban rate limit abusers",
        "clean_old_audit":      "Trim audit log (>1000 entries)",
        "notify_crashed":       "Notify owner on bot crash",
    }
    cap = (
        f"<b>🧹 {sc('Janitor — Auto-Cleanup Rules')}</b>\n"
        f"{G['div_eq']}\n"
        + "\n".join(
            f"{'✅' if get_setting(f'jan_{k}', False) else '❌'} {v}"
            for k, v in flags.items()
        )
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k, v in flags.items():
        on = bool(get_setting(f"jan_{k}", False))
        kb.add(Btn(f"{'✅' if on else '❌'} {v[:28]}",
                   callback_data=f"adm_jan_toggle_{k}", style="primary"))
    kb.add(
        Btn("▶️  Rᴜɴ Nᴏᴡ",         callback_data="adm_jan_run_now",   style="success"),
        Btn("📋  Jᴀɴ Rᴜʟᴇꜱ",       callback_data="adm_jan_rules",     style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("janitor", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_jan_rules(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>📋 {sc('Janitor Rule Details')}</b>\n"
        f"{G['div_eq']}\n"
        f"<b>{sc('Orphan Sandbox Cleanup')}:</b>\n"
        f"  {sc('Removes sandbox dirs with no matching bot record.')}\n\n"
        f"<b>{sc('Old Log Cleanup')}:</b>\n"
        f"  {sc('Clears log files older than 7 days from disk.')}\n\n"
        f"<b>{sc('Expired Coupon Cleanup')}:</b>\n"
        f"  {sc('Removes coupons past their expiry date automatically.')}\n\n"
        f"<b>{sc('Rate Abuse Auto-Ban')}:</b>\n"
        f"  {sc('Bans users exceeding rate limits 3+ times in 24h.')}\n\n"
        f"<b>{sc('Audit Log Trim')}:</b>\n"
        f"  {sc('Keeps only the last 1000 audit entries.')}\n\n"
        f"<b>{sc('Crash Notifications')}:</b>\n"
        f"  {sc('Sends owner a message when any bot crashes.')}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("janitor", PHOTOS["admin"]), cap,
              _adm_back("adm_janitor"), call=call)


def render_adm_jan_schedule(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>⏰ {sc('Janitor Schedule')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Orphan cleanup',        'Every 6 hours')}\n"
        f"{bullet('Log cleanup',           'Daily at 03:00')}\n"
        f"{bullet('Coupon cleanup',        'Daily at 04:00')}\n"
        f"{bullet('Audit trim',            'Daily at 05:00')}\n"
        f"{bullet('Rate abuse check',      'Every 30 minutes')}\n"
        f"{G['div']}\n"
        f"<i>{sc('Janitor runs automatically in background threads.')}</i>{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("janitor", PHOTOS["admin"]), cap,
              _adm_back("adm_janitor"), call=call)


def action_adm_jan_run(admin_uid: int) -> None:
    """Run all enabled janitor tasks immediately."""
    results: List[str] = []
    # Orphan cleanup
    if get_setting("jan_clean_orphan_dirs", False):
        try:
            dirs, files = _do_clean_orphans()
            results.append(f"✅ Orphan cleanup: {dirs} dirs, {files} files removed")
        except Exception as e:
            results.append(f"❌ Orphan cleanup: {e}")
    # Expired coupons
    if get_setting("jan_clean_expired_coupons", False):
        try:
            d = db_load()
            now_s = ts_iso()
            before = len(d["coupons"])
            d["coupons"] = {k: v for k, v in d["coupons"].items()
                            if not (v.get("expiry") and v["expiry"] < now_s)}
            removed = before - len(d["coupons"])
            db_save(d)
            results.append(f"✅ Expired coupons: {removed} removed")
        except Exception as e:
            results.append(f"❌ Coupon cleanup: {e}")
    # Audit trim
    if get_setting("jan_clean_old_audit", False):
        try:
            d = db_load()
            before = len(d.get("audit", []))
            d["audit"] = d.get("audit", [])[-1000:]
            db_save(d)
            results.append(f"✅ Audit trim: kept last 1000 of {before}")
        except Exception as e:
            results.append(f"❌ Audit trim: {e}")
    audit(admin_uid, "janitor_run_now", f"tasks={len(results)}")
    summary = "\n".join(results) or "No janitor tasks enabled"
    try:
        bot.send_message(admin_uid,
                         f"<b>🧹 {sc('Janitor Report')}</b>\n{G['div_eq']}\n{summary}",
                         parse_mode="HTML")
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# WEBHOOK MANAGER
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_webhooks(call: types.CallbackQuery) -> None:
    wh_url = get_setting("webhook_url", "") or ""
    wh_info: Dict[str, Any] = {}
    if wh_url:
        try:
            wh_info = bot.get_webhook_info().__dict__
        except Exception:
            wh_info = {}
    mode = "Webhook" if wh_url else "Long Polling"
    pending = wh_info.get("pending_update_count", 0)
    last_err= wh_info.get("last_error_message", "—")
    cap = (
        f"<b>🌐 {sc('Webhook Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Mode',           mode)}\n"
        f"{bullet('Webhook URL',    esc(wh_url[:50]) if wh_url else '—')}\n"
        f"{bullet('Pending Updates',pending)}\n"
        f"{bullet('Last Error',     esc(str(last_err)[:50]))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🔗  Sᴇᴛ Wᴇʙʜᴏᴏᴋ",    callback_data="adm_wh_set",   style="primary"),
        Btn("❌  Cʟᴇᴀʀ (Pᴏʟʟɪɴɢ)", callback_data="adm_wh_clear", style="danger"),
    )
    kb.add(
        Btn("🧪  Tᴇꜱᴛ Wᴇʙʜᴏᴏᴋ",   callback_data="adm_wh_test",  style="primary"),
        Btn("ℹ️  Wᴇʙʜᴏᴏᴋ Iɴꜰᴏ",   callback_data="adm_wh_info",  style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("webhooks", PHOTOS["admin"]), cap, kb, call=call)


def action_adm_wh_test(call: types.CallbackQuery) -> None:
    wh_url = get_setting("webhook_url", "")
    if not wh_url:
        ack(call, "No webhook URL set"); return
    ack(call, "Testing webhook…")
    def _bg() -> None:
        try:
            import urllib.request as _ur
            import json as _j
            payload = _j.dumps({"test": True, "ts": ts_iso(), "from": "KRYON_HOST"}).encode()
            req = _ur.Request(wh_url, data=payload, method="POST")
            req.add_header("Content-Type", "application/json")
            with _ur.urlopen(req, timeout=10) as resp:
                status = resp.status
            bot.send_message(call.from_user.id,
                             f"{G['ok']} {sc('Webhook test')}: HTTP {status} ✅")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('Webhook test failed')}: <code>{esc(e)}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def render_adm_wh_info(call: types.CallbackQuery) -> None:
    try:
        wi = bot.get_webhook_info()
        cap = (
            f"<b>ℹ️ {sc('Webhook Info')}</b>\n"
            f"{G['div_eq']}\n"
            f"{bullet('URL',             esc(str(wi.url or '—')[:60]))}\n"
            f"{bullet('Has Cert',        wi.has_custom_certificate)}\n"
            f"{bullet('Pending',         wi.pending_update_count)}\n"
            f"{bullet('Max Connections', wi.max_connections)}\n"
            f"{bullet('Last Error',      esc(str(wi.last_error_message or '—')[:60]))}\n"
            f"{bullet('Last Error Time', fmt_ts(wi.last_error_date))}\n"
            f"{bullet('IP Address',      wi.ip_address or '—')}\n"
            f"{G['div']}{FOOTER}"
        )
    except Exception as e:
        cap = f"{G['no']} {sc('Error')}: <code>{esc(e)}</code>{FOOTER}"
    show_menu(call.message.chat.id, PHOTOS.get("webhooks", PHOTOS["admin"]), cap,
              _adm_back("adm_webhooks"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# FEATURE FLAGS
# ─────────────────────────────────────────────────────────────────────────────



def render_adm_feature_flags(call: types.CallbackQuery) -> None:
    rows = []
    for k, default in _FEATURE_FLAG_DEFAULTS.items():
        val = _ff_get(k)
        rows.append(f"{'✅' if val else '❌'} <code>{k}</code>")
    cap = (
        f"<b>🎯 {sc('Feature Flags')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Toggle any system feature on or off instantly.')}\n"
        f"{G['div']}\n"
        + "\n".join(rows)
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for k in list(_FEATURE_FLAG_DEFAULTS.keys()):
        val = _ff_get(k)
        label = k.replace("_"," ").title()[:20]
        kb.add(Btn(f"{'✅' if val else '❌'} {label}",
                   callback_data=f"adm_ff_toggle_{k}", style="primary"))
    kb.add(Btn("🔄  Rᴇꜱᴇᴛ Aʟʟ Fʟᴀɢꜱ", callback_data="adm_ff_reset_all", style="danger"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("features", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# RATE LIMITER CONFIG
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_rate_config(call: types.CallbackQuery) -> None:
    global_rl = _ff_get("rate_limiting")
    cap = (
        f"<b>⏱️ {sc('Rate Limit Configuration')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Global Rate Limiting', '✅ ON' if global_rl else '❌ OFF')}\n"
        f"{G['div']}\n"
        + "\n".join(
            f"<b>{PLAN_LIMITS.get(plan,{}).get('name', plan)}</b>: "
            f"↑{get_setting(f'rl_{plan}_uploads_per_day', d['uploads_per_day'])}/day "
            f"▶{get_setting(f'rl_{plan}_starts_per_hour', d['starts_per_hour'])}/hr "
            f"💬{get_setting(f'rl_{plan}_msgs_per_min', d['msgs_per_min'])}/min"
            for plan, d in _RATE_LIMIT_DEFAULTS.items()
        )
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'✅ ON' if global_rl else '❌ OFF'}  Gʟᴏʙᴀʟ RL",
            callback_data="adm_ff_toggle_rate_limiting",
            style="success" if global_rl else "danger"),
    )
    for plan in _RATE_LIMIT_DEFAULTS:
        name = PLAN_LIMITS.get(plan, {}).get("name", plan)[:10]
        kb.add(Btn(f"✏️  {name}", callback_data=f"adm_rate_plan_{plan}", style="primary"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("rate_limits", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_rate_plan(call: types.CallbackQuery, plan: str) -> None:
    d = _RATE_LIMIT_DEFAULTS.get(plan, {})
    name = PLAN_LIMITS.get(plan, {}).get("name", plan)
    cap = (
        f"<b>⏱️ {sc('Rate Limits for')} {esc(name)}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Uploads/Day',    get_setting(f'rl_{plan}_uploads_per_day', d.get('uploads_per_day')))}\n"
        f"{bullet('Starts/Hour',    get_setting(f'rl_{plan}_starts_per_hour', d.get('starts_per_hour')))}\n"
        f"{bullet('Messages/Min',   get_setting(f'rl_{plan}_msgs_per_min',    d.get('msgs_per_min')))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=1)
    for metric in ("uploads_per_day", "starts_per_hour", "msgs_per_min"):
        kb.add(Btn(f"✏️  {metric.replace('_',' ').title()}",
                   callback_data=f"adm_rate_set_{plan}_{metric}", style="primary"))
    kb.add(Btn(f"{G['back']}  Rᴀᴛᴇ Cᴏɴꜰɪɢ", callback_data="adm_rate_config", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("rate_limits", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# LIVE MONITOR
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_live_monitor(call: types.CallbackQuery) -> None:
    running_bots = [(bid, info) for bid, info in RUNNING.items()
                    if info["proc"].poll() is None]
    crashed_bots = [(bid, info) for bid, info in RUNNING.items()
                    if info["proc"].poll() is not None]
    total_child_ram = 0
    total_child_cpu = 0.0
    if psutil:
        for bid, info in running_bots:
            try:
                p = psutil.Process(info["proc"].pid)
                total_child_ram += p.memory_info().rss
                total_child_cpu += p.cpu_percent(interval=0)
            except Exception:
                pass
    panel_ram = panel_cpu = 0
    if psutil:
        try:
            pp = psutil.Process(os.getpid())
            panel_ram = pp.memory_info().rss
            panel_cpu = pp.cpu_percent(interval=0.1)
        except Exception:
            pass
    up_s = int(time.time() - START_TIME) if "START_TIME" in globals() else 0
    cap = (
        f"<b>📡 {sc('Live Monitor')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Panel Uptime',   fmt_dur(up_s * 1000))}\n"
        f"{bullet('Panel RAM',      fmt_bytes(panel_ram))}\n"
        f"{bullet('Panel CPU',      f'{panel_cpu:.1f}%')}\n"
        f"{G['div']}\n"
        f"{bullet('▶ Running Bots',  len(running_bots))}\n"
        f"{bullet('💥 Crashed',      len(crashed_bots))}\n"
        f"{bullet('Child RAM Total', fmt_bytes(total_child_ram))}\n"
        f"{bullet('Child CPU Total', f'{total_child_cpu:.1f}%')}\n"
        f"{G['div']}\n"
        + "\n".join(
            f"  {G['bullet']} <code>{bid[:8]}</code> "
            f"{esc(info.get('name','?')[:18])}"
            for bid, info in running_bots[:8]
        )
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🔄  Rᴇꜰʀᴇꜱʜ",         callback_data="adm_monitor_refresh",  style="success"),
        Btn("🤖  Bᴏᴛ Dᴇᴛᴀɪʟꜱ",     callback_data="adm_monitor_bots",     style="primary"),
    )
    kb.add(
        Btn("🖥️  Sʏꜱᴛᴇᴍ",           callback_data="adm_monitor_system",   style="primary"),
        Btn("💥  Cʀᴀꜱʜᴇᴅ",          callback_data="adm_crashed_bots",     style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("monitor", PHOTOS["stats"]), cap, kb, call=call)


def render_adm_monitor_bots(call: types.CallbackQuery) -> None:
    rows: List[str] = []
    for bid, info in list(RUNNING.items())[:20]:
        rc = info["proc"].poll()
        is_running = rc is None
        b = find_bot(bid)
        name = (b.get("name","?") if b else bid)[:20]
        pid  = info["proc"].pid
        rss  = 0
        cpu  = 0.0
        if psutil and is_running:
            try:
                p = psutil.Process(pid)
                rss = p.memory_info().rss
                cpu = p.cpu_percent(interval=0)
            except Exception:
                pass
        status = "▶ running" if is_running else f"⏹ exit={rc}"
        rows.append(
            f"{G['bullet']} <b>{esc(name)}</b> <code>{bid[:8]}</code>\n"
            f"   {status} | PID {pid} | {fmt_bytes(rss)} | CPU {cpu:.1f}%"
        )
    cap = (
        f"<b>🤖 {sc('Bot Monitor')} ({len(RUNNING)} total)</b>\n"
        f"{G['div_eq']}\n"
        + ("\n".join(rows) or f"<i>{sc('No bots running')}</i>")
        + f"\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("monitor", PHOTOS["stats"]), cap,
              _adm_back("adm_live_monitor"), call=call)


def render_adm_monitor_system(call: types.CallbackQuery) -> None:
    cpu_pct = mem_pct = disk_pct = 0.0
    load1 = load5 = load15 = 0.0
    if psutil:
        try:
            cpu_pct  = psutil.cpu_percent(interval=0.3)
            vm       = psutil.virtual_memory()
            mem_pct  = vm.percent
            du       = psutil.disk_usage("/")
            disk_pct = du.percent
        except Exception:
            pass
    try:
        load1, load5, load15 = os.getloadavg()
    except Exception:
        pass
    def bar(pct: float) -> str:
        filled = int(pct / 10)
        return "█" * filled + "░" * (10 - filled) + f" {pct:.1f}%"
    cap = (
        f"<b>🖥️ {sc('System Monitor')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('CPU',       bar(cpu_pct))}\n"
        f"{bullet('Memory',    bar(mem_pct))}\n"
        f"{bullet('Disk',      bar(disk_pct))}\n"
        f"{bullet('Load 1m',   f'{load1:.2f}')}\n"
        f"{bullet('Load 5m',   f'{load5:.2f}')}\n"
        f"{bullet('Load 15m',  f'{load15:.2f}')}\n"
        f"{bullet('Threads',   threading.active_count())}\n"
        f"{bullet('PID',       os.getpid())}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("monitor", PHOTOS["stats"]), cap,
              _adm_back("adm_live_monitor"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# REVENUE GOALS
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_rev_goals(call: types.CallbackQuery) -> None:
    pays = db_load()["payments"]
    now  = now_utc()
    month_start = now.replace(day=1, hour=0, minute=0, second=0).strftime("%Y-%m")
    year_start  = now.strftime("%Y")
    rev_month = sum(p.get("amount",0) for p in pays
                    if p.get("status")=="approved" and str(p.get("ts","")).startswith(month_start))
    rev_year  = sum(p.get("amount",0) for p in pays
                    if p.get("status")=="approved" and str(p.get("ts","")).startswith(year_start))
    rev_all   = sum(p.get("amount",0) for p in pays if p.get("status")=="approved")
    goal_month = get_setting("rev_goal_monthly", 0)
    goal_year  = get_setting("rev_goal_yearly",  0)
    def progress_bar(cur: float, goal: float) -> str:
        if not goal:
            return "— (no goal set)"
        pct = min(100, cur * 100 / goal)
        filled = int(pct / 5)
        return "█" * filled + "░" * (20 - filled) + f" {pct:.1f}%"
    cap = (
        f"<b>💎 {sc('Revenue Goals')}</b>\n"
        f"{G['div_eq']}\n"
        f"<b>{sc('This Month')} ({month_start})</b>\n"
        f"  {sc('Earned')}: <b>{money(rev_month)}</b> / {money(goal_month) if goal_month is not None else '—'}\n"
        f"  {progress_bar(rev_month, goal_month)}\n"
        f"{G['div']}\n"
        f"<b>{sc('This Year')} ({year_start})</b>\n"
        f"  {sc('Earned')}: <b>{money(rev_year)}</b> / {money(goal_year) if goal_year is not None else '—'}\n"
        f"  {progress_bar(rev_year, goal_year)}\n"
        f"{G['div']}\n"
        f"{bullet('All Time',   money(rev_all))}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("🎯  Sᴇᴛ Mᴏɴᴛʜʟʏ Gᴏᴀʟ", callback_data="adm_goal_set_monthly", style="primary"),
        Btn("🎯  Sᴇᴛ Yᴇᴀʀʟʏ Gᴏᴀʟ",  callback_data="adm_goal_set_yearly",  style="primary"),
    )
    kb.add(
        Btn("📈  Hɪꜱᴛᴏʀʏ",           callback_data="adm_goal_history",     style="primary"),
        Btn("📊  Rᴇᴠᴇɴᴜᴇ Rᴇᴘᴏʀᴛ",   callback_data="adm_revenue_report",   style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("rev_goals", PHOTOS["stats"]), cap, kb, call=call)


def render_adm_goal_history(call: types.CallbackQuery) -> None:
    pays  = db_load()["payments"]
    now   = now_utc()
    months: Dict[str, float] = defaultdict(float)
    for p in pays:
        if p.get("status") != "approved":
            continue
        ts = str(p.get("ts", ""))
        if len(ts) >= 7:
            months[ts[:7]] += p.get("amount", 0)
    rows = "\n".join(
        f"{G['bullet']} <b>{m}</b>: {money(amt)}"
        for m, amt in sorted(months.items(), reverse=True)[:12]
    ) or f"<i>{sc('No revenue data')}</i>"
    cap = (
        f"<b>📈 {sc('Monthly Revenue History')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("rev_goals", PHOTOS["stats"]), cap,
              _adm_back("adm_rev_goals"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# TASK SCHEDULER
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_scheduler(call: types.CallbackQuery) -> None:
    tasks = get_setting("scheduled_tasks", []) or []
    enabled_n = sum(1 for t in tasks if t.get("enabled", True))
    cap = (
        f"<b>⏰ {sc('Task Scheduler')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Tasks',   len(tasks))}\n"
        f"{bullet('Enabled',       enabled_n)}\n"
        f"{bullet('Disabled',      len(tasks) - enabled_n)}\n"
        f"{G['div']}\n"
        + ("\n".join(
            f"{G['bullet']} {'✅' if t.get('enabled',True) else '⏸️'} "
            f"<b>{esc(t.get('type','?'))}</b> {t.get('time','?')} — "
            f"<i>{esc(str(t.get('msg',''))[:30])}</i>"
            for t in tasks[:10]
        ) or f"<i>{sc('No scheduled tasks')}</i>")
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("➕  Aᴅᴅ Tᴀꜱᴋ",      callback_data="adm_sched_add",  style="success"),
        Btn("📋  Aʟʟ Tᴀꜱᴋꜱ",     callback_data="adm_sched_list", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("scheduler", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_sched_list(call: types.CallbackQuery) -> None:
    tasks = get_setting("scheduled_tasks", []) or []
    cap = (
        f"<b>📋 {sc('Scheduled Tasks')}</b>\n"
        f"{G['div_eq']}\n"
        + ("\n".join(
            f"{G['bullet']} <code>{t.get('id','?')[:8]}</code> "
            f"{'✅' if t.get('enabled',True) else '⏸️'} "
            f"<b>{t.get('type','?')}</b> {t.get('time','?')}\n"
            f"   <i>{esc(str(t.get('msg',''))[:50])}</i>"
            for t in tasks
        ) or f"<i>{sc('No tasks')}</i>")
        + f"\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for t in tasks[:8]:
        tid = t.get("id","")
        en  = t.get("enabled", True)
        kb.add(
            Btn(f"{'⏸️' if en else '▶️'} {tid[:8]}",
                callback_data=f"adm_sched_toggle_{tid}", style="primary"),
            Btn(f"🗑️ {tid[:8]}",
                callback_data=f"adm_sched_del_{tid}",    style="danger"),
        )
    kb.add(Btn("➕  Aᴅᴅ Tᴀꜱᴋ",     callback_data="adm_sched_add",   style="success"))
    kb.add(Btn(f"{G['back']}  Sᴄʜᴇᴅᴜʟᴇʀ", callback_data="adm_scheduler", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("scheduler", PHOTOS["admin"]), cap, kb, call=call)


def _sched_check_and_run() -> None:
    """Background thread — runs every 60s, fires scheduled tasks."""
    while True:
        try:
            time.sleep(60)
            tasks = get_setting("scheduled_tasks", []) or []
            now_hm = now_utc().strftime("%H:%M")
            now_dt = now_utc().strftime("%Y-%m-%d %H:%M")
            changed = False
            for t in tasks:
                if not t.get("enabled", True):
                    continue
                ttype = t.get("type", "daily")
                ttime = t.get("time", "")
                msg   = t.get("msg", "")
                if not msg:
                    continue
                fire = False
                if ttype == "daily" and ttime == now_hm:
                    fire = True
                elif ttype == "once" and ttime == now_dt:
                    fire = True
                    t["enabled"] = False
                    changed = True
                if fire:
                    _sched_broadcast(msg)
        except Exception:
            pass
        if True:  # always loop
            pass




# ─────────────────────────────────────────────────────────────────────────────
# IMPORT / EXPORT
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_import_export(call: types.CallbackQuery) -> None:
    settings_size = SETTINGS_FILE.stat().st_size if SETTINGS_FILE.exists() else 0
    db_size       = DB_FILE.stat().st_size if DB_FILE.exists() else 0
    cap = (
        f"<b>📥 {sc('Import / Export')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Settings File',  fmt_bytes(settings_size))}\n"
        f"{bullet('Database File',  fmt_bytes(db_size))}\n"
        f"{G['div']}\n"
        f"{sc('Export: download a full config backup (settings only, no user data). ')}\n"
        f"{sc('Import: upload a previously exported config to restore settings. ')}\n"
        f"{sc('User Export: CSV of all users.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📤  Exᴘᴏʀᴛ Cᴏɴꜰɪɢ",  callback_data="adm_export_full_cfg", style="success"),
        Btn("📥  Iᴍᴘᴏʀᴛ Cᴏɴꜰɪɢ",  callback_data="adm_import_cfg",      style="primary"),
    )
    kb.add(
        Btn("👥  Exᴘᴏʀᴛ Uꜱᴇʀꜱ CSV",callback_data="adm_user_export_csv", style="primary"),
        Btn("🗄️  Fᴏʀᴄᴇ Bᴀᴄᴋᴜᴘ",   callback_data="adm_force_backup",    style="primary"),
    )
    kb.add(
        Btn("♻️  Fᴀᴄᴛᴏʀʏ Rᴇꜱᴇᴛ",  callback_data="adm_import_reset",    style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("import_export", PHOTOS["admin"]), cap, kb, call=call)


def action_adm_export_full_cfg(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    ack(call, "Preparing config export…")
    def _bg() -> None:
        try:
            import json as _j
            settings = {}
            if SETTINGS_FILE.exists():
                with _db_lock:
                    with SETTINGS_FILE.open("r", encoding="utf-8") as f:
                        settings = _j.load(f)
            # Strip sensitive values
            safe_settings = {k: v for k, v in settings.items()
                             if not any(s in k.lower()
                                        for s in ("token","secret","key","password","mongo"))}
            export_data = {
                "export_ts":    ts_iso(),
                "bot_version":  "2.1",
                "brand_tag":    BRAND_TAG,
                "settings":     safe_settings,
                "plan_limits":  {k: {kk: vv for kk, vv in v.items()
                                     if kk not in ("price",)}
                                 for k, v in PLAN_LIMITS.items()},
                "feature_flags":{k: _ff_get(k) for k in _FEATURE_FLAG_DEFAULTS},
            }
            tmp = Path(tempfile.mktemp(suffix="_config_export.json"))
            tmp.write_text(_j.dumps(export_data, indent=2, ensure_ascii=False), encoding="utf-8")
            with tmp.open("rb") as fh:
                bot.send_document(call.from_user.id, fh,
                                  caption=f"📥 {sc('Config Export')} — {ts_iso()[:10]}",
                                  visible_file_name="bot_config_export.json")
            tmp.unlink(missing_ok=True)
            audit(call.from_user.id, "export_config", "")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                                 f"{G['no']} {sc('Export error')}: <code>{esc(e)}</code>",
                                 parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


# ─────────────────────────────────────────────────────────────────────────────
# ADMIN 2FA
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_admin_2fa(call: types.CallbackQuery) -> None:
    enabled = bool(get_setting("admin_2fa_enabled", False))
    secret  = get_setting("admin_2fa_secret", "")
    cap = (
        f"<b>🔐 {sc('Admin 2FA')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status',  '✅ Enabled' if enabled else '❌ Disabled')}\n"
        f"{bullet('Secret',  '✅ Set' if secret else '❌ Not configured')}\n"
        f"{G['div']}\n"
        f"<i>{sc('2FA adds an extra TOTP code requirement for critical admin actions. ')}"
        f"{sc('Use any authenticator app (Google Authenticator, Authy, etc.).')}</i>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    if not secret:
        kb.add(Btn("🔑  Sᴇᴛᴜᴘ 2FA", callback_data="adm_2fa_setup", style="success"))
    else:
        kb.add(
            Btn(f"{'✅ ON' if enabled else '❌ OFF'}  Tᴏɢɢʟᴇ",
                callback_data="adm_bc_toggle_admin_2fa_enabled",
                style="success" if enabled else "danger"),
            Btn("🗑️  Dɪꜱᴀʙʟᴇ+Rᴇꜱᴇᴛ", callback_data="adm_2fa_disable", style="danger"),
        )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("admin_2fa", PHOTOS["security"]), cap, kb, call=call)


def action_adm_2fa_setup(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    try:
        secret = base64.b32encode(secrets.token_bytes(20)).decode("utf-8").rstrip("=")
        set_setting("admin_2fa_secret", secret)
        set_setting("admin_2fa_enabled", False)
        audit(call.from_user.id, "2fa_setup", "secret generated")
        user = db_load()["users"].get(str(call.from_user.id), {})
        label = f"{BRAND_TAG}:{user.get('username','admin')}"
        otp_url = f"otpauth://totp/{label}?secret={secret}&issuer={BRAND_TAG}"
        bot.send_message(
            call.from_user.id,
            f"<b>🔐 {sc('2FA Setup')}</b>\n{G['div_eq']}\n"
            f"{sc('Scan this secret in your authenticator app')}:\n\n"
            f"<code>{secret}</code>\n\n"
            f"{sc('OTP URL')}:\n<code>{otp_url}</code>\n\n"
            f"<i>{sc('After adding to authenticator, use the toggle to enable 2FA.')}</i>",
            parse_mode="HTML"
        )
        render_adm_admin_2fa(call)
    except Exception as e:
        ack(call, f"Error: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# LEADERBOARD
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_leaderboard(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>🏆 {sc('Leaderboard')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('View top users by different metrics.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("💰  Tᴏᴘ Sᴘᴇɴᴅᴇʀꜱ",   callback_data="adm_lb_spenders",  style="success"),
        Btn("🤖  Mᴏꜱᴛ Bᴏᴛꜱ",      callback_data="adm_lb_bots",       style="primary"),
    )
    kb.add(
        Btn("🔗  Tᴏᴘ Rᴇꜰᴇʀʀᴇʀꜱ",  callback_data="adm_lb_referrals",  style="primary"),
        Btn("⚡  Mᴏꜱᴛ Aᴄᴛɪᴠᴇ",    callback_data="adm_lb_active",     style="primary"),
    )
    kb.add(
        Btn("⏱️  Lᴏɴɢᴇꜱᴛ Uᴘᴛɪᴍᴇ", callback_data="adm_lb_uptime",     style="primary"),
        Btn("🏆  Aʟʟ Lʙꜱ",         callback_data="adm_top_users",     style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap, kb, call=call)


def render_adm_lb_spenders(call: types.CallbackQuery) -> None:
    pays = db_load()["payments"]
    spend: Dict[str, float] = defaultdict(float)
    for p in pays:
        if p.get("status") == "approved":
            spend[str(p.get("uid", ""))] += p.get("amount", 0)
    top = sorted(spend.items(), key=lambda x: x[1], reverse=True)[:15]
    users_db = db_load()["users"]
    rows = "\n".join(
        f"{i}. <b>{esc(users_db.get(uid,{}).get('name','?')[:20])}</b> "
        f"<code>{uid}</code> — <b>{money(amt)}</b>"
        for i, (uid, amt) in enumerate(top, 1)
    ) or f"<i>{sc('No data')}</i>"
    cap = f"<b>💰 {sc('Top Spenders')}</b>\n{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap,
              _adm_back("adm_leaderboard"), call=call)


def render_adm_lb_bots(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"]
    by_owner: Dict[str, int] = defaultdict(int)
    for b in bots.values():
        by_owner[str(b.get("owner",""))] += 1
    top = sorted(by_owner.items(), key=lambda x: x[1], reverse=True)[:15]
    users_db = db_load()["users"]
    rows = "\n".join(
        f"{i}. <b>{esc(users_db.get(uid,{}).get('name','?')[:20])}</b> — {n} bots"
        for i, (uid, n) in enumerate(top, 1)
    ) or f"<i>{sc('No data')}</i>"
    cap = f"<b>🤖 {sc('Most Bots')}</b>\n{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap,
              _adm_back("adm_leaderboard"), call=call)


def render_adm_lb_referrals(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    top = sorted(users.items(),
                 key=lambda x: len(x[1].get("referrals",[])), reverse=True)[:15]
    rows = "\n".join(
        f"{i}. <b>{esc(u.get('name','?')[:20])}</b> — "
        f"{len(u.get('referrals',[]))} refs | {money(u.get('referral_earnings',0))}"
        for i, (uid, u) in enumerate(top, 1) if u.get("referrals")
    ) or f"<i>{sc('No referrals yet')}</i>"
    cap = f"<b>🔗 {sc('Top Referrers')}</b>\n{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap,
              _adm_back("adm_leaderboard"), call=call)


def render_adm_lb_active(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    top = sorted(users.items(),
                 key=lambda x: x[1].get("last_seen", ""), reverse=True)[:15]
    rows = "\n".join(
        f"{i}. <b>{esc(u.get('name','?')[:20])}</b> — "
        f"last: <i>{str(u.get('last_seen','?'))[:10]}</i>"
        for i, (uid, u) in enumerate(top, 1)
    ) or f"<i>{sc('No data')}</i>"
    cap = f"<b>⚡ {sc('Most Recently Active')}</b>\n{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap,
              _adm_back("adm_leaderboard"), call=call)


def render_adm_lb_uptime(call: types.CallbackQuery) -> None:
    running = [(bid, info) for bid, info in RUNNING.items()
               if info["proc"].poll() is None]
    rows: List[str] = []
    for i, (bid, info) in enumerate(running[:15], 1):
        started = info.get("started_at", 0)
        uptime  = int(time.time() - started) if started else 0
        b       = find_bot(bid)
        name    = (b.get("name","?") if b else bid)[:20]
        rows.append(f"{i}. <b>{esc(name)}</b> — {fmt_dur(uptime * 1000)} uptime")
    cap = (
        f"<b>⏱️ {sc('Longest Uptime Bots')}</b>\n"
        f"{G['div_eq']}\n"
        + ("\n".join(rows) or f"<i>{sc('No running bots')}</i>")
        + f"\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("leaderboard", PHOTOS["stats"]), cap,
              _adm_back("adm_leaderboard"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# MULTI-LANGUAGE
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_languages(call: types.CallbackQuery) -> None:
    cur = get_setting("default_language", "en")
    cur_name = _SUPPORTED_LANGUAGES.get(cur, cur)
    cap = (
        f"<b>🌍 {sc('Language Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Default Language', esc(cur_name))}\n"
        f"{bullet('Total Supported',  len(_SUPPORTED_LANGUAGES))}\n"
        f"{G['div']}\n"
        f"<i>{sc('Setting a default language affects message templates and bot UI text for users who have not set a personal language.')}</i>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for code, name in _SUPPORTED_LANGUAGES.items():
        kb.add(Btn(f"{'✅' if code == cur else '  '} {name}",
                   callback_data=f"adm_lang_set_{code}", style="primary"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("lang_panel", PHOTOS["admin"]), cap, kb, call=call)


# ─────────────────────────────────────────────────────────────────────────────
# PER-BOT CONTROLS
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_bot_controls_panel(call: types.CallbackQuery) -> None:
    d = db_load()
    total   = len(d["bots"])
    running = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    cap = (
        f"<b>🤖 {sc('Per-Bot Controls')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Bots',  total)}\n"
        f"{bullet('Running',     running)}\n"
        f"{G['div']}\n"
        f"{sc('Search, inspect, or manage individual bots.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📋  Lɪꜱᴛ Aʟʟ Bᴏᴛꜱ",   callback_data="adm_bc_list_all",  style="primary"),
        Btn("🔍  Sᴇᴀʀᴄʜ Bᴏᴛ",       callback_data="adm_bot_search",   style="primary"),
    )
    kb.add(
        Btn("💥  Cʀᴀꜱʜᴇᴅ Bᴏᴛꜱ",    callback_data="adm_crashed_bots", style="danger"),
        Btn("📦  Sɪᴢᴇ Rᴇᴘᴏʀᴛ",      callback_data="adm_bot_size_report", style="primary"),
    )
    kb.add(
        Btn("🔴  Kɪʟʟ Aʟʟ",         callback_data="adm_kill_all_now", style="danger"),
        Btn("🔄  Rᴇꜱᴛᴀʀᴛ Sᴛᴏᴘᴘᴇᴅ",  callback_data="adm_mass_restart_stopped", style="success"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_controls", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_list_all(call: types.CallbackQuery) -> None:
    bots = db_load()["bots"]
    page = 0  # pagination
    page_size = 8
    bot_items = list(bots.items())
    total_pages = max(1, (len(bot_items) + page_size - 1) // page_size)
    page_bots   = bot_items[page * page_size:(page + 1) * page_size]
    rows = "\n".join(
        f"{G['bullet']} <code>{bid[:8]}</code> <b>{esc(b.get('name','?')[:20])}</b> "
        f"uid={b.get('owner','?')} "
        f"{'▶' if bid in RUNNING and RUNNING[bid]['proc'].poll() is None else '⏹'}"
        for bid, b in page_bots
    ) or f"<i>{sc('No bots')}</i>"
    cap = (
        f"<b>📋 {sc('All Bots')} ({len(bots)} total)</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for bid, b in page_bots:
        is_running = bid in RUNNING and RUNNING[bid]["proc"].poll() is None
        icon = "▶" if is_running else "⏹"
        kb.add(Btn(f"{icon} {esc(b.get('name','?')[:22])}",
                   callback_data=f"adm_bcbot_{bid[:20]}", style="primary"))
    kb.add(Btn(f"{G['back']}  Bᴏᴛ Cᴏɴᴛʀᴏʟꜱ", callback_data="adm_bot_controls", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_controls", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_single(call: types.CallbackQuery, bid: str) -> None:
    b = find_bot(bid)
    if not b:
        ack(call, "Bot not found"); return
    is_running = bid in RUNNING and RUNNING[bid]["proc"].poll() is None
    pid = RUNNING[bid]["proc"].pid if bid in RUNNING else 0
    rss = 0
    if psutil and is_running and pid:
        try:
            rss = psutil.Process(pid).memory_info().rss
        except Exception:
            pass
    cap = (
        f"<b>🤖 {esc(b.get('name','?'))}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('ID',       f'<code>{bid}</code>')}\n"
        f"{bullet('Owner',    str(b.get('owner','?')))}\n"
        f"{bullet('Plan',     b.get('plan','free'))}\n"
        f"{bullet('Status',   '▶ Running' if is_running else '⏹ Stopped')}\n"
        f"{bullet('PID',      pid or '—')}\n"
        f"{bullet('RAM',      fmt_bytes(rss) if rss else '—')}\n"
        f"{bullet('Approval', b.get('approval_status','?'))}\n"
        f"{bullet('Files',    len(b.get('enc_files',{})))}\n"
        f"{bullet('Source',   esc(b.get('source','local')[:30]))}\n"
        f"{bullet('Created',  str(b.get('created_at','?'))[:10])}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    if is_running:
        kb.add(
            Btn("⏹  Sᴛᴏᴘ",       callback_data=f"adm_bc_stop_{bid[:20]}",    style="danger"),
            Btn("🔄  Rᴇꜱᴛᴀʀᴛ",   callback_data=f"adm_bc_restart_{bid[:20]}", style="success"),
        )
    else:
        kb.add(Btn("▶️  Sᴛᴀʀᴛ",   callback_data=f"adm_bc_restart_{bid[:20]}", style="success"))
    kb.add(
        Btn("📋  Lᴏɢꜱ",           callback_data=f"adm_bc_logs_{bid[:20]}",    style="primary"),
        Btn("🔐  Eɴᴠ Eᴅɪᴛᴏʀ",    callback_data=f"adm_bc_env_{bid[:20]}",     style="primary"),
    )
    kb.add(
        Btn("📊  Rᴇꜱᴏᴜʀᴄᴇꜱ",     callback_data=f"adm_bc_res_{bid[:20]}",     style="primary"),
        Btn("🗑️  Dᴇʟᴇᴛᴇ",        callback_data=f"adm_bc_del_{bid[:20]}",     style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aʟʟ Bᴏᴛꜱ", callback_data="adm_bc_list_all", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("bot_controls", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_bc_env_editor(call: types.CallbackQuery, bid: str) -> None:
    b = find_bot(bid)
    if not b:
        ack(call, "Bot not found"); return
    env = b.get("env", {})
    def _mask_env(k: str, v: Any) -> str:
        text = str(v or "")
        sensitive = k in SECRET_ENV_NAMES or any(x in k for x in ("TOKEN", "PASSWORD", "SECRET", "API_KEY", "API_HASH"))
        if sensitive:
            return (text[:4] + "…" + text[-4:]) if len(text) > 10 else "••••••"
        return text[:40]
    rows = "\n".join(
        f"{G['bullet']} <code>{esc(k)}</code> = <code>{esc(_mask_env(k, v))}</code>"
        for k, v in env.items()
    ) or f"<i>{sc('No env vars set')}</i>"
    cap = (
        f"<b>🔐 {sc('Env Editor')}: {esc(b.get('name','?'))}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}\n"
        f"{sc('To add/change')}: send <code>KEY=value</code>\n"
        f"{sc('To remove')}: send <code>del KEY</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_adm_bot_env_edit", "bot_id": bid}
    show_menu(call.message.chat.id, PHOTOS.get("bot_controls", PHOTOS["admin"]), cap,
              _adm_back(f"adm_bcbot_{bid[:20]}"), call=call)


def render_adm_bc_resources(call: types.CallbackQuery, bid: str) -> None:
    b = find_bot(bid)
    if not b:
        ack(call, "Bot not found"); return
    is_running = bid in RUNNING and RUNNING[bid]["proc"].poll() is None
    rss = vms = cpu = 0
    num_threads = num_fds = 0
    if psutil and is_running:
        try:
            proc = psutil.Process(RUNNING[bid]["proc"].pid)
            mi   = proc.memory_info()
            rss, vms = mi.rss, mi.vms
            cpu  = proc.cpu_percent(interval=0.2)
            num_threads = proc.num_threads()
            try:
                num_fds = proc.num_fds()
            except Exception:
                pass
        except Exception:
            pass
    # Disk usage
    bot_dir = Path(b.get("dir", ""))
    disk = 0
    if bot_dir.exists():
        for root, _, files in os.walk(bot_dir):
            for f in files:
                try:
                    disk += (Path(root) / f).stat().st_size
                except OSError:
                    pass
    cap = (
        f"<b>📊 {sc('Resource Usage')}: {esc(b.get('name','?'))}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status',   '▶ Running' if is_running else '⏹ Stopped')}\n"
        f"{bullet('RAM RSS',  fmt_bytes(rss))}\n"
        f"{bullet('RAM VMS',  fmt_bytes(vms))}\n"
        f"{bullet('CPU %',    f'{cpu:.1f}%')}\n"
        f"{bullet('Threads',  num_threads)}\n"
        f"{bullet('Open FDs', num_fds)}\n"
        f"{bullet('Disk',     fmt_bytes(disk))}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("bot_controls", PHOTOS["admin"]), cap,
              _adm_back(f"adm_bcbot_{bid[:20]}"), call=call)


def render_adm_bc_logs(call: types.CallbackQuery, bid: str) -> None:
    b = find_bot(bid)
    if not b:
        ack(call, "Bot not found"); return
    ring: Deque = RUNNING.get(bid, {}).get("log_ring") or deque(maxlen=200)
    lines = list(ring)[-40:]
    log_text = "\n".join(lines) or f"({sc('No logs available')})"
    cap = (
        f"<b>📋 {sc('Logs')}: {esc(b.get('name','?'))}</b>\n"
        f"{G['div_eq']}\n"
        f"<pre>{esc(log_text[:3000])}</pre>{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("logs", PHOTOS["admin"]), cap,
              _adm_back(f"adm_bcbot_{bid[:20]}"), call=call)


# ─────────────────────────────────────────────────────────────────────────────
# SUBSCRIPTION MANAGER
# ─────────────────────────────────────────────────────────────────────────────

def render_adm_subscriptions(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    now_s = ts_iso()
    paid_users   = [u for u in users.values() if u.get("plan","free") != "free"]
    expiring_7d  = []
    expired_sub  = []
    for u in paid_users:
        exp = u.get("plan_expiry")
        if not exp:
            continue
        if exp < now_s:
            expired_sub.append(u)
        elif exp < (now_utc() + timedelta(days=7)).isoformat():
            expiring_7d.append(u)
    auto_dg = bool(get_setting("auto_downgrade_expired", True))
    cap = (
        f"<b>👤 {sc('Subscription Manager')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Paid Users',       len(paid_users))}\n"
        f"{bullet('Expiring in 7d',   len(expiring_7d))}\n"
        f"{bullet('Already Expired',  len(expired_sub))}\n"
        f"{bullet('Auto-Downgrade',   '✅ ON' if auto_dg else '❌ OFF')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("⏰  Exᴘɪʀɪɴɢ Sᴏᴏɴ",    callback_data="adm_sub_expiring",      style="danger"),
        Btn("❌  Exᴘɪʀᴇᴅ",           callback_data="adm_sub_expired",        style="primary"),
    )
    kb.add(
        Btn("📨  Rᴇᴍɪɴᴅ Aʟʟ",       callback_data="adm_sub_remind_all",     style="success"),
        Btn("➕  Exᴛᴇɴᴅ Sᴜʙ",       callback_data="adm_sub_extend_prompt",  style="primary"),
    )
    kb.add(
        Btn(f"{'✅' if auto_dg else '❌'}  Aᴜᴛᴏ-Dɢ",
            callback_data="adm_sub_auto_downgrade",
            style="success" if auto_dg else "danger"),
        Btn("⚡  Rᴜɴ Dᴏᴡɴɢʀᴀᴅᴇ",    callback_data="adm_sub_run_downgrade",  style="danger"),
    )
    kb.add(
        Btn("📋  Sᴜʙ Hɪꜱᴛᴏʀʏ",      callback_data="adm_sub_history",        style="primary"),
        Btn("💰  Pᴀʏᴍᴇɴᴛꜱ",         callback_data="adm_payments",           style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("subscriptions", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_sub_expiring(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    now_s = ts_iso()
    soon_s = (now_utc() + timedelta(days=7)).isoformat()
    expiring = [(uid, u) for uid, u in users.items()
                if u.get("plan_expiry") and now_s < u["plan_expiry"] <= soon_s]
    rows = "\n".join(
        f"{G['bullet']} <code>{uid}</code> <b>{esc(u.get('name','?')[:20])}</b> "
        f"plan={u.get('plan','?')} "
        f"exp={str(u.get('plan_expiry','?'))[:10]}"
        for uid, u in expiring[:20]
    ) or f"<i>{sc('No expiring subscriptions')}</i>"
    cap = (
        f"<b>⏰ {sc('Expiring in 7 Days')} ({len(expiring)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("subscriptions", PHOTOS["admin"]), cap,
              _adm_back("adm_subscriptions"), call=call)


def render_adm_sub_expired(call: types.CallbackQuery) -> None:
    users = db_load()["users"]
    now_s = ts_iso()
    expired = [(uid, u) for uid, u in users.items()
               if u.get("plan_expiry") and u["plan_expiry"] < now_s
               and u.get("plan","free") != "free"]
    rows = "\n".join(
        f"{G['bullet']} <code>{uid}</code> <b>{esc(u.get('name','?')[:20])}</b> "
        f"plan={u.get('plan','?')} "
        f"exp={str(u.get('plan_expiry','?'))[:10]}"
        for uid, u in expired[:20]
    ) or f"<i>{sc('No expired subscriptions with active plans')}</i>"
    cap = (
        f"<b>❌ {sc('Expired Subscriptions')} ({len(expired)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("subscriptions", PHOTOS["admin"]), cap,
              _adm_back("adm_subscriptions"), call=call)


def action_adm_sub_remind_all(admin_uid: int) -> None:
    """Send renewal reminders to all users with expiring subscriptions."""
    users = db_load()["users"]
    now_s = ts_iso()
    soon_s = (now_utc() + timedelta(days=7)).isoformat()
    sent = fail = 0
    for uid, u in users.items():
        exp = u.get("plan_expiry")
        if not exp or exp < now_s or exp > soon_s:
            continue
        plan_name = PLAN_LIMITS.get(u.get("plan","free"), {}).get("name", u.get("plan","?"))
        days_left = max(0, (datetime.fromisoformat(exp.replace("Z","")) -
                            now_utc().replace(tzinfo=None)).days)
        tmpl = get_setting("tmpl_plan_expired", "") or _MESSAGE_TEMPLATES["plan_expired"]["default"]
        msg = (tmpl.replace("{name}", u.get("name","User"))
                    .replace("{plan}", plan_name)
                    .replace("{days}", str(days_left))
                    .replace("{expiry_date}", str(exp)[:10]))
        try:
            bot.send_message(int(uid), msg)
            sent += 1
        except Exception:
            fail += 1
        time.sleep(0.05)
    audit(admin_uid, "sub_remind_all", f"sent={sent} fail={fail}")
    try:
        bot.send_message(admin_uid,
                         f"{G['ok']} {sc('Renewal reminders sent')}: {sent} ok, {fail} failed.")
    except Exception:
        pass


def action_adm_downgrade_expired(admin_uid: int) -> None:
    """Downgrade all expired paid users to free plan."""
    d = db_load()
    now_s = ts_iso()
    downgraded = 0
    for uid, u in d["users"].items():
        exp = u.get("plan_expiry")
        if exp and exp < now_s and u.get("plan","free") != "free":
            u["plan"] = "free"
            u["plan_expiry"] = None
            downgraded += 1
    db_save(d)
    audit(admin_uid, "downgrade_expired", f"count={downgraded}")
    try:
        bot.send_message(admin_uid,
                         f"{G['ok']} {sc('Downgraded')} {downgraded} {sc('expired subscriptions to free')}.")
    except Exception:
        pass


# ═══════════════════════ END MEGA ADVANCED PANELS ════════════════════════════


def _do_restart_all_bots(admin_uid: int) -> Tuple[int, int]:
    """Restart every bot that is currently running. Returns (ok, fail)."""
    ok = fail = 0
    for bid in list(RUNNING.keys()):
        b = find_bot(bid)
        if not b:
            continue
        try:
            r = restart_child(b)
            if r.get("ok"):
                ok += 1
            else:
                fail += 1
        except Exception:
            fail += 1
    audit(admin_uid, "restart_all_bots", f"ok={ok} fail={fail}")
    return ok, fail


def _do_stop_all_bots(admin_uid: int) -> int:
    n = 0
    for bid in list(RUNNING.keys()):
        try:
            r = stop_child(bid, manual=True)
            if r.get("ok"):
                n += 1
        except Exception:
            pass
    audit(admin_uid, "stop_all_bots", f"stopped={n}")
    return n


def _do_clean_orphans() -> Tuple[int, int]:
    """Delete sandbox dirs and bot_data files with no matching bot
    record. Returns (sandboxes_removed, files_removed)."""
    valid_sandbox_keys: set = set()
    valid_bot_ids: set = set(db_load_ro()["bots"].keys())
    for b in db_load_ro()["bots"].values():
        owner = b.get("owner")
        bid = b.get("_id")
        if owner and bid:
            valid_sandbox_keys.add(f"{owner}_{bid}")
    removed_dirs = 0
    sandbox_root = BASE_DIR / "sandbox"
    if sandbox_root.exists():
        for entry in sandbox_root.iterdir():
            if entry.is_dir() and entry.name not in valid_sandbox_keys:
                try:
                    shutil.rmtree(entry, ignore_errors=True)
                    removed_dirs += 1
                except Exception:
                    pass
    removed_files = 0
    bot_data_dir = BASE_DIR / "storage" / "bot_data"
    if bot_data_dir.exists():
        for f in bot_data_dir.iterdir():
            if f.is_file() and f.suffix == ".json" and f.stem not in valid_bot_ids:
                try:
                    f.unlink()
                    removed_files += 1
                except Exception:
                    pass
    return removed_dirs, removed_files


def _do_export_data(admin_uid: int) -> Path:
    """Bundle DB + settings + audit + bot_data into a single zip and
    return its path."""
    out = BASE_DIR / "exports"
    out.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    target = out / f"kryon_export_{stamp}.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for name in ("user_data.json", "settings.json", "audit.log",
                     "github_config.json"):
            p = BASE_DIR / "storage" / name
            if p.exists():
                zf.write(p, arcname=name)
        bot_data = BASE_DIR / "storage" / "bot_data"
        if bot_data.exists():
            for f in bot_data.iterdir():
                if f.is_file():
                    zf.write(f, arcname=f"bot_data/{f.name}")
    audit(admin_uid, "export_data", f"file={target.name}")
    return target


# ═════════════════════════════════════════════════════════════════
# 21. TICKETS
# ═════════════════════════════════════════════════════════════════











# ═════════════════════════════════════════════════════════════════
# 22. MESSAGE/DOC HANDLERS  (state-driven flows)
# ═════════════════════════════════════════════════════════════════

# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# Legacy duplicate registration disabled.



# ═════════════════════════════════════════════════════════════════
# 22.5  APPROVAL SYSTEM (admin-gated bot uploads)
# ═════════════════════════════════════════════════════════════════
#
# When admin toggles "Approval Mode: ON", every uploaded bot is held
# until an admin Approves or Rejects it. While pending, the bot is
# NEVER auto-started, even if its files decrypt cleanly.
#
# storage layout:
#   settings.approval_required          : bool (default True)
#   settings.pending_uploads            : { bot_id -> { file_id, msg_id,
#                                                       chat_id, user_id, name,
#                                                       file_count, size,
#                                                       file_name, ts } }
# bot doc:
#   doc["approval_status"]   : "pending" | "approved" | "rejected" | None
#   doc["approval_reason"]   : str (filled when rejected)
# ═════════════════════════════════════════════════════════════════

def approval_required() -> bool:
    return bool(get_setting("approval_required", True))


def set_approval_required(on: bool) -> None:
    set_setting("approval_required", bool(on))


def _pending_load() -> Dict[str, Any]:
    return dict(get_setting("pending_uploads", {}) or {})


def _pending_save(d: Dict[str, Any]) -> None:
    set_setting("pending_uploads", d)


def pending_add(bot_id: str, info: Dict[str, Any]) -> None:
    p = _pending_load()
    p[bot_id] = info
    _pending_save(p)


def pending_remove(bot_id: str) -> Optional[Dict[str, Any]]:
    p = _pending_load()
    info = p.pop(bot_id, None)
    _pending_save(p)
    return info


def pending_list() -> List[Tuple[str, Dict[str, Any]]]:
    return list(_pending_load().items())


def is_bot_blocked_by_approval(b: Dict[str, Any]) -> bool:
    """Returns True if the bot is held in the approval queue."""
    return (b or {}).get("approval_status") == "pending"


def _send_approval_request_to_admins(b: Dict[str, Any], info: Dict[str, Any],
                                     forwarded_msg: Optional[types.Message] = None) -> None:
    """Notify admins about a pending upload using metadata only.

    IMPORTANT: the original Telegram upload message/file is deliberately
    never forwarded or copied to any admin/channel. `forwarded_msg` is kept
    only for backwards-compatible callers and is intentionally ignored.
    """
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  {sc('Approve')}",
                                   callback_data=f"appr_ok_{b['_id']}"),
        Btn(f"{G['no']}  {sc('Reject')}",
                                   callback_data=f"appr_no_{b['_id']}"),
    )
    txt = (
        f"<b>{G['warn']} {sc('New bot upload — awaiting approval')}</b>\n"
        f"{G['div']}\n"
        f"{bullet('User',     '{} (@{})'.format(info.get('user_name') or '', info.get('user_username') or '-'))}\n"
        f"{bullet('User ID',  info.get('user_id'))}\n"
        f"{bullet('Bot Name', b.get('name'))}\n"
        f"{bullet('Bot ID',   b['_id'])}\n"
        f"{bullet('File',     info.get('file_name'))}\n"
        f"{bullet('Files',    info.get('file_count'))}\n"
        f"{bullet('Size',     fmt_bytes(info.get('size', 0)))}\n"
        f"{G['div']}"
    )
    targets: List[int] = []
    if OWNER_ID:
        targets.append(OWNER_ID)
    for uid_str in (db_load().get("admins") or {}).keys():
        try:
            uid_i = int(uid_str)
            if uid_i not in targets:
                targets.append(uid_i)
        except Exception:
            pass
    for tgt in targets:
        try:
            bot.send_message(tgt, txt, parse_mode="HTML", reply_markup=kb)
        except Exception:
            pass



def approve_bot(bot_id: str, admin_uid: int) -> Dict[str, Any]:
    b = find_bot(bot_id)
    if not b:
        return {"ok": False, "error": "Bot not found."}
    pending_remove(bot_id)
    b["approval_status"] = "approved"
    b["approval_reason"] = ""
    b["status"] = "stopped"
    save_bot(b)
    audit(admin_uid, "approve_bot", f"bot={bot_id}")
    # Notify uploader
    try:
        owner = b.get("owner")
        if owner:
            bot.send_message(
                owner,
                f"<b>{G['ok']} {sc('Your bot was approved')}</b>\n"
                f"{bullet('Bot', b.get('name'))}\n"
                f"{sc('Starting it now')}…",
                parse_mode="HTML",
            )
    except Exception:
        pass
    # Auto-start in background
    def _bg() -> None:
        try:
            res = start_child(b)
            if not res.get("ok") and b.get("owner"):
                try:
                    bot.send_message(
                        b["owner"],
                        f"<b>{G['no']} {sc('Auto-start failed after approval')}</b>\n"
                        f"{bullet('Error', esc(res.get('error', '')))}",
                        parse_mode="HTML",
                    )
                except Exception:
                    pass
        except Exception as e:
            print(f"[approve_bot bg] {e}")
    threading.Thread(target=_bg, daemon=True).start()
    return {"ok": True}


def reject_bot(bot_id: str, admin_uid: int, reason: str = "") -> Dict[str, Any]:
    b = find_bot(bot_id)
    if not b:
        return {"ok": False, "error": "Bot not found."}
    pending_remove(bot_id)
    b["approval_status"] = "rejected"
    b["approval_reason"] = reason or "rejected by admin"
    b["status"] = "rejected"
    save_bot(b)
    # Wipe the encrypted blobs + bot dir — rejected uploads should not
    # linger on disk.
    try:
        for f in b.get("enc_files") or []:
            try:
                Path(f.get("enc_path", "")).unlink(missing_ok=True)
            except Exception:
                pass
        rmrf(b.get("dir", ""))
    except Exception:
        pass
    # Remove the bot entry so the user's slot frees up
    try:
        db = db_load()
        db["bots"].pop(bot_id, None)
        db_save(db)
    except Exception:
        pass
    audit(admin_uid, "reject_bot", f"bot={bot_id} reason={reason}")
    try:
        owner = b.get("owner")
        if owner:
            bot.send_message(
                owner,
                f"<b>{G['no']} {sc('Your bot was rejected')}</b>\n"
                f"{bullet('Bot', b.get('name'))}\n"
                f"{bullet('Reason', reason or 'No reason given')}",
                parse_mode="HTML",
            )
    except Exception:
        pass
    return {"ok": True}


# ═════════════════════════════════════════════════════════════════
# 22.6  PHOTO CUSTOMIZATION (admin-uploaded menu banners)
# ═════════════════════════════════════════════════════════════════
#
# Admin clicks "Menu Photos" → picks a key (main / admin / plans / …)
# → next photo they send replaces that menu's banner. The PNG is saved
# to storage/photos/<key>.png (overwriting the auto-generated banner)
# and the cached file_id for that key is invalidated so the new image
# is uploaded on the next show_menu.

PHOTO_KEYS_FRIENDLY: Dict[str, str] = {
    "main":      "Main Menu",
    "admin":     "Admin Panel",
    "plans":     "Plans",
    "buy":       "Buy Plan",
    "wallet":    "Wallet",
    "bots":      "My Bots",
    "bot":       "Bot View",
    "upload":    "Upload Bot",
    "stats":     "Stats",
    "support":   "Support",
    "about":     "About",
    "broadcast": "Broadcast",
    "ticket":    "Tickets",
    "coupon":    "Coupons",
    "security":  "Security",
}


def replace_menu_photo(key: str, file_bytes: bytes) -> bool:
    """Persist an admin-uploaded photo as the banner for `key`.

    Custom photos are saved with a 'custom_' prefix so _build_local_photos()
    always picks them over the auto-generated fallback — even after a restart
    or a GitHub restore that overwrites the plain <key>.png.

    The bytes are ALSO mirrored to GitHub at storage/photos/custom_<key>.png
    immediately, so a fresh deploy or restart that wipes local storage can
    restore the admin-set banner via gh_restore_custom_photos()."""
    if key not in _PHOTO_SPECS:
        return False
    out_dir = DIRS["photos"]
    out_dir.mkdir(parents=True, exist_ok=True)
    # Save with custom_ prefix — this is the persistent marker
    custom_out = out_dir / f"custom_{key}.png"
    # Also overwrite the plain key.png so existing code paths work
    plain_out  = out_dir / f"{key}.png"
    try:
        custom_out.write_bytes(file_bytes)
        plain_out.write_bytes(file_bytes)
        PHOTOS[key] = str(custom_out)
        # Invalidate the cached file_id so the next send re-uploads.
        _PHOTO_FILE_IDS.pop(key, None)
        _PHOTO_FILE_IDS.pop(str(plain_out), None)
        _PHOTO_FILE_IDS.pop(str(custom_out), None)
        # ── Mirror to GitHub right away so it survives restarts ──────
        try:
            if gh_enabled():
                threading.Thread(
                    target=lambda: _gh_put_file(
                        f"storage/photos/custom_{key}.png",
                        file_bytes,
                        f"chore(photos): admin updated banner '{key}'",
                    ),
                    daemon=True,
                ).start()
        except Exception as _e:
            print(f"[replace_menu_photo] gh mirror skipped: {_e}")
        return True
    except Exception as e:
        print(f"[replace_menu_photo] {key}: {e}")
        return False


def gh_restore_custom_photos() -> Dict[str, Any]:
    """Restore admin-uploaded banner photos from GitHub. Runs on every boot
    (even when the local DB is non-empty) so a wiped storage/photos/ folder
    can be repopulated. Existing local custom_<key>.png files are kept;
    only missing or empty ones are pulled. Returns a small summary dict."""
    if not gh_enabled():
        return {"ok": False, "skip": True, "reason": "gh disabled"}
    out_dir = DIRS["photos"]
    out_dir.mkdir(parents=True, exist_ok=True)
    restored = 0
    failed: List[str] = []
    try:
        listing = _gh(
            "GET", _gh_repo_url("contents/storage/photos"),
            params={"ref": GH["branch"]},
        )
        if listing.status_code == 404:
            return {"ok": True, "restored": 0, "note": "no remote photos dir"}
        if listing.status_code != 200:
            return {"ok": False, "error": f"list http {listing.status_code}"}
        items = listing.json() or []
    except Exception as e:
        return {"ok": False, "error": str(e)}
    for it in items:
        try:
            name = (it or {}).get("name") or ""
            if not (name.startswith("custom_") and name.endswith(".png")):
                continue
            local = out_dir / name
            if local.exists() and local.stat().st_size > 1024:
                continue  # local copy already present
            r = _gh(
                "GET", _gh_repo_url(f"contents/storage/photos/{name}"),
                params={"ref": GH["branch"]},
            )
            if r.status_code != 200:
                failed.append(name); continue
            payload = r.json() or {}
            blob = base64.b64decode(payload.get("content") or "")
            if len(blob) < 1024:
                failed.append(name); continue
            local.write_bytes(blob)
            # Mirror onto plain <key>.png so legacy paths also resolve.
            key = name[len("custom_"):-len(".png")]
            plain = out_dir / f"{key}.png"
            try:
                plain.write_bytes(blob)
            except Exception:
                pass
            if key in _PHOTO_SPECS:
                PHOTOS[key] = str(local)
                _PHOTO_FILE_IDS.pop(key, None)
                _PHOTO_FILE_IDS.pop(str(local), None)
                _PHOTO_FILE_IDS.pop(str(plain), None)
            restored += 1
        except Exception as e:
            failed.append(f"{(it or {}).get('name','?')}:{e}")
    return {"ok": True, "restored": restored, "failed": failed}


# ─── security scan helper ─────────────────────────────────────────
def _run_security_scan(files_added: List[Tuple[str, bytes]],
                       uploader_uid: Optional[int] = None) -> Dict[str, Any]:
    """Write uploaded files to a temp dir, run combined AI+pattern scan,
    return the worst-case result dict. Falls back to APPROVE if the
    scanner module is not available. Logs every scan to DB scan_log."""
    if not _SCANNER_OK or _scan_file is None:
        return {"recommendation": "APPROVE", "verdict": "SAFE",
                "risk_score": 0, "summary": "Scanner not available.", "all_threats": []}

    # Honour per-user whitelist — whitelisted users skip scanning
    wl = get_setting("scan_whitelist", []) or []
    if uploader_uid and str(uploader_uid) in wl:
        return {"recommendation": "APPROVE", "verdict": "SAFE",
                "risk_score": 0, "summary": "User is whitelisted — scan skipped.",
                "all_threats": []}

    tmp_dir = Path(tempfile.mkdtemp())
    worst: Optional[Dict[str, Any]] = None
    try:
        for rel, plain in files_added[:10]:  # scan up to 10 files
            safe_rel = Path(rel).name or "upload.bin"
            tmp_file = tmp_dir / safe_rel
            try:
                tmp_file.write_bytes(plain)
                # Use combined AI + pattern scan
                result = _combined_scan(str(tmp_file))
                if worst is None or result.get("risk_score", 0) > worst.get("risk_score", 0):
                    worst = result
            except Exception as e:
                print(f"[security] scan error for {safe_rel}: {e}")
                continue
    finally:
        shutil.rmtree(str(tmp_dir), ignore_errors=True)

    if worst is None:
        return {"recommendation": "APPROVE", "verdict": "SAFE",
                "risk_score": 0, "summary": "No scannable files.", "all_threats": []}

    # ── Log scan result to DB ─────────────────────────────────────
    try:
        log_entry = {
            "ts":         ts_iso(),
            "uid":        str(uploader_uid or "?"),
            "filename":   worst.get("filename", files_added[0][0] if files_added else "?"),
            "verdict":    worst.get("verdict", "UNKNOWN"),
            "risk_score": worst.get("risk_score", 0),
            "summary":    (worst.get("summary", "") or "")[:200],
        }
        d = db_load()
        d["scan_log"].append(log_entry)
        d["scan_log"] = d["scan_log"][-500:]   # keep last 500 entries
        db_save(d)
    except Exception:
        pass

    return worst


# ─── upload handler ───────────────────────────────────────────────
def _handle_bot_upload(m: types.Message) -> None:
    uid = m.from_user.id
    u = db_load()["users"][str(uid)]
    if len(list_user_bots(uid)) >= user_max_bots(u):
        bot.reply_to(m, f"{G['no']} {sc('You hit your bot slot limit')}. {sc('Upgrade or delete one')}.")
        return
    doc = m.document
    if not doc:
        return
    if doc.file_size and doc.file_size > MAX_UPLOAD_BYTES:
        bot.reply_to(m, f"{G['no']} {sc('File too big')} (>{MAX_UPLOAD_BYTES // (1024*1024)} Mʙ).")
        return
    fname = doc.file_name or "upload.bin"
    if not re.match(r"^[A-Za-z0-9._\-]+$", fname):
        bot.reply_to(m, f"{G['warn']} {sc('Suspicious filename, please rename')}.")
        return
    try:
        f = bot.get_file(doc.file_id)
        raw = bot.download_file(f.file_path)
    except Exception as e:
        bot.reply_to(m, f"{G['no']} {sc('download error')}: <code>{esc(e)}</code>", parse_mode="HTML")
        return

    bot_id = secrets.token_hex(8)
    bot_dir = DIRS["sandbox"] / f"{uid}_{bot_id}"
    bot_dir.mkdir(parents=True, exist_ok=True)
    name = safe_name(Path(fname).stem)
    doc_db = {
        "_id": bot_id, "owner": uid, "name": name,
        "dir": str(bot_dir), "created": ts_iso(),
        "enc_files": [], "env": {}, "status": "stopped", "cron": {},
    }

    # Determine content: zip vs single file
    files_added: List[Tuple[str, bytes]] = []
    if fname.lower().endswith(".zip"):
        try:
            with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                for member in zf.infolist():
                    if member.is_dir():
                        continue
                    rel = member.filename.replace("\\", "/")
                    if rel.startswith("/") or ".." in rel.split("/"):
                        continue
                    try:
                        # path-traversal check
                        safe_path_join(bot_dir, rel)
                    except ValueError:
                        continue
                    files_added.append((rel, zf.read(member)))
        except zipfile.BadZipFile:
            bot.reply_to(m, f"{G['no']} {sc('not a valid zip')}")
            rmrf(bot_dir); return
    else:
        files_added.append((fname, raw))

    # ══ SECURITY SCAN ════════════════════════════════════════════
    # Runs BEFORE any file is saved, encrypted, or approved.
    _scan_msg = bot.reply_to(
        m,
        f"{G['shield']} {sc('Security scan in progress...')}",
        parse_mode="HTML",
    )
    scan      = _run_security_scan(files_added, uploader_uid=m.from_user.id)
    recommend = scan.get("recommendation", "APPROVE")
    risk      = scan.get("risk_score", 0)
    verdict   = scan.get("verdict", "SAFE")
    summary   = scan.get("summary", "")
    threats   = scan.get("all_threats") or []

    # Delete the "scanning..." notice
    try:
        bot.delete_message(m.chat.id, _scan_msg.message_id)
    except Exception:
        pass

    if recommend == "REJECT":
        # Hard block — wipe everything, alert user + admin
        rmrf(bot_dir)
        threat_lines = "\n".join(f"• {esc(t)}" for t in threats[:5])
        bot.reply_to(
            m,
            f"<b>🚫 {sc('File Blocked — Security Threat Detected')}</b>\n"
            f"{G['div']}\n"
            f"{bullet('File',       fname)}\n"
            f"{bullet('Risk Score', f'{risk}/100')}\n"
            f"{bullet('Verdict',    verdict)}\n"
            f"{G['div']}\n"
            f"<b>{sc('Threats found')}:</b>\n{threat_lines or sc('See admin alert')}",
            parse_mode="HTML",
        )
        notify_owner(
            f"<b>🚨 {sc('DANGEROUS FILE BLOCKED BY SCANNER')}</b>\n"
            f"{G['div']}\n"
            f"{bullet('User',    '{} (@{})'.format(m.from_user.first_name or '', m.from_user.username or '-'))}\n"
            f"{bullet('User ID', uid)}\n"
            f"{bullet('File',    fname)}\n"
            f"{bullet('Risk',    f'{risk}/100')}\n"
            f"{bullet('Verdict', verdict)}\n"
            f"<b>{sc('Top threats')}:</b>\n" +
            "\n".join(f"• {esc(t)}" for t in threats[:3])
        )
        audit(uid, "security_reject", f"file={fname} risk={risk} verdict={verdict}")
        return

    if recommend == "MANUAL_REVIEW":
        # Tag the bot record with scan info so admins see it in the approval panel
        doc_db["security_scan"] = {
            "verdict": verdict, "risk_score": risk, "summary": summary,
        }
    # ══ END SECURITY SCAN ════════════════════════════════════════

    # encrypt and store each
    for rel, plain in files_added:
        meta = store_uploaded_file(m.from_user, rel, plain, bot_id=str(doc_db.get("_id") or ""))
        doc_db["enc_files"].append({
            "key_id": meta["key_id"],
            "enc_path": meta["path"],
            "filename": Path(rel).name,
            "rel_path": rel,
            "mongo_file_id": meta.get("mongo_file_id", ""),
        })

    # NOTE: We deliberately do NOT push to GitHub right after upload.
    # Most upload failures are caught only when the bot starts running,
    # so we wait until the bot has been running for >= 10 minutes
    # (see `gh_uptime_backup_loop`) before backing up. This keeps the
    # backup repo clean of broken/test uploads.
    doc_db["gh_synced_at"] = 0  # reset; loop will re-sync once stable
    total_size = sum(len(p) for _, p in files_added)

    # ── Approval gate ───────────────────────────────────────────
    needs_approval = approval_required() and not is_admin(uid) and OWNER_ID > 0
    if needs_approval:
        doc_db["approval_status"] = "pending"
        doc_db["status"] = "pending_approval"
    save_bot(doc_db)
    db = db_load()
    db["users"][str(uid)]["stats"]["bots_uploaded"] = int(
        db["users"][str(uid)]["stats"].get("bots_uploaded", 0)) + 1
    db_save(db)
    USER_STATES.pop(uid, None)

    if needs_approval:
        info = {
            "user_id":       uid,
            "user_name":     m.from_user.first_name or "",
            "user_username": m.from_user.username or "",
            "chat_id":       m.chat.id,
            "msg_id":        m.message_id,
            "file_name":     fname,
            "file_count":    len(files_added),
            "size":          total_size,
            "ts":            ts_iso(),
        }
        pending_add(bot_id, info)
        try:
            _send_approval_request_to_admins(doc_db, info, m)
        except Exception as e:
            print(f"[approval notify] {e}")
        bot.reply_to(
            m,
            f"<b>{G['warn']} {sc('Pending admin approval')}</b>\n"
            f"{G['div']}\n"
            f"{bullet('Bot Name', name)}\n"
            f"{bullet('Files',    len(files_added))}\n"
            f"{bullet('Size',     fmt_bytes(total_size))}\n"
            f"{G['div']}\n"
            f"{sc('Your bot will start automatically once an admin approves it')}.",
            parse_mode="HTML",
        )
        return

    # File forward disabled — owner sees only the notification summary below.

    notify_owner(
        f"<b>{G['upload']} ɴᴇᴡ ʙᴏᴛ ᴜᴘʟᴏᴀᴅ</b>\n"
        f"{G['div']}\n"
        f"{bullet('File',     fname)}\n"
        f"{bullet('User',     '{} (@{})'.format(m.from_user.first_name or '', m.from_user.username or '-'))}\n"
        f"{bullet('User ID',  uid)}\n"
        f"{bullet('Bot Name', name)}\n"
        f"{bullet('Files',    len(files_added))}\n"
        f"{bullet('Size',     fmt_bytes(total_size))}\n"
        f"{G['div']}"
    )

    kind, _ = detect_entry(bot_dir)  # speculative — might be encrypted-only

    def _make_bar(pct: int, status: str, kind_str: str = "") -> str:
        filled = int(pct / 5)
        bar    = "▓" * filled + "░" * (20 - filled)
        return (
            f"<b>{G['ok']} {sc('Bot stored encrypted')}</b>\n"
            f"{bullet('Name',  name)}\n"
            f"{bullet('Files', len(files_added))}\n"
            f"{bullet('Kind',  kind_str or kind or 'auto-detect on start')}\n"
            f"<code>{bar} {pct}%</code>\n"
            f"{status}"
        )

    # Ek message bhejo — phir edit karte rahenge (spam nahi hoga)
    sent   = bot.reply_to(m, _make_bar(0, sc("Starting...")), parse_mode="HTML")
    msg_id = sent.message_id
    cid    = m.chat.id

    def _edit(pct: int, status: str, kind_str: str = "") -> None:
        try:
            bot.edit_message_text(
                _make_bar(pct, status, kind_str),
                chat_id=cid, message_id=msg_id,
                parse_mode="HTML",
            )
        except Exception:
            pass

    # ── auto-start the freshly uploaded bot ──────────────────────
    def _bg_start(doc: Dict[str, Any]) -> None:
        try:
            _edit(10, sc("Decrypting files..."))
            time.sleep(0.8)
            _edit(30, sc("Installing dependencies..."))
            time.sleep(0.8)
            _edit(50, sc("Setting up environment..."))
            time.sleep(0.8)
            _edit(70, sc("Launching bot..."))
            res = start_child(doc)
            if res.get("ok"):
                _edit(100,
                      f"<b>{G['play']} {sc('Bot is running!')}</b>",
                      res.get("kind", ""))
                time.sleep(1.5)
                # loading msg delete karo
                try:
                    bot.delete_message(cid, msg_id)
                except Exception:
                    pass
                # My Bots menu bhejo
                bots = list_user_bots(uid)
                u = db_load()["users"][str(uid)]
                cap = (
                    f"<b>{G['diamond']} {sc('Your Bots')}</b>\n"
                    f"{G['div_eq']}\n"
                    f"{bullet('Slots', f'{len(bots)} / {user_max_bots(u)}')}\n"
                )
                kb = types.InlineKeyboardMarkup()
                for b in sorted(bots, key=lambda x: x.get("name", "")):
                    running = b["_id"] in RUNNING and RUNNING[b["_id"]]["proc"].poll() is None
                    mark = G["play"] if running else G["stop"]
                    kb.add(Btn(
                        f"{mark}  {sc(b['name'])[:30]}",
                        callback_data=f"bot_view_{b['_id']}"))
                kb.add(
                    Btn(f"{G['plus']}  {sc('Upload')}",   callback_data="menu_upload", style="success"),
                    Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main", style="primary"),
                )
                bot.send_message(cid, cap + FOOTER, parse_mode="HTML", reply_markup=kb)
            else:
                _edit(0,
                      f"<b>{G['no']} {sc('Auto-start failed')}</b>\n"
                      f"{bullet('Error', esc(res.get('error', '')))}\n"
                      f"{sc('Open My Bots → Live Logs to see why')}.")
        except Exception as e:
            try:
                _edit(0, f"{G['no']} {sc('Auto-start error')}: <code>{esc(str(e))}</code>")
            except Exception:
                pass

    threading.Thread(target=_bg_start, args=(doc_db,), daemon=True).start()


# ─── env vars flow ────────────────────────────────────────────────


# ─── pip install flow ─────────────────────────────────────────────


# ─── cron flow ────────────────────────────────────────────────────


# ─── admin: find user ─────────────────────────────────────────────


# ─── admin: ban / unban ──────────────────────────────────────────


# ─── admin: give plan ─────────────────────────────────────────────


# ─── admin: broadcast ─────────────────────────────────────────────


def _send_broadcast(text: str, target_plan: Optional[str]) -> Tuple[int, int]:
    sent = skipped = 0
    d = db_load()
    for u in d["users"].values():
        if u.get("banned"):
            skipped += 1; continue
        if target_plan and u.get("plan") != target_plan:
            skipped += 1; continue
        try:
            bot.send_message(int(u["_id"]), text, parse_mode="HTML",
                             disable_web_page_preview=True)
            sent += 1
            time.sleep(0.04)  # gentle throttle
        except Exception:
            skipped += 1
    return sent, skipped


# ─── coupons ──────────────────────────────────────────────────────




# ─── admin: admins ───────────────────────────────────────────────


# ─── tickets ──────────────────────────────────────────────────────






# ─── payment proof ───────────────────────────────────────────────










# ─── gift plan flow ───────────────────────────────────────────────




# ═════════════════════════════════════════════════════════════════
# 23. SCHEDULER  (background loops)
# ═════════════════════════════════════════════════════════════════



# ═════════════════════════════════════════════════════════════════
# 24. BOOTSTRAP / MAIN
# ═════════════════════════════════════════════════════════════════



def _acquire_singleton_lock() -> Optional[Any]:
    """Best-effort single-instance guard. Prevents two local copies of the
    panel from running on the same machine (which would otherwise both poll
    the same token and deliver every callback twice). Returns the file
    handle to keep alive for the lifetime of the process, or None on
    platforms where fcntl isn't available (e.g. Windows)."""
    try:
        import fcntl
    except ImportError:
        return None
    lock_path = DIRS["data"] / "panel.lock"
    try:
        fh = open(lock_path, "w")
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        fh.write(str(os.getpid()))
        fh.flush()
        return fh
    except OSError:
        # A host may briefly start a replacement process before the previous
        # process has been reaped. Exiting here makes the platform restart the
        # replacement again, creating the exact restart loop seen in logs.
        # Keep this process alive instead; the already-running instance owns
        # the health port and Telegram poller. If that instance dies, the lock
        # is released and this process can acquire it on the next check.
        print(f"[persistence] another local panel instance owns {lock_path}; waiting...", flush=True)
        while True:
            time.sleep(10)
            try:
                fh = open(lock_path, "w")
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                fh.write(str(os.getpid()))
                fh.flush()
                print("[persistence] local panel lease acquired after waiting.", flush=True)
                return fh
            except OSError:
                try:
                    fh.close()
                except Exception:
                    pass




# NOTE: entrypoint stays at the bottom of this file so runtime hooks
# defined further down get registered BEFORE main() starts polling.

# ═══════════════════════════════════════════════════════════════════════════════
# ██████████████  ULTRA-ADVANCED HELP & ANALYTICS SYSTEM  ██████████████████████
# ═══════════════════════════════════════════════════════════════════════════════

_HELP_PAGES = {
    "main": {
        "title": "📚 Help Centre",
        "text": (
            "Welcome to <b>𓂀KRYON_HOST𓂀</b>\n\n"
            "<b>Quick Start</b>\n"
            "1. Register with /start\n"
            "2. Upload your .py or .zip file\n"
            "3. Set BOT_TOKEN env var\n"
            "4. Press Start\n\n"
            "<b>Commands</b>\n"
            "/start /menu /help /id /cancel /status /profile /plans /pay /refer /coupon"
        ),
        "subs": ["upload", "manage", "plans", "github", "referral"],
    },
    "upload": {
        "title": "📤 Uploading Bots",
        "text": (
            "<b>Method 1:</b> Send .py directly\n"
            "<b>Method 2:</b> Send .zip (main file = main.py or bot.py)\n"
            "<b>Method 3:</b> GitHub File Browser\n\n"
            "<b>Limits:</b> max upload size per plan, .py/.js/.zip allowed"
        ),
    },
    "manage": {
        "title": "🤖 Managing Bots",
        "text": (
            "My Bots → select → Start/Stop/Restart\n"
            "View logs in real time (last 500 lines ring buffer)\n"
            "Download source as ZIP any time\n"
            "Crash auto-restart (configurable max retries)"
        ),
    },
    "plans": {
        "title": "💳 Plans & Billing",
        "text": (
            "Free: 1 bot, 50 MB\n"
            "Basic: 3 bots, 100 MB\n"
            "Pro: 10 bots, 500 MB\n"
            "Ultra: unlimited bots, 2 GB\n\n"
            "Pay via UPI/Crypto/PayPal → send proof → admin approves"
        ),
    },
    "github": {
        "title": "🐙 GitHub Integration",
        "text": (
            "Admin → GitHub → enter PAT + repo\n"
            "Auto-backup on start/stop/every N minutes\n"
            "GitHub Browser: browse any public repo, deploy files as bots"
        ),
    },
    "referral": {
        "title": "👥 Referral System",
        "text": (
            "Share your link, earn credits per sign-up\n"
            "Menu → Refer & Earn → copy link\n"
            "Admin configures reward amount and min plan requirement"
        ),
    },
}


def render_help_page(chat_id, page, call=None):
    data = _HELP_PAGES.get(page, _HELP_PAGES["main"])
    cap  = (
        f"<b>{data['title']}</b>\n"
        f"{G['div_eq']}\n"
        f"{data['text']}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for sub in data.get("subs", []):
        sd = _HELP_PAGES.get(sub, {})
        if sd:
            kb.add(Btn(sd["title"], callback_data=f"help_{sub}", style="primary"))
    kb.add(Btn(f"{G['back']}  Mᴀɪɴ Hᴇʟᴘ", callback_data="help_main", style="primary"))
    photo = PHOTOS.get("main", PHOTOS.get("admin"))
    if call:
        show_menu(call.message.chat.id, photo, cap, kb, call=call)
    else:
        bot.send_photo(chat_id, photo, caption=cap, reply_markup=kb, parse_mode="HTML")


# ─── Analytics Helpers ──────────────────────────────────────────────────────

def _analytics_daily_signups(days=30):
    d = db_load()
    from datetime import timedelta
    cutoff = (now_utc() - timedelta(days=days))
    counts = {}
    for u in d["users"].values():
        joined = u.get("joined", "")
        if joined:
            try:
                from datetime import datetime, timezone
                dt = datetime.fromisoformat(joined)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                if dt >= cutoff:
                    day = dt.strftime("%Y-%m-%d")
                    counts[day] = counts.get(day, 0) + 1
            except Exception:
                pass
    return dict(sorted(counts.items()))


def _analytics_plan_distribution(d=None):
    if d is None:
        d = db_load()
    dist = {}
    for u in d["users"].values():
        plan = u.get("plan", "free") or "free"
        dist[plan] = dist.get(plan, 0) + 1
    return dist


def _analytics_bot_status_dist(d=None):
    if d is None:
        d = db_load()
    dist = {}
    for b in d["bots"].values():
        s = b.get("status", "stopped")
        dist[s] = dist.get(s, 0) + 1
    return dist


def _analytics_top_referrers(n=10):
    d = db_load()
    rows = [(uid, u.get("name", uid), len(u.get("referrals", [])))
            for uid, u in d["users"].items() if u.get("referrals")]
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:n]


def _analytics_avg_bots_per_user():
    d = db_load()
    if not d["users"]:
        return 0.0
    counts = {}
    for b in d["bots"].values():
        uid = str(b.get("owner", ""))
        counts[uid] = counts.get(uid, 0) + 1
    return round(sum(counts.values()) / len(d["users"]), 2)


def _rev_total():
    d = db_load()
    return sum(float(tx.get("amount", 0))
               for u in d["users"].values()
               for tx in u.get("transactions", [])
               if tx.get("type") in ("payment", "upgrade", "renewal"))


def _rev_this_month():
    d = db_load()
    month = now_utc().strftime("%Y-%m")
    return sum(float(tx.get("amount", 0))
               for u in d["users"].values()
               for tx in u.get("transactions", [])
               if tx.get("ts", "").startswith(month)
               and tx.get("type") in ("payment", "upgrade", "renewal"))


def _rev_by_plan():
    d = db_load()
    by_plan = {}
    for u in d["users"].values():
        for tx in u.get("transactions", []):
            if tx.get("type") in ("payment", "upgrade", "renewal"):
                pl = tx.get("plan", "unknown")
                by_plan[pl] = by_plan.get(pl, 0.0) + float(tx.get("amount", 0))
    return by_plan


def _rev_goal_progress():
    goal       = float(get_setting("revenue_goal", 0) or 0)
    this_month = _rev_this_month()
    pct        = round(this_month / goal * 100, 1) if goal > 0 else 0
    return {
        "goal":      goal,
        "achieved":  this_month,
        "remaining": max(0.0, goal - this_month),
        "pct":       pct,
    }




# ─── Notification Queue ─────────────────────────────────────────────────────

_NOTIFICATION_QUEUE = []
_NOTIF_LOCK = threading.Lock()


def _notif_enqueue(uid, msg, parse_mode="HTML"):
    with _NOTIF_LOCK:
        _NOTIFICATION_QUEUE.append({"uid": uid, "msg": msg, "pm": parse_mode})


def _notif_flush_queue():
    with _NOTIF_LOCK:
        batch = list(_NOTIFICATION_QUEUE)
        _NOTIFICATION_QUEUE.clear()
    for item in batch:
        try:
            bot.send_message(item["uid"], item["msg"], parse_mode=item["pm"])
        except Exception:
            pass


def _notif_runner():
    while True:
        try:
            _notif_flush_queue()
        except Exception:
            pass
        time.sleep(5)


# ─── Rate Limiter ───────────────────────────────────────────────────────────

_RATE_BUCKETS = {}
_RATE_LOCK    = threading.Lock()


def _rate_check(uid, action="msg"):
    cfg = {
        "msg":       (_rl_get("msg_per_min"),        60),
        "callback":  (_rl_get("cb_per_min"),         60),
        "upload":    (_rl_get("upload_per_hour"),   3600),
        "start_bot": (_rl_get("bot_start_per_hour"),3600),
    }
    limit, window = cfg.get(action, (60, 60))
    key = f"{uid}:{action}"
    now = time.time()
    with _RATE_LOCK:
        bucket = _RATE_BUCKETS.get(key, {"count": 0, "window_start": now})
        if now - bucket["window_start"] > window:
            bucket = {"count": 0, "window_start": now}
        bucket["count"] += 1
        _RATE_BUCKETS[key] = bucket
        return bucket["count"] <= limit


def _rate_cleanup_loop():
    while True:
        time.sleep(300)
        now = time.time()
        with _RATE_LOCK:
            stale = [k for k, v in _RATE_BUCKETS.items() if now - v["window_start"] > 7200]
            for k in stale:
                _RATE_BUCKETS.pop(k, None)


# ─── Plan Enforcement ───────────────────────────────────────────────────────

def _plan_enforce_bot_limit(uid):
    d = db_load()
    u = d["users"].get(str(uid), {})
    plan   = u.get("plan", "free") or "free"
    limits = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])
    max_b  = limits.get("bots", 1)
    if max_b == -1:
        return True, ""
    cur = sum(1 for b in d["bots"].values() if str(b.get("owner")) == str(uid))
    if cur >= max_b:
        return False, f"Plan limit: {max_b} bots. You have {cur}. Upgrade to add more."
    return True, ""


def _plan_enforce_upload_size(uid, size_bytes):
    d = db_load()
    u = d["users"].get(str(uid), {})
    plan   = u.get("plan", "free") or "free"
    limits = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])
    max_mb = limits.get("max_upload_mb", 50)
    if max_mb == -1:
        return True, ""
    if size_bytes > max_mb * 1024 * 1024:
        return False, f"File {fmt_bytes(size_bytes)} > plan limit {max_mb} MB. Upgrade!"
    return True, ""


def _plan_check_expiry(uid):
    d = db_load()
    u = d["users"].get(str(uid), {})
    plan    = u.get("plan", "free") or "free"
    expires = u.get("plan_expires")
    if plan == "free" or not expires:
        return True
    if expires < ts_iso():
        u["plan"]         = "free"
        u["plan_expires"] = None
        u.setdefault("transactions", []).append({
            "type": "downgrade", "ts": ts_iso(), "from_plan": plan, "reason": "expired"
        })
        db_save(d)
        _notif_enqueue(uid,
            f"<b>{G['warn']} Plan expired</b>\n"
            f"Your <b>{plan}</b> plan expired. Downgraded to Free.",
            parse_mode="HTML"
        )
        return False
    return True


# ─── Webhook Delivery ───────────────────────────────────────────────────────

def _wh_deliver(event, payload):
    url    = get_setting("webhook_url", "")
    if not url:
        return
    secret = get_setting("webhook_secret", "") or ""
    import json as _json
    body   = _json.dumps({"event": event, "payload": payload, "ts": ts_iso()})
    headers = {"Content-Type": "application/json"}
    if secret:
        import hmac, hashlib
        headers["X-Webhook-Signature"] = hmac.new(
            secret.encode(), body.encode(), hashlib.sha256).hexdigest()
    try:
        import urllib.request as _ur
        req = _ur.Request(url, data=body.encode(), headers=headers, method="POST")
        with _ur.urlopen(req, timeout=10) as r:
            status = r.status
        _wh_log(event, status)
    except Exception as e:
        _wh_log(event, f"error:{e}")


def _wh_log(event, status):
    log = get_setting("webhook_log", []) or []
    log.append({"event": event, "ts": ts_iso(), "status": str(status)})
    if len(log) > 100:
        log = log[-100:]
    set_setting("webhook_log", log)


def _wh_fire(event, payload):
    if not get_setting("webhook_enabled", False):
        return
    threading.Thread(target=_wh_deliver, args=(event, payload), daemon=True).start()


# ─── Subscription Engine ────────────────────────────────────────────────────

def _sub_check_all_expiries():
    d = db_load()
    downgraded = []
    for uid_s, u in d["users"].items():
        plan    = u.get("plan", "free") or "free"
        expires = u.get("plan_expires")
        if plan != "free" and expires and expires < ts_iso():
            old = plan
            u["plan"] = "free"; u["plan_expires"] = None
            u.setdefault("transactions", []).append({
                "type": "downgrade", "ts": ts_iso(), "from_plan": old, "reason": "expired"})
            downgraded.append((int(uid_s), old))
    if downgraded:
        db_save(d)
        for uid, op in downgraded:
            try:
                bot.send_message(uid,
                    f"<b>{G['warn']} Plan Expired</b>\n{op} → Free. Renew to restore.",
                    parse_mode="HTML")
            except Exception:
                pass
    return downgraded


def _sub_renewal_reminders():
    d = db_load()
    from datetime import timedelta
    threshold = (now_utc() + timedelta(days=3)).isoformat()
    sent = 0
    for uid_s, u in d["users"].items():
        plan    = u.get("plan", "free") or "free"
        expires = u.get("plan_expires", "")
        if plan == "free" or not expires:
            continue
        if ts_iso() < expires <= threshold:
            today = now_utc().strftime("%Y-%m-%d")
            if u.get("last_renewal_reminder") == today:
                continue
            try:
                bot.send_message(int(uid_s),
                    f"<b>{G['warn']} Plan Expiring Soon</b>\n"
                    f"{bullet('Plan', plan)}\n{bullet('Expires', expires[:10])}\n"
                    f"Renew now to avoid downtime!", parse_mode="HTML")
                u["last_renewal_reminder"] = today
                sent += 1
            except Exception:
                pass
    if sent:
        db_save(d)
    return sent


def _sub_reminder_loop():
    while True:
        time.sleep(3600)
        try:
            _sub_check_all_expiries()
        except Exception:
            pass
        try:
            _sub_renewal_reminders()
        except Exception:
            pass


# ─── Coupon Engine ──────────────────────────────────────────────────────────

def _coupon_validate(code, uid):
    d = db_load()
    c = d.get("coupons", {}).get(code.upper())
    if not c:
        return False, "Invalid coupon code.", {}
    if c.get("expiry") and c["expiry"] < ts_iso():
        return False, "Coupon expired.", {}
    uses_left = c.get("uses_left")
    if uses_left is not None and uses_left <= 0:
        return False, "No uses remaining.", {}
    if uid in c.get("used_by", []):
        return False, "Already used.", {}
    return True, "", c


def _coupon_redeem(code, uid):
    valid, err, c = _coupon_validate(code, uid)
    if not valid:
        return False, err, 0.0
    d    = db_load()
    coup = d.setdefault("coupons", {}).setdefault(code.upper(), c)
    coup.setdefault("used_by", []).append(uid)
    if coup.get("uses_left") is not None:
        coup["uses_left"] = max(0, coup["uses_left"] - 1)
    db_save(d)
    discount = float(c.get("discount_pct", 0))
    flat     = float(c.get("discount_flat", 0))
    _wh_fire("coupon_redeemed", {"code": code.upper(), "uid": uid,
                                  "discount_pct": discount, "discount_flat": flat})
    return True, f"Coupon applied! Discount: {discount}% / flat {flat}", discount


# ─── File Manager ───────────────────────────────────────────────────────────

def _fm_list_bot_files(bot_id):
    b = find_bot(bot_id)
    if not b:
        return []
    sbox = Path(b.get("sandbox", ""))
    if not sbox.exists():
        return []
    result = []
    try:
        for p in sorted(sbox.rglob("*")):
            if p.is_file():
                result.append({
                    "name": str(p.relative_to(sbox)),
                    "size": p.stat().st_size,
                })
    except Exception:
        pass
    return result


def _fm_read_file(bot_id, rel_path, max_bytes=32768):
    b = find_bot(bot_id)
    if not b:
        return "", False
    sbox   = Path(b.get("sandbox", ""))
    target = (sbox / rel_path).resolve()
    try:
        target.relative_to(sbox.resolve())
    except ValueError:
        return "Access denied.", False
    if not target.exists():
        return "File not found.", False
    data = target.read_bytes()
    trunc = len(data) > max_bytes
    return data[:max_bytes].decode("utf-8", errors="replace"), trunc


def _fm_write_file(bot_id, rel_path, content):
    b = find_bot(bot_id)
    if not b:
        return False
    sbox   = Path(b.get("sandbox", ""))
    target = (sbox / rel_path).resolve()
    try:
        target.relative_to(sbox.resolve())
    except ValueError:
        return False
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        target.write_text(content, encoding="utf-8")
        return True
    except Exception:
        return False


def _fm_zip_sandbox(bot_id):
    import zipfile as _zf
    b = find_bot(bot_id)
    if not b:
        return None
    sbox = Path(b.get("sandbox", ""))
    if not sbox.exists():
        return None
    zip_path = DIRS["tmp"] / f"{bot_id}_export_{int(time.time())}.zip"
    try:
        with _zf.ZipFile(zip_path, "w", _zf.ZIP_DEFLATED) as z:
            for p in sbox.rglob("*"):
                if p.is_file():
                    z.write(p, p.relative_to(sbox))
        return zip_path
    except Exception:
        return None


# ─── Broadcast Engine ───────────────────────────────────────────────────────

_BROADCAST_ACTIVE = {}


def _broadcast_job(job_id, uids, msg, parse_mode="HTML", delay=0.05):
    _BROADCAST_ACTIVE[job_id] = {"total": len(uids), "sent": 0, "failed": 0, "done": False}
    for uid in uids:
        try:
            bot.send_message(uid, msg, parse_mode=parse_mode)
            _BROADCAST_ACTIVE[job_id]["sent"] += 1
        except Exception:
            _BROADCAST_ACTIVE[job_id]["failed"] += 1
        time.sleep(delay)
    _BROADCAST_ACTIVE[job_id]["done"] = True


def _broadcast_start(uids, msg, parse_mode="HTML"):
    import random, string
    job_id = "bc_" + "".join(random.choices(string.ascii_lowercase, k=8))
    threading.Thread(target=_broadcast_job, args=(job_id, uids, msg, parse_mode),
                     daemon=True, name=f"broadcast-{job_id}").start()
    return job_id


# ─── Metrics ────────────────────────────────────────────────────────────────

_METRICS = {
    "messages_received": 0, "callbacks_received": 0, "bot_starts": 0,
    "bot_stops": 0, "bot_crashes": 0, "uploads": 0, "errors": 0,
    "commands": 0, "plan_upgrades": 0, "payments_received": 0,
}
_METRICS_LOCK = threading.Lock()


def _metric(key, n=1):
    with _METRICS_LOCK:
        _METRICS[key] = _METRICS.get(key, 0) + n


def _metrics_snapshot():
    with _METRICS_LOCK:
        return dict(_METRICS)


def _metrics_persist_loop():
    while True:
        time.sleep(300)
        try:
            snap = _metrics_snapshot()
            existing = get_setting("metrics_total", {}) or {}
            for k, v in snap.items():
                existing[k] = existing.get(k, 0) + v
            set_setting("metrics_total", existing)
            with _METRICS_LOCK:
                for k in _METRICS:
                    _METRICS[k] = 0
        except Exception:
            pass


# ─── Security Engine ────────────────────────────────────────────────────────

def _security_scan_code(content):
    patterns = [
        "os.system", "subprocess.call", "eval(compile", "__import__('os').system",
        "open('/etc/passwd')", "/proc/self/environ", "exec(base64",
    ]
    warnings_found = []
    for i, line in enumerate(content.split("\n"), 1):
        for pat in patterns:
            if pat in line:
                warnings_found.append(f"Line {i}: {pat}")
    return warnings_found


def _security_audit_log(uid, action, detail="", risk="low"):
    entry = {"uid": uid, "action": action, "detail": detail, "risk": risk, "ts": ts_iso()}
    log = get_setting("security_audit_log", []) or []
    log.append(entry)
    if len(log) > 500:
        log = log[-500:]
    set_setting("security_audit_log", log)
    if risk in ("high", "critical"):
        try:
            notify_owner(
                f"<b>{G['warn']} Security Alert [{risk.upper()}]</b>\n"
                f"{bullet('User', uid)}\n{bullet('Action', action)}\n"
                f"{bullet('Detail', esc(str(detail)[:200]))}"
            )
        except Exception:
            pass


def _security_detect_token_leak(content):
    import re
    return bool(re.compile(r"\d{8,10}:[A-Za-z0-9_-]{35}", re.MULTILINE).search(content))


# ─── Template Engine ────────────────────────────────────────────────────────

def _tmpl_render(key, ctx):
    templates = get_setting("message_templates", {}) or {}
    template  = templates.get(key) or _MESSAGE_TEMPLATES.get(key, "")
    if not template:
        return ""
    try:
        return template.format_map(ctx)
    except (KeyError, ValueError):
        return template


def _tmpl_list():
    return {**dict(_MESSAGE_TEMPLATES), **(get_setting("message_templates", {}) or {})}


def _tmpl_reset_one(key):
    templates = get_setting("message_templates", {}) or {}
    if key in templates:
        del templates[key]
        set_setting("message_templates", templates)
        return True
    return False


# ─── User Profile Engine ────────────────────────────────────────────────────

def _user_activity_score(uid):
    d = db_load()
    u = d["users"].get(str(uid), {})
    score = 0
    score += sum(1 for b in d["bots"].values() if str(b.get("owner")) == str(uid)) * 10
    score += {"free": 0, "basic": 20, "pro": 50, "ultra": 100}.get(
        u.get("plan", "free") or "free", 0)
    score += len(u.get("referrals", [])) * 15
    joined = u.get("joined", "")
    if joined:
        try:
            from datetime import datetime, timezone
            dt = datetime.fromisoformat(joined)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            score += min((now_utc() - dt).days, 365)
        except Exception:
            pass
    return score


def _user_get_badges(uid):
    d = db_load()
    u = d["users"].get(str(uid), {})
    badges = []
    plan   = u.get("plan", "free") or "free"
    if plan == "ultra":   badges.append("💎 Ultra Member")
    elif plan == "pro":   badges.append("🥇 Pro Member")
    elif plan == "basic": badges.append("🥈 Basic Member")
    bot_count = sum(1 for b in d["bots"].values() if str(b.get("owner")) == str(uid))
    if bot_count >= 10: badges.append("🤖 Bot Master (10+)")
    elif bot_count >= 5: badges.append("🤖 Bot Expert (5+)")
    elif bot_count >= 1: badges.append("🤖 Bot Hoster")
    refs = len(u.get("referrals", []))
    if refs >= 50:  badges.append("👑 Referral King (50+)")
    elif refs >= 10: badges.append("🌟 Top Referrer (10+)")
    elif refs >= 1:  badges.append("👥 Referrer")
    if _user_activity_score(uid) >= 200: badges.append("🔥 Power User")
    return badges


def _user_profile_card(uid):
    d    = db_load()
    u    = d["users"].get(str(uid), {})
    if not u:
        return "User not found."
    plan   = u.get("plan", "free") or "free"
    p_lim  = PLAN_LIMITS.get(plan, PLAN_LIMITS["free"])
    bots   = sum(1 for b in d["bots"].values() if str(b.get("owner")) == str(uid))
    run    = sum(1 for b in d["bots"].values()
                 if str(b.get("owner")) == str(uid) and b.get("status") == "running")
    badges = _user_get_badges(uid)
    score  = _user_activity_score(uid)
    return (
        f"<b>👤 {esc(u.get('name', str(uid)))}</b>\n"
        f"{G['div_eq']}\n"
        + bullet("UID", uid) + "\n"
        + bullet("Plan", p_lim.get("name", plan)) + "\n"
        + bullet("Bots", f"{bots} ({run} running)") + "\n"
        + bullet("Score", score) + "\n"
        + bullet("Badges", len(badges)) + "\n"
        + G["div"] + "\n"
        + "\n".join(f"  • {b}" for b in badges)
    )


# ─── Revenue Engine ─────────────────────────────────────────────────────────

def _rev_projected_monthly():
    day = now_utc().day or 1
    return round(_rev_this_month() / day * 30, 2)


# ─── Leaderboard Engine ─────────────────────────────────────────────────────

def _lb_top_by_bots(n=10):
    d = db_load()
    counts = {}
    for b in d["bots"].values():
        uid = str(b.get("owner", ""))
        counts[uid] = counts.get(uid, 0) + 1
    rows = [(uid, d["users"].get(uid, {}).get("name", uid), cnt)
            for uid, cnt in counts.items()]
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:n]


def _lb_top_by_referrals(n=10):
    d = db_load()
    rows = [(uid, u.get("name", uid), len(u.get("referrals", [])))
            for uid, u in d["users"].items() if u.get("referrals")]
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:n]


def _lb_top_by_revenue(n=10):
    d = db_load()
    rev = {}
    for uid, u in d["users"].items():
        total = sum(float(tx.get("amount", 0))
                    for tx in u.get("transactions", [])
                    if tx.get("type") in ("payment", "upgrade", "renewal"))
        if total > 0:
            rev[uid] = (u.get("name", uid), total)
    rows = [(uid, name, amt) for uid, (name, amt) in rev.items()]
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:n]


def _lb_top_by_score(n=10):
    d = db_load()
    rows = [(uid, u.get("name", uid), _user_activity_score(int(uid)))
            for uid, u in d["users"].items()]
    rows.sort(key=lambda x: x[2], reverse=True)
    return rows[:n]


# ─── Language Engine ────────────────────────────────────────────────────────

_TRANSLATIONS = {
    "en": {"welcome": "Welcome to {brand}!", "plan_expired": "Your plan has expired.",
           "bot_started": "Bot {name} is now running!", "bot_crashed": "Bot {name} crashed.",
           "payment_received": "Payment received! Plan will be updated shortly.",
           "referral_earned": "You earned {amount} credits for referring {user}!"},
    "hi": {"welcome": "{brand} में आपका स्वागत है!", "plan_expired": "आपका प्लान समाप्त हो गया।",
           "bot_started": "बॉट {name} चल रहा है!", "bot_crashed": "बॉट {name} क्रैश हो गया।",
           "payment_received": "भुगतान प्राप्त हुआ!", "referral_earned": "{user} रेफर पर {amount} क्रेडिट मिले!"},
    "ru": {"welcome": "Добро пожаловать в {brand}!", "plan_expired": "Срок плана истёк.",
           "bot_started": "Бот {name} запущен!", "bot_crashed": "Бот {name} упал.",
           "payment_received": "Платёж получен!", "referral_earned": "Заработано {amount} кредитов за {user}!"},
    "ar": {"welcome": "مرحباً في {brand}!", "plan_expired": "انتهت صلاحية خطتك.",
           "bot_started": "البوت {name} يعمل الآن!", "bot_crashed": "تعطل البوت {name}.",
           "payment_received": "تم استلام الدفعة!", "referral_earned": "ربحت {amount} رصيداً لإحالة {user}!"},
    "es": {"welcome": "¡Bienvenido a {brand}!", "plan_expired": "Tu plan ha expirado.",
           "bot_started": "¡El bot {name} está activo!", "bot_crashed": "El bot {name} falló.",
           "payment_received": "¡Pago recibido!", "referral_earned": "¡Ganaste {amount} créditos por referir a {user}!"},
    "tr": {"welcome": "{brand}'e hoş geldiniz!", "plan_expired": "Planın süresi doldu.",
           "bot_started": "{name} botu çalışıyor!", "bot_crashed": "{name} botu çöktü.",
           "payment_received": "Ödeme alındı!", "referral_earned": "{user} için {amount} kredi kazandın!"},
}


def _lang_get_user(uid):
    d = db_load()
    return d["users"].get(str(uid), {}).get("lang", get_setting("ui_language", "en") or "en")


def _lang_set_user(uid, lang):
    d = db_load()
    if str(uid) in d["users"]:
        d["users"][str(uid)]["lang"] = lang
        db_save(d)


def _tr(uid, key, **ctx):
    lang  = _lang_get_user(uid)
    texts = _TRANSLATIONS.get(lang, _TRANSLATIONS["en"])
    tmpl  = texts.get(key) or _TRANSLATIONS["en"].get(key, key)
    try:
        return tmpl.format(**ctx)
    except (KeyError, ValueError):
        return tmpl


# ─── Feature Flags Engine ───────────────────────────────────────────────────

def _ff_get(key):
    flags = get_setting("feature_flags", {}) or {}
    return bool(flags.get(key, _FEATURE_FLAG_DEFAULTS.get(key, True)))


def _ff_set(key, val):
    flags = get_setting("feature_flags", {}) or {}
    flags[key] = bool(val)
    set_setting("feature_flags", flags)


def _ff_toggle(key):
    new_val = not _ff_get(key)
    _ff_set(key, new_val)
    return new_val


def _ff_reset_all():
    set_setting("feature_flags", dict(_FEATURE_FLAG_DEFAULTS))


# ─── 2FA Engine ─────────────────────────────────────────────────────────────

_2FA_CODES = {}
_2FA_LOCK  = threading.Lock()


def _2fa_generate(uid):
    import random
    code = str(random.randint(100000, 999999))
    with _2FA_LOCK:
        _2FA_CODES[uid] = {"code": code, "ts": time.time(), "attempts": 0}
    return code


def _2fa_verify(uid, code):
    with _2FA_LOCK:
        entry = _2FA_CODES.get(uid)
        if not entry:
            return False, "No active session. Request a new code."
        if time.time() - entry["ts"] > 300:
            _2FA_CODES.pop(uid, None)
            return False, "Code expired."
        if entry["attempts"] >= 3:
            _2FA_CODES.pop(uid, None)
            return False, "Too many attempts."
        entry["attempts"] += 1
        if entry["code"] == code.strip():
            _2FA_CODES.pop(uid, None)
            return True, ""
        return False, f"Wrong code. {3 - entry['attempts']} attempt(s) left."


def _2fa_is_enabled():
    return bool(get_setting("admin_2fa_enabled", False))


def _2fa_send_code(uid):
    code = _2fa_generate(uid)
    try:
        bot.send_message(uid,
            f"<b>🔐 Admin 2FA Code</b>\n\n<code>{code}</code>\n\nExpires in 5 minutes.",
            parse_mode="HTML")
        return True
    except Exception:
        return False


def _2fa_session_check(uid):
    sessions = get_setting("admin_2fa_sessions", {}) or {}
    ts = sessions.get(str(uid), {}).get("ts", 0)
    return (time.time() - ts) < 86400


def _2fa_session_create(uid):
    sessions = get_setting("admin_2fa_sessions", {}) or {}
    sessions[str(uid)] = {"ts": time.time()}
    set_setting("admin_2fa_sessions", sessions)


def _2fa_revoke_all():
    set_setting("admin_2fa_sessions", {})


# ─── Import/Export Engine ───────────────────────────────────────────────────

def _export_full_db():
    import json as _json
    payload = {
        "version": "2.0", "exported_at": ts_iso(),
        "db": db_load(), "settings": _load_settings(),
    }
    return _json.dumps(payload, indent=2, default=str).encode("utf-8")


def _import_full_db(data):
    import json as _json
    try:
        payload = _json.loads(data.decode("utf-8"))
    except Exception as e:
        return False, f"JSON parse error: {e}"
    db_data = payload.get("db")
    if not isinstance(db_data, dict) or "users" not in db_data:
        return False, "Invalid DB structure."
    db_save(db_data)
    settings_data = payload.get("settings")
    if isinstance(settings_data, dict):
        _save_settings(settings_data)
    return True, f"Imported {len(db_data['users'])} users, {len(db_data['bots'])} bots."


def _export_users_csv():
    import csv, io
    d   = db_load()
    buf = io.StringIO()
    fn  = ["uid","name","username","plan","plan_expires","joined","banned","credits","referrals","bots"]
    w   = csv.DictWriter(buf, fieldnames=fn)
    w.writeheader()
    for uid, u in d["users"].items():
        bc = sum(1 for b in d["bots"].values() if str(b.get("owner")) == uid)
        w.writerow({"uid": uid, "name": u.get("name",""), "username": u.get("username",""),
                    "plan": u.get("plan","free"), "plan_expires": u.get("plan_expires",""),
                    "joined": u.get("joined",""), "banned": u.get("banned",False),
                    "credits": u.get("credits",0), "referrals": len(u.get("referrals",[])), "bots": bc})
    return buf.getvalue().encode("utf-8")


def _export_bots_csv():
    import csv, io
    d   = db_load()
    buf = io.StringIO()
    fn  = ["bot_id","name","owner","status","created","main_file","crash_count","total_run_hours"]
    w   = csv.DictWriter(buf, fieldnames=fn)
    w.writeheader()
    for bid, b in d["bots"].items():
        w.writerow({"bot_id": bid, "name": b.get("name",""), "owner": b.get("owner",""),
                    "status": b.get("status","stopped"), "created": b.get("created",""),
                    "main_file": b.get("main_file",""), "crash_count": b.get("crash_count",0),
                    "total_run_hours": b.get("total_run_hours",0)})
    return buf.getvalue().encode("utf-8")


def _export_transactions_csv():
    import csv, io
    d   = db_load()
    buf = io.StringIO()
    fn  = ["uid","user_name","type","amount","plan","ts","note"]
    w   = csv.DictWriter(buf, fieldnames=fn)
    w.writeheader()
    for uid, u in d["users"].items():
        for tx in u.get("transactions", []):
            w.writerow({"uid": uid, "user_name": u.get("name",""), "type": tx.get("type",""),
                        "amount": tx.get("amount",0), "plan": tx.get("plan",""),
                        "ts": tx.get("ts",""), "note": tx.get("note","")})
    return buf.getvalue().encode("utf-8")


def _export_audit_log_csv():
    import csv, io
    log = get_setting("security_audit_log", []) or []
    buf = io.StringIO()
    fn  = ["ts","uid","action","detail","risk"]
    w   = csv.DictWriter(buf, fieldnames=fn)
    w.writeheader()
    for e in log:
        w.writerow({"ts": e.get("ts",""), "uid": e.get("uid",""), "action": e.get("action",""),
                    "detail": e.get("detail",""), "risk": e.get("risk","low")})
    return buf.getvalue().encode("utf-8")


# ─── Janitor Engine ─────────────────────────────────────────────────────────

def _janitor_purge_stale_tmp(max_age_hours=24):
    count  = 0
    cutoff = time.time() - max_age_hours * 3600
    for p in DIRS["tmp"].iterdir():
        try:
            if p.is_file() and p.stat().st_mtime < cutoff:
                p.unlink(); count += 1
        except Exception:
            pass
    return count


def _janitor_purge_empty_sandboxes():
    import shutil
    d           = db_load()
    valid_ids   = set(d["bots"].keys())
    sandbox_root= DIRS.get("sandboxes", BASE_DIR / "sandboxes")
    count       = 0
    if not sandbox_root.exists():
        return 0
    for p in sandbox_root.iterdir():
        if p.is_dir() and p.name not in valid_ids:
            try:
                shutil.rmtree(p); count += 1
            except Exception:
                pass
    return count


def _janitor_compact_db():
    d = db_load()
    tx_trunc = 0
    for u in d["users"].values():
        txs = u.get("transactions", [])
        if len(txs) > 200:
            u["transactions"] = txs[-200:]
            tx_trunc += len(txs) - 200
    orphan = [bid for bid, b in d["bots"].items() if not b.get("owner")]
    for bid in orphan:
        del d["bots"][bid]
    sessions = get_setting("admin_2fa_sessions", {}) or {}
    stale    = [k for k, v in sessions.items() if time.time() - v.get("ts",0) > 86400]
    for k in stale:
        sessions.pop(k, None)
    set_setting("admin_2fa_sessions", sessions)
    db_save(d)
    return {"tx_truncated": tx_trunc, "orphan_bots": len(orphan), "stale_sessions": len(stale)}


def _janitor_full_run():
    tmp_del  = _janitor_purge_stale_tmp()
    sbox_del = _janitor_purge_empty_sandboxes()
    ok, ver  = _do_clean_orphans()
    compact  = _janitor_compact_db()
    return {
        "tmp_files_deleted":    tmp_del,
        "empty_sandboxes":      sbox_del,
        "orphan_procs_killed":  ok,
        "orphan_procs_verified":ver,
        "tx_truncated":         compact["tx_truncated"],
        "orphan_bots_removed":  compact["orphan_bots"],
        "stale_sessions_purged":compact["stale_sessions"],
    }


# ─── Scheduler Engine ───────────────────────────────────────────────────────

def _sched_add_task(task_type, task_time, msg, target="all"):
    tasks = get_setting("scheduled_tasks", []) or []
    task  = {
        "id": f"task_{int(time.time())}", "type": task_type, "time": task_time,
        "msg": msg, "target": target, "enabled": True, "created": ts_iso(),
        "last_run": None, "run_count": 0,
    }
    tasks.append(task)
    set_setting("scheduled_tasks", tasks)
    return task


def _sched_remove_task(task_id):
    tasks = get_setting("scheduled_tasks", []) or []
    orig  = len(tasks)
    tasks = [t for t in tasks if t.get("id") != task_id]
    if len(tasks) < orig:
        set_setting("scheduled_tasks", tasks)
        return True
    return False


def _sched_toggle_task(task_id):
    tasks = get_setting("scheduled_tasks", []) or []
    for t in tasks:
        if t.get("id") == task_id:
            t["enabled"] = not t.get("enabled", True)
            set_setting("scheduled_tasks", tasks)
            return t["enabled"]
    return None


def _sched_broadcast(msg, target="all"):
    d    = db_load()
    uids = []
    for uid_s, u in d["users"].items():
        if u.get("banned"):
            continue
        if target == "all":
            uids.append(int(uid_s))
        elif target == "paid" and u.get("plan","free") not in ("free", None):
            uids.append(int(uid_s))
        elif target == "free" and u.get("plan","free") in ("free", None):
            uids.append(int(uid_s))
    sent = 0
    for uid in uids:
        try:
            bot.send_message(uid, msg, parse_mode="HTML")
            sent += 1; time.sleep(0.04)
        except Exception:
            pass
    return sent


# ─── Referral Engine ────────────────────────────────────────────────────────

def _ref_process(new_uid, ref_uid):
    if not _ff_get("referral_enabled") or new_uid == ref_uid:
        return False
    d       = db_load()
    ref_u   = d["users"].get(str(ref_uid), {})
    if new_uid in ref_u.get("referrals", []):
        return False
    reward  = float(get_setting("referral_reward", 0) or 0)
    ref_u.setdefault("referrals", []).append(new_uid)
    if reward > 0:
        ref_u["credits"] = float(ref_u.get("credits", 0)) + reward
    db_save(d)
    try:
        new_name = d["users"].get(str(new_uid), {}).get("name", str(new_uid))
        bot.send_message(ref_uid,
            f"<b>{G['spark']} Referral Reward!</b>\n"
            f"{bullet('New user', esc(str(new_name)))}\n"
            f"{bullet('Credits', reward)}", parse_mode="HTML")
    except Exception:
        pass
    _wh_fire("referral", {"ref_uid": ref_uid, "new_uid": new_uid, "reward": reward})
    return True


def _ref_get_link(uid):
    me = bot.get_me()
    return f"https://t.me/{me.username if me else 'YourBot'}?start=ref_{uid}"


def _ref_stats(uid):
    d   = db_load()
    u   = d["users"].get(str(uid), {})
    refs= u.get("referrals", [])
    return {
        "total":   len(refs),
        "credits": u.get("credits", 0),
        "link":    _ref_get_link(uid),
        "users":   [{
            "uid":  rid,
            "name": d["users"].get(str(rid), {}).get("name", str(rid)),
            "plan": d["users"].get(str(rid), {}).get("plan", "free"),
        } for rid in refs],
    }


# ─── Monitor / Diagnostics ──────────────────────────────────────────────────

def _monitor_system_stats():
    import os
    stats = {}
    stats["uptime"] = fmt_dur(int(time.time() - START_TIME) * 1000)
    stats["uptime_secs"] = int(time.time() - START_TIME)
    try:
        with open("/proc/meminfo") as f:
            mem = {}
            for line in f:
                parts = line.split()
                if len(parts) >= 2:
                    mem[parts[0].rstrip(":")] = int(parts[1])
        tm = mem.get("MemTotal",0)//1024
        av = mem.get("MemAvailable",0)//1024
        stats.update({"mem_total_mb": tm, "mem_used_mb": tm-av,
                       "mem_pct": round((tm-av)/tm*100,1) if tm else 0})
    except Exception:
        stats.update({"mem_total_mb": 0, "mem_used_mb": 0, "mem_pct": 0})
    try:
        with open("/proc/loadavg") as f:
            la = f.read().split()
        stats.update({"load_1": float(la[0]), "load_5": float(la[1]), "load_15": float(la[2])})
    except Exception:
        stats.update({"load_1": 0, "load_5": 0, "load_15": 0})
    try:
        st = os.statvfs(str(BASE_DIR))
        tg = st.f_blocks*st.f_frsize/1e9
        fg = st.f_bavail*st.f_frsize/1e9
        stats.update({"disk_total_gb": round(tg,2), "disk_used_gb": round(tg-fg,2),
                       "disk_free_gb": round(fg,2), "disk_pct": round((tg-fg)/tg*100,1) if tg else 0})
    except Exception:
        stats.update({"disk_total_gb": 0, "disk_used_gb": 0, "disk_pct": 0})
    stats["running_bots"]  = len(RUNNING)
    stats["total_threads"] = threading.active_count()
    stats["pid"]           = os.getpid()
    try:
        d = db_load()
        stats["total_users"]  = len(d["users"])
        stats["total_bots"]   = len(d["bots"])
        stats["paid_users"]   = sum(1 for u in d["users"].values()
                                    if u.get("plan","free") not in ("free",None))
    except Exception:
        stats.update({"total_users":0,"total_bots":0,"paid_users":0})
    stats["metrics"] = _metrics_snapshot()
    return stats


def _progress_bar(current, total=None, width=12):
    """Render a progress bar for either pct-only or current/total callers."""
    try:
        if total is None:
            pct = max(0.0, min(float(current) / 100.0, 1.0))
        elif float(total) <= 0:
            pct = 0.0
        else:
            pct = max(0.0, min(float(current) / float(total), 1.0))
    except (TypeError, ValueError, ZeroDivisionError):
        pct = 0.0
    filled = int(pct * width)
    return "█" * filled + "░" * (width - filled) + f" {pct*100:.1f}%"


def _run_diagnostics():
    import os, shutil
    report = {
        "bot_token":      bool(TOKEN),
        "db_writable":    DB_FILE.parent.exists() and os.access(str(DB_FILE.parent), os.W_OK),
        "sandbox_exists": DIRS.get("sandboxes", BASE_DIR/"sandboxes").exists(),
        "python_found":   bool(shutil.which("python3")),
        "owner_set":      OWNER_ID > 0,
        "threads_running":threading.active_count() > 3,
        "uptime_secs":    int(time.time() - START_TIME),
        "running_bots":   len(RUNNING),
    }
    return report


# ─── Utility Helpers ────────────────────────────────────────────────────────

def _truncate(s, max_len=200, suffix="…"):
    return s if len(s) <= max_len else s[:max_len-len(suffix)] + suffix

def _sanitize_filename(name):
    import re
    return re.sub(r"[^\w\-_\. ]","_",name).strip()[:100]

def _human_number(n):
    if n >= 1_000_000: return f"{n/1_000_000:.1f}M"
    if n >= 1_000:     return f"{n/1_000:.1f}K"
    return str(int(n))

def _safe_int(val, default=0):
    try:    return int(val)
    except: return default

def _safe_float(val, default=0.0):
    try:    return float(val)
    except: return default

def _clamp(val, lo, hi):
    return max(lo, min(hi, val))

def _chunk_list(lst, size):
    return [lst[i:i+size] for i in range(0, len(lst), size)]

def _hash_str(s):
    import hashlib
    return hashlib.sha256(s.encode()).hexdigest()

def _gen_random_id(length=12):
    import random, string
    return "".join(random.choices(string.ascii_lowercase+string.digits, k=length))

def _gen_coupon_code(prefix="", length=8):
    import random, string
    return (prefix + "".join(random.choices(string.ascii_uppercase+string.digits, k=length))).upper()

def _parse_duration(s):
    import re
    m = re.match(r"^(\d+)\s*([dhms]?)$", s.strip().lower())
    if not m: return 0
    return int(m.group(1)) * {"d":86400,"h":3600,"m":60,"s":1}.get(m.group(2) or "s", 1)

def _format_duration_human(secs):
    if secs < 0: return "0s"
    d,secs = divmod(int(secs),86400)
    h,secs = divmod(secs,3600)
    mi,s   = divmod(secs,60)
    parts  = []
    if d:  parts.append(f"{d}d")
    if h:  parts.append(f"{h}h")
    if mi: parts.append(f"{mi}m")
    if s or not parts: parts.append(f"{s}s")
    return " ".join(parts)

def _iso_add_days(iso_ts, days):
    try:
        from datetime import datetime, timezone, timedelta
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        return (dt + timedelta(days=days)).isoformat()
    except Exception:
        return iso_ts

def _iso_now_plus_days(days):
    from datetime import timedelta
    return (now_utc() + timedelta(days=days)).isoformat()

def _validate_bot_token_format(token):
    import re
    return bool(re.match(r"^\d{8,10}:[A-Za-z0-9_-]{35}$", token.strip()))

def _validate_url(url):
    return url.startswith(("http://","https://")) and "." in url

def _time_since(iso_ts):
    if not iso_ts: return "never"
    try:
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        secs = int((now_utc()-dt).total_seconds())
        if secs < 60:   return f"{secs}s ago"
        if secs < 3600: return f"{secs//60}m ago"
        if secs < 86400:return f"{secs//3600}h ago"
        return f"{secs//86400}d ago"
    except: return iso_ts[:10]

def _until(iso_ts):
    if not iso_ts: return "never"
    try:
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(iso_ts)
        if dt.tzinfo is None: dt = dt.replace(tzinfo=timezone.utc)
        secs = int((dt-now_utc()).total_seconds())
        if secs <= 0:   return "expired"
        if secs < 3600: return f"{secs//60}m"
        if secs < 86400:return f"{secs//3600}h"
        return f"{secs//86400}d"
    except: return iso_ts[:10]

def _mask_token(token):
    if not token or len(token) < 10: return "****"
    return token[:6] + "..." + token[-4:]

def _mask_secret(s, show_chars=4):
    if not s: return "—"
    if len(s) <= show_chars: return "*"*len(s)
    return s[:show_chars] + "*"*(len(s)-show_chars)

def _size_of_dir(path):
    total = 0
    try:
        for p in Path(path).rglob("*"):
            if p.is_file():
                try: total += p.stat().st_size
                except: pass
    except: pass
    return total

def _env_dict_from_str(env_str):
    result = {}
    for line in env_str.strip().split("\n"):
        line = line.strip()
        if not line or line.startswith("#"): continue
        if "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip()
    return result

def _env_dict_to_str(env_dict):
    return "\n".join(f"{k}={v}" for k, v in sorted(env_dict.items()))

def _diff_dicts(old, new):
    changes = {}
    for k in set(old)|set(new):
        ov, nv = old.get(k,"__MISSING__"), new.get(k,"__MISSING__")
        if ov != nv: changes[k] = {"old": ov, "new": nv}
    return changes


# ─── API Key Manager ────────────────────────────────────────────────────────

def _apikey_generate(uid):
    import secrets
    key = "sbhb_" + secrets.token_urlsafe(32)
    d = db_load()
    if str(uid) in d["users"]:
        d["users"][str(uid)]["api_key_hash"] = _hash_str(key)
        d["users"][str(uid)]["api_key_created"] = ts_iso()
        db_save(d)
    return key


def _apikey_verify(key):
    key_hash = _hash_str(key)
    d = db_load()
    for uid_s, u in d["users"].items():
        if u.get("api_key_hash") == key_hash:
            return int(uid_s)
    return 0


def _apikey_revoke(uid):
    d = db_load()
    if str(uid) in d["users"]:
        d["users"][str(uid)].pop("api_key_hash", None)
        d["users"][str(uid)].pop("api_key_created", None)
        db_save(d)
        return True
    return False


# ─── Payment Processor ──────────────────────────────────────────────────────

def _payment_create_request(uid, plan, amount, method, coupon=""):
    import random, string
    req_id   = "pay_" + "".join(random.choices(string.ascii_lowercase+string.digits, k=12))
    discount = 0.0
    if coupon:
        ok, _, c = _coupon_validate(coupon, uid)
        if ok:
            discount = float(c.get("discount_pct", 0))
            flat     = float(c.get("discount_flat", 0))
            if discount: amount = round(amount*(1-discount/100), 2)
            if flat:     amount = max(0, round(amount-flat, 2))
    req = {"id": req_id, "uid": uid, "plan": plan, "amount": amount, "method": method,
           "coupon": coupon, "discount": discount, "status": "pending",
           "created": ts_iso(), "updated": ts_iso(), "note": ""}
    reqs = get_setting("payment_requests", []) or []
    reqs.append(req)
    if len(reqs) > 1000: reqs = reqs[-1000:]
    set_setting("payment_requests", reqs)
    _wh_fire("payment_request_created", {"req_id": req_id, "uid": uid, "plan": plan, "amount": amount})
    return req


def _payment_approve(req_id, admin_uid, note=""):
    reqs = get_setting("payment_requests", []) or []
    req  = next((r for r in reqs if r["id"] == req_id), None)
    if not req: return False, "Request not found."
    if req["status"] != "pending": return False, f"Already {req['status']}."
    req.update({"status": "approved", "updated": ts_iso(), "note": note, "approved_by": admin_uid})
    set_setting("payment_requests", reqs)
    uid, plan = req["uid"], req["plan"]
    d = db_load()
    u = d["users"].get(str(uid), {})
    old_plan = u.get("plan", "free")
    u["plan"] = plan
    expires  = u.get("plan_expires", "")
    base     = ts_iso() if not expires or expires < ts_iso() else expires
    u["plan_expires"] = _iso_add_days(base, 30)
    u.setdefault("transactions", []).append({
        "type": "upgrade", "ts": ts_iso(), "plan": plan,
        "amount": req["amount"], "req_id": req_id, "note": note})
    u.setdefault("purchases", []).append({
        "payment_id": req_id, "plan": plan,
        "plan_name": PLAN_LIMITS.get(plan, {}).get("name", plan),
        "amount": float(req.get("amount", 0) or 0),
        "method": req.get("method"), "purchased_at": ts_iso(), "status": "completed"
    })
    if len(u["purchases"]) > 100:
        u["purchases"] = u["purchases"][-100:]
    db_save(d)
    audit(admin_uid, "payment_approved", f"req={req_id} uid={uid} plan={plan}")
    _wh_fire("payment_approved", {"req_id": req_id, "uid": uid, "plan": plan})
    _metric("plan_upgrades"); _metric("payments_received")
    try:
        bot.send_message(uid,
            f"<b>{G['ok']} Payment Approved!</b>\n"
            f"{bullet('Plan', plan)}\n{bullet('Expires', u['plan_expires'][:10])}\n"
            f"Enjoy your upgraded features!", parse_mode="HTML")
    except Exception:
        pass
    return True, f"Approved. {old_plan} → {plan}."


def _payment_reject(req_id, admin_uid, reason=""):
    reqs = get_setting("payment_requests", []) or []
    req  = next((r for r in reqs if r["id"] == req_id), None)
    if not req: return False, "Not found."
    req.update({"status": "rejected", "updated": ts_iso(), "note": reason, "rejected_by": admin_uid})
    set_setting("payment_requests", reqs)
    uid = req["uid"]
    audit(admin_uid, "payment_rejected", f"req={req_id} uid={uid}")
    _wh_fire("payment_rejected", {"req_id": req_id, "uid": uid, "reason": reason})
    try:
        bot.send_message(uid,
            f"<b>{G['no']} Payment Rejected</b>\n"
            f"{bullet('Reason', esc(reason) if reason else 'Not specified')}",
            parse_mode="HTML")
    except Exception:
        pass
    return True, "Rejected."


def _payment_list_pending():
    reqs = get_setting("payment_requests", []) or []
    return sorted([r for r in reqs if r.get("status") == "pending"],
                  key=lambda r: r.get("created",""), reverse=True)


def _payment_stats():
    reqs     = get_setting("payment_requests", []) or []
    approved = [r for r in reqs if r.get("status") == "approved"]
    return {
        "total":    len(reqs),
        "pending":  sum(1 for r in reqs if r.get("status") == "pending"),
        "approved": len(approved),
        "rejected": sum(1 for r in reqs if r.get("status") == "rejected"),
        "revenue":  sum(float(r.get("amount",0)) for r in approved),
    }


# ─── Process Monitor ────────────────────────────────────────────────────────

def _proc_get_memory_mb(pid):
    try:
        with open(f"/proc/{pid}/status") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) / 1024
    except Exception:
        pass
    return 0.0


def _all_running_bot_stats():
    result = []
    for bid, info in list(RUNNING.items()):
        proc = info.get("proc")
        pid  = proc.pid if proc else 0
        b    = find_bot(bid)
        result.append({
            "bot_id":    bid,
            "name":      b.get("name", bid) if b else bid,
            "owner":     b.get("owner", 0)  if b else 0,
            "pid":       pid,
            "memory_mb": _proc_get_memory_mb(pid),
            "started_at":info.get("started_at", ""),
        })
    result.sort(key=lambda x: x["memory_mb"], reverse=True)
    return result


# ─── Extra Admin Render Helpers ─────────────────────────────────────────────

def render_adm_diagnostics(call):
    report = _run_diagnostics()
    ok = lambda v: "✅" if v else "❌"
    cap = (
        f"<b>🔬 {sc('System Diagnostics')}</b>\n{G['div_eq']}\n"
        f"{ok(report['bot_token'])}  BOT_TOKEN set\n"
        f"{ok(report['db_writable'])}  DB writable\n"
        f"{ok(report['sandbox_exists'])}  Sandbox dir\n"
        f"{ok(report['python_found'])}  Python found\n"
        f"{ok(report['owner_set'])}  Owner configured\n"
        f"{ok(report['threads_running'])}  Background threads\n"
        f"{G['div']}\n"
        + bullet("Uptime", _format_duration_human(report["uptime_secs"])) + "\n"
        + bullet("Running bots", report["running_bots"]) + "\n"
        + G["div"] + FOOTER
    )
    show_menu(call.message.chat.id, PHOTOS.get("monitor", PHOTOS["admin"]),
              cap, _adm_back("menu_admin"), call=call)


def render_adm_payment_requests(call):
    pending = _payment_list_pending()
    pstats  = _payment_stats()
    lines   = [
        f"<b>💳 {sc('Payment Requests')}</b>", G["div_eq"],
        bullet("Total",    pstats["total"]),   bullet("Pending",  pstats["pending"]),
        bullet("Approved", pstats["approved"]),bullet("Revenue",  round(pstats["revenue"],2)),
        G["div"],
    ]
    if not pending:
        lines.append(f"  {sc('No pending requests')}")
    for req in pending[:10]:
        lines.append(f"  💳 <code>{req['id'][:12]}</code> {req['uid']} → {req['plan']} ({req['amount']})")
    lines.append(G["div"] + FOOTER)
    cap = "\n".join(lines)
    kb  = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("✅  Aᴘᴘʀᴏᴠᴇ", callback_data="adm_pay_approve_select", style="success"),
        Btn("❌  Rᴇᴊᴇᴄᴛ",   callback_data="adm_pay_reject_select",  style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("pay_config", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_process_monitor(call):
    stats = _all_running_bot_stats()
    lines = [f"<b>🔬 {sc('Process Monitor')}</b>", G["div_eq"],
             bullet("Running bots", len(stats)), G["div"]]
    if not stats:
        lines.append(f"  {sc('No bots running')}")
    for s in stats[:15]:
        lines.append(f"  🤖 <b>{esc(str(s['name'])[:20])}</b>  PID:{s['pid']}  Mem:{s['memory_mb']:.1f}MB")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("monitor", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_live_monitor"), call=call)


def render_adm_security_log(call):
    log    = get_setting("security_audit_log", []) or []
    recent = list(reversed(log[-20:]))
    lines  = [f"<b>🔐 {sc('Security Audit Log')}</b>", G["div_eq"],
              bullet("Total entries", len(log)), G["div"]]
    risk_icon = {"low":"🟢","medium":"🟡","high":"🔴","critical":"💀"}
    for e in recent[:15]:
        icon = risk_icon.get(e.get("risk","low"),"🟢")
        lines.append(f"  {icon} <code>{e.get('ts','')[:16]}</code> {e.get('uid','?')}: {esc(str(e.get('action',''))[:30])}")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS["admin"], "\n".join(lines), _adm_back("menu_admin"), call=call)


def render_adm_broadcast_status(call):
    lines = [f"<b>📢 {sc('Broadcast Status')}</b>", G["div_eq"]]
    if not _BROADCAST_ACTIVE:
        lines.append(f"  {sc('No active broadcast jobs')}")
    for jid, st in _BROADCAST_ACTIVE.items():
        done  = st.get("done", False)
        total = st.get("total", 0)
        sent  = st.get("sent", 0)
        fail  = st.get("failed", 0)
        lines.append(f"  {'✅' if done else '🔄'} <code>{jid}</code>")
        lines.append(f"     {_progress_bar(sent+fail, total)}")
        lines.append(f"     Sent:{sent} Failed:{fail} Total:{total}")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS["admin"], "\n".join(lines), _adm_back("menu_admin"), call=call)


def render_adm_api_keys(call):
    d    = db_load()
    keys = [(uid, u.get("name",uid), u.get("api_key_created","")[:10])
            for uid, u in d["users"].items() if u.get("api_key_hash")]
    lines = [f"<b>🔑 {sc('API Key Manager')}</b>", G["div_eq"],
             bullet("Users with keys", len(keys)), G["div"]]
    for uid, name, created in keys[:10]:
        lines.append(f"  🔑 <code>{uid}</code>  {esc(str(name)[:20])} (created {created})")
    lines.append(G["div"] + FOOTER)
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(Btn("🗑️  Rᴇᴠᴏᴋᴇ Aʟʟ", callback_data="adm_apikey_revoke_all", style="danger"))
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], "\n".join(lines), kb, call=call)


def action_adm_sub_send_reminders(call):
    sent = _sub_renewal_reminders()
    ack(call, f"{G['ok']} Sent {sent} renewal reminder(s)")


def render_adm_webhook_log(call):
    log    = get_setting("webhook_log", []) or []
    recent = list(reversed(log[-20:]))
    lines  = [f"<b>🔗 {sc('Webhook Log')}</b>", G["div_eq"], bullet("Total", len(log)), G["div"]]
    for e in recent[:15]:
        st   = str(e.get("status","?"))
        icon = "✅" if st in ("200","201","204") else "❌"
        lines.append(f"  {icon} <code>{e.get('ts','')[:16]}</code> {esc(str(e.get('event',''))[:25])} → {st}")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("webhooks", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_webhooks"), call=call)


def render_adm_rate_stats(call):
    with _RATE_LOCK:
        bc    = len(_RATE_BUCKETS)
        top   = sorted(_RATE_BUCKETS.items(), key=lambda x: x[1]["count"], reverse=True)[:10]
    lines = [f"<b>⚡ {sc('Rate Limit Stats')}</b>", G["div_eq"], bullet("Active buckets", bc), G["div"]]
    for key, bucket in top:
        lines.append(f"  <code>{key[:30]}</code>: {bucket['count']} hits")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("rate_limits", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_rate_cfg"), call=call)


def action_adm_export_full_db(call):
    data  = _export_full_db()
    fname = f"kryon_db_{now_utc().strftime('%Y%m%d_%H%M%S')}.json"
    import io
    bot.send_document(call.message.chat.id, (fname, io.BytesIO(data)),
                      caption=f"<b>📂 Full DB Export</b>\n{bullet('Size', fmt_bytes(len(data)))}",
                      parse_mode="HTML")
    ack(call, f"{G['ok']} Export sent")


def action_adm_export_users_csv(call):
    data  = _export_users_csv()
    fname = f"kryon_users_{now_utc().strftime('%Y%m%d')}.csv"
    import io
    bot.send_document(call.message.chat.id, (fname, io.BytesIO(data)),
                      caption=f"<b>👥 Users CSV</b>\n{bullet('Size', fmt_bytes(len(data)))}",
                      parse_mode="HTML")
    ack(call, f"{G['ok']} Users CSV sent")


def action_adm_export_bots_csv(call):
    data  = _export_bots_csv()
    fname = f"kryon_bots_{now_utc().strftime('%Y%m%d')}.csv"
    import io
    bot.send_document(call.message.chat.id, (fname, io.BytesIO(data)),
                      caption=f"<b>🤖 Bots CSV</b>\n{bullet('Size', fmt_bytes(len(data)))}",
                      parse_mode="HTML")
    ack(call, f"{G['ok']} Bots CSV sent")


def action_adm_export_trans_csv(call):
    data  = _export_transactions_csv()
    fname = f"kryon_transactions_{now_utc().strftime('%Y%m%d')}.csv"
    import io
    bot.send_document(call.message.chat.id, (fname, io.BytesIO(data)),
                      caption=f"<b>💳 Transactions CSV</b>\n{bullet('Size', fmt_bytes(len(data)))}",
                      parse_mode="HTML")
    ack(call, f"{G['ok']} Transactions CSV sent")


def action_adm_export_audit_csv(call):
    data  = _export_audit_log_csv()
    fname = f"kryon_audit_{now_utc().strftime('%Y%m%d')}.csv"
    import io
    bot.send_document(call.message.chat.id, (fname, io.BytesIO(data)),
                      caption=f"<b>🔐 Audit CSV</b>\n{bullet('Size', fmt_bytes(len(data)))}",
                      parse_mode="HTML")
    ack(call, f"{G['ok']} Audit CSV sent")


def render_adm_referral_detail(call):
    top       = _analytics_top_referrers(15)
    total_refs= sum(r[2] for r in top)
    lines     = [f"<b>👥 {sc('Referral Analytics')}</b>", G["div_eq"],
                 bullet("Total referrals", total_refs), bullet("Active referrers", len(top)),
                 bullet("Reward/referral", get_setting("referral_reward", 0)),
                 G["div"], f"<b>🏆 Top Referrers</b>"]
    medals = ["🥇","🥈","🥉"]
    for i, (uid, name, cnt) in enumerate(top[:10], 1):
        m = medals[i-1] if i <= 3 else f"{i}."
        lines.append(f"  {m} {esc(str(name)[:20])} — {cnt} refs")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("referral_adm", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_referral_sys"), call=call)


def render_adm_sub_expiry_report(call):
    d   = db_load()
    from datetime import timedelta
    thr = (now_utc() + timedelta(days=7)).isoformat()
    now = ts_iso()
    exp = [(uid, u.get("name",uid), u.get("plan","free"), u.get("plan_expires","")[:10])
           for uid, u in d["users"].items()
           if u.get("plan","free") not in ("free",None)
           and u.get("plan_expires","") and now < u["plan_expires"] <= thr]
    exp.sort(key=lambda x: x[3])
    lines = [f"<b>⏰ {sc('Expiring Soon (7d)')}</b>", G["div_eq"], bullet("Expiring", len(exp)), G["div"]]
    for uid, name, plan, date in exp[:15]:
        lines.append(f"  ⏳ {esc(str(name)[:18])} — {plan} — {date}")
    lines.append(G["div"] + FOOTER)
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(Btn("📨  Sᴇɴᴅ Rᴇᴍɪɴᴅᴇʀꜱ", callback_data="adm_sub_send_reminders", style="primary"))
    kb.add(Btn(f"{G['back']}  Sᴜʙꜱ", callback_data="adm_subscriptions", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("subscriptions", PHOTOS["admin"]),
              "\n".join(lines), kb, call=call)


def render_adm_lang_stats(call):
    d      = db_load()
    counts = {}
    for u in d["users"].values():
        lang = u.get("lang","en") or "en"
        counts[lang] = counts.get(lang,0) + 1
    total = len(d["users"]) or 1
    lines = [f"<b>🌐 {sc('Language Stats')}</b>", G["div_eq"],
             bullet("Total users", len(d["users"])),
             bullet("Default", get_setting("ui_language","en") or "en"), G["div"]]
    for lang, cnt in sorted(counts.items(), key=lambda x: x[1], reverse=True):
        name = _SUPPORTED_LANGUAGES.get(lang, lang)
        lines.append(f"  🌐 {name}: {cnt} ({round(cnt/total*100,1)}%)")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("lang_panel", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_lang_panel"), call=call)


def render_adm_scheduler_history(call):
    tasks = get_setting("scheduled_tasks", []) or []
    lines = [f"<b>⏰ {sc('Scheduler Tasks')}</b>", G["div_eq"], bullet("Total tasks", len(tasks)), G["div"]]
    for t in tasks[:15]:
        icon = "🟢" if t.get("enabled",True) else "🔴"
        ttime = t.get("time","?")[:16]
        runs  = t.get("run_count",0)
        msg_p = esc(str(t.get("msg",""))[:30]) + "…"
        lines.append(f"  {icon} [{t.get('type','daily')}] {ttime} runs:{runs}  {msg_p}")
    lines.append(G["div"] + FOOTER)
    show_menu(call.message.chat.id, PHOTOS.get("scheduler", PHOTOS["admin"]),
              "\n".join(lines), _adm_back("adm_scheduler"), call=call)


def render_adm_export_menu(call):
    cap = (
        f"<b>📦 {sc('Export & Import')}</b>\n{G['div_eq']}\n"
        f"{sc('Export data in multiple formats')}\n\n"
        f"• <b>Full DB JSON</b> — complete backup\n"
        f"• <b>Users CSV</b>\n• <b>Bots CSV</b>\n"
        f"• <b>Transactions CSV</b>\n• <b>Audit Log CSV</b>\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("📂  Fᴜʟʟ DB",     callback_data="adm_export_full_db",   style="primary"),
        Btn("👥  Uꜱᴇʀꜱ CSV",   callback_data="adm_export_users_csv", style="primary"),
    )
    kb.add(
        Btn("🤖  Bᴏᴛꜱ CSV",   callback_data="adm_export_bots_csv",  style="primary"),
        Btn("💳  Tʀᴀɴꜱ CSV",  callback_data="adm_export_trans_csv", style="primary"),
    )
    kb.add(
        Btn("🔐  Aᴜᴅɪᴛ CSV",  callback_data="adm_export_audit_csv", style="primary"),
        Btn("📥  Iᴍᴘᴏʀᴛ DB",  callback_data="adm_import_db",        style="danger"),
    )
    kb.add(Btn(f"{G['back']}  Aᴅᴍɪɴ", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("import_export", PHOTOS["admin"]), cap, kb, call=call)


# ─── Extra Callback Router ──────────────────────────────────────────────────

def _register_extra_routes(data, call):
    """Returns True if handled."""
    # Help
    if data == "help_main":                  render_help_page(call.message.chat.id,"main",call=call); return True
    if data.startswith("help_"):             render_help_page(call.message.chat.id,data[5:],call=call); return True
    # Extra admin panels
    if data == "adm_diagnostics":            render_adm_diagnostics(call); return True
    if data == "adm_payment_requests":       render_adm_payment_requests(call); return True
    if data == "adm_process_monitor":        render_adm_process_monitor(call); return True
    if data == "adm_security_log":           render_adm_security_log(call); return True
    if data == "adm_broadcast_status":       render_adm_broadcast_status(call); return True
    if data == "adm_api_keys":               render_adm_api_keys(call); return True
    if data == "adm_apikey_revoke_all":
        if not is_owner(call.from_user.id):  ack(call,"Owner only"); return True
        d = db_load()
        cnt = 0
        for u in d["users"].values():
            if u.pop("api_key_hash",None): u.pop("api_key_created",None); cnt+=1
        db_save(d); ack(call,f"{G['ok']} Revoked {cnt} API keys")
        render_adm_api_keys(call); return True
    if data == "adm_sub_send_reminders":     action_adm_sub_send_reminders(call); return True
    if data == "adm_webhook_log":            render_adm_webhook_log(call); return True
    if data == "adm_rate_stats":             render_adm_rate_stats(call); return True
    if data == "adm_export_full_db":         action_adm_export_full_db(call); return True
    if data == "adm_export_users_csv":       action_adm_export_users_csv(call); return True
    if data == "adm_export_bots_csv":        action_adm_export_bots_csv(call); return True
    if data == "adm_export_trans_csv":       action_adm_export_trans_csv(call); return True
    if data == "adm_export_audit_csv":       action_adm_export_audit_csv(call); return True
    if data == "adm_referral_detail":        render_adm_referral_detail(call); return True
    if data == "adm_sub_expiry_report":      render_adm_sub_expiry_report(call); return True
    if data == "adm_lang_stats":             render_adm_lang_stats(call); return True
    if data == "adm_sched_history":          render_adm_scheduler_history(call); return True
    if data == "adm_export_menu":            render_adm_export_menu(call); return True
    return False


# ─── Extra Background Threads ───────────────────────────────────────────────

def _start_extra_background_threads():
    threading.Thread(target=_notif_runner,        daemon=True, name="notif-flush").start()
    threading.Thread(target=_rate_cleanup_loop,   daemon=True, name="rate-cleanup").start()
    threading.Thread(target=_sub_reminder_loop,   daemon=True, name="sub-reminder").start()
    threading.Thread(target=_metrics_persist_loop,daemon=True, name="metrics-persist").start()


# ─── Constant Lookup Tables ─────────────────────────────────────────────────

_STATUS_EMOJIS = {
    "running":"🟢","stopped":"🔴","crashed":"💥",
    "starting":"🟡","stopping":"🟠","idle":"⚪",
}
_RISK_EMOJIS = {"low":"🟢","medium":"🟡","high":"🔴","critical":"💀"}
_PAYMENT_STATUS_EMOJIS = {"pending":"⏳","approved":"✅","rejected":"❌","refunded":"↩️"}
_PLAN_DISPLAY_NAMES  = {"free":"🆓 Free","basic":"🥈 Basic","pro":"🥇 Pro","ultra":"💎 Ultra"}
_PLAN_ORDER          = ["free","basic","pro","ultra"]
_CURRENCY_SYMBOLS = {
    "USD":"$","EUR":"€","GBP":"£","INR":"₹","JPY":"¥","CNY":"¥","RUB":"₽","TRY":"₺",
    "KRW":"₩","BRL":"R$","AUD":"A$","CAD":"C$","CHF":"CHF","SGD":"S$","HKD":"HK$",
    "MXN":"MX$","AED":"د.إ","SAR":"﷼","ZAR":"R","THB":"฿","IDR":"Rp","MYR":"RM",
    "PHP":"₱","VND":"₫","PKR":"₨","INR":"₹","EGP":"£","NGN":"₦","KES":"Ksh",
}
_CRYPTO_SYMBOLS = {
    "BTC":"₿","ETH":"Ξ","USDT":"₮","BNB":"B","SOL":"◎","ADA":"₳",
    "XRP":"✕","DOT":"●","DOGE":"Ð","MATIC":"⬡","AVAX":"A","LTC":"Ł","TRX":"T",
}


def currency_code() -> str:
    code = str(get_setting("payment_currency", "INR") or "INR").upper().strip()
    return code if code in _CURRENCY_SYMBOLS else "INR"


def currency_symbol() -> str:
    sym = str(get_setting("currency_symbol", "₹") or "₹").strip()
    return sym or _CURRENCY_SYMBOLS.get(currency_code(), "₹")


def money(amount: Any) -> str:
    """Format all plan/wallet/payment amounts using the configured currency."""
    try:
        n = float(amount or 0)
        if n.is_integer():
            value = str(int(n))
        else:
            value = f"{n:.2f}".rstrip("0").rstrip(".")
    except Exception:
        value = str(amount)
    return f"{value}{currency_symbol()}"


def money_or_free(amount: Any) -> str:
    try:
        if float(amount or 0) == 0:
            return "Free"
    except Exception:
        pass
    return money(amount)
_ERROR_MESSAGES = {
    "not_registered":   "Please /start first to register.",
    "banned":           "You have been banned.",
    "admin_only":       "Admins only.",
    "owner_only":       "Owner only.",
    "bot_not_found":    "Bot not found.",
    "plan_limit_bots":  "Bot limit reached. Upgrade your plan.",
    "plan_limit_upload":"File exceeds upload limit.",
    "invalid_token":    "Invalid bot token format.",
    "invalid_url":      "Invalid URL.",
    "invalid_coupon":   "Invalid or expired coupon.",
    "upload_failed":    "Upload failed. Try again.",
    "rate_limited":     "You're going too fast. Slow down!",
    "2fa_required":     "Admin 2FA required.",
    "session_expired":  "Session expired. Start again.",
    "db_error":         "Database error. Try again.",
    "network_error":    "Network error. Try again.",
    "timeout":          "Operation timed out.",
    "permission_denied":"Permission denied.",
    "not_implemented":  "Feature not yet available.",
}
_SUCCESS_MESSAGES = {
    "bot_started":    "Bot started successfully!",
    "bot_stopped":    "Bot stopped successfully!",
    "bot_restarted":  "Bot restarted successfully!",
    "bot_deleted":    "Bot deleted.",
    "upload_ok":      "File uploaded successfully!",
    "plan_upgraded":  "Plan upgraded!",
    "env_saved":      "Environment variables saved!",
    "coupon_ok":      "Coupon applied!",
    "settings_saved": "Settings saved!",
    "backup_done":    "Backup completed!",
    "restore_done":   "Restore completed!",
    "ban_applied":    "User banned.",
    "ban_lifted":     "User unbanned.",
    "broadcast_queued":"Broadcast queued!",
    "task_added":     "Scheduled task added!",
    "task_removed":   "Task removed.",
    "2fa_verified":   "2FA verified! Access granted.",
    "export_ready":   "Export ready.",
}



# COMPLETION BLOCK — HANDLERS, NEW FEATURES, MAIN


# ─── Telegram Channel Backup ──────────────────────────────────────────────────

def _tg_channel_backup_enabled() -> bool:
    ch = get_setting("tg_backup_channel", None)
    return bool(ch)

def _tg_backup_channel() -> Optional[str]:
    return get_setting("tg_backup_channel", None)

def tg_channel_backup_now() -> Dict[str, Any]:
    """Zip the entire DB + settings + bot_data and send to a Telegram channel."""
    ch = _tg_backup_channel()
    if not ch:
        return {"ok": False, "error": "tg_backup_channel not configured"}
    try:
        out_dir = BASE_DIR / "exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        target = out_dir / f"tg_backup_{stamp}.zip"
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
            for name in ("user_data.json", "settings.json", "audit.log", "github_config.json"):
                p = BASE_DIR / "storage" / name
                if p.exists():
                    zf.write(p, arcname=name)
            bot_data = BASE_DIR / "storage" / "bot_data"
            if bot_data.exists():
                for f in bot_data.iterdir():
                    if f.is_file():
                        zf.write(f, arcname=f"bot_data/{f.name}")
            photos_dir = DIRS.get("photos")
            if photos_dir and photos_dir.exists():
                for f in photos_dir.iterdir():
                    if f.is_file() and f.name.startswith("custom_"):
                        zf.write(f, arcname=f"photos/{f.name}")
        sz = target.stat().st_size
        with target.open("rb") as fh:
            bot.send_document(
                ch, fh,
                caption=(
                    f"<b>\U0001f4be {sc('Telegram Channel Backup')}</b>\n"
                    f"{bullet('Time', stamp)}\n"
                    f"{bullet('Size', fmt_bytes(sz))}\n"
                    f"{bullet('Brand', BRAND_TAG)}"
                ),
                parse_mode="HTML",
                visible_file_name=f"kryon_backup_{stamp}.zip",
            )
        target.unlink(missing_ok=True)
        audit(0, "tg_channel_backup", f"channel={ch} size={sz}")
        return {"ok": True, "size": sz, "channel": ch}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def tg_channel_restore_latest() -> Dict[str, Any]:
    """Fetch the most recent backup zip from the configured Telegram channel."""
    ch = _tg_backup_channel()
    if not ch:
        return {"ok": False, "error": "tg_backup_channel not configured"}
    return {"ok": False, "error": "Use /getUpdates or export from Telegram to restore manually."}


def render_adm_tg_channel_backup(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    ch = _tg_backup_channel() or "\u2014"
    auto_on = bool(get_setting("tg_backup_auto", False))
    auto_interval = int(get_setting("tg_backup_interval_h", 6))
    cap = (
        f"<b>\U0001f4e1 {sc('Telegram Channel Backup')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Backup Channel', ch)}\n"
        f"{bullet('Auto Backup', 'ON' if auto_on else 'OFF')}\n"
        f"{bullet('Interval', f'{auto_interval}h')}\n"
        f"{G['div']}\n"
        f"{sc('Set a channel, add bot as admin, then enable backup.')}.\n"
        f"{sc('Bot will zip all data and send to the channel')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("\U0001f4e1  S\u1d07\u1d1b C\u029c\u0251\u0274\u0274\u1d07\u029f", callback_data="adm_tg_bkp_set_ch", style="primary"),
        Btn("\U0001f4be  B\u1d00\u1d04\u1d0b\u1d1c\u1d18 N\u1d0f\u1d21", callback_data="adm_tg_bkp_now", style="success"),
    )
    kb.add(
        Btn(f"{'OK' if auto_on else 'OFF'}  A\u1d1c\u1d1b\u1d0f", callback_data="adm_tg_bkp_toggle_auto",
            style="success" if auto_on else "danger"),
        Btn("\U0001f4e5  R\u1d07\u02e2\u1d1b\u1d0f\u0280\u1d07", callback_data="adm_tg_bkp_restore", style="danger"),
    )
    kb.add(Btn(f"{G['back']}  A\u1d05\u1d0d\u026a\u0274", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


# ─── GitHub Repo Hosting for Users ──────────────────────────────────────────

def _user_can_host_gh(u: Dict[str, Any]) -> bool:
    plan = u.get("plan", "free")
    return plan not in ("free",)


def render_gh_repo_host_menu(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    d = db_load()
    u = d["users"].get(str(uid), {})
    if not _user_can_host_gh(u):
        ack(call, "Pro/Ultra plan required for GitHub hosting")
        show_text(
            call.message.chat.id,
            f"<b>{G['no']} {sc('GitHub Repo Hosting — Pro+ Only')}</b>\n"
            f"{G['div']}\n"
            f"{sc('Upgrade to Pro or Ultra to host bots from GitHub repos')}.\n"
            f"{G['div']}{FOOTER}",
            back_main_kb(), call=call,
        )
        return
    cap = (
        f"<b>\U0001f419 {sc('Host from GitHub Repo')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Clone a GitHub repository and run it as a bot')}.\n"
        f"{sc('Supports public and private repos (with token)')}.\n"
        f"{G['div']}\n"
        f"<b>{sc('Steps')}:</b>\n"
        f"1. {sc('Set your GitHub token (for private repos)')}\n"
        f"2. {sc('Tap Clone Repo and paste the URL')}\n"
        f"3. {sc('Bot auto-detects entry file and runs')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("\U0001f419  C\u029f\u1d0f\u0274\u1d07 R\u1d07\u1d18\u1d0f", callback_data="gh_host_clone", style="primary"),
        Btn("\U0001f511  P\u0280\u026a\u1d20\u1d00\u1d1b\u1d07 T\u1d0f\u1d0b\u1d07\u0274", callback_data="gh_host_set_token", style="primary"),
    )
    kb.add(
        Btn("\U0001f4c2  M\u028f G\u029c B\u1d0f\u1d1b\u02e2", callback_data="gh_host_list", style="primary"),
        Btn("\U0001f5d1\ufe0f  R\u1d07\u1d0d\u1d0f\u1d20\u1d07 R\u1d07\u1d18\u1d0f", callback_data="gh_host_remove_sel", style="danger"),
    )
    kb.add(Btn(f"{G['back']}  M\u1d00\u026a\u0274", callback_data="menu_main", style="primary"))
    show_menu(call.message.chat.id, PHOTOS.get("upload", PHOTOS["main"]), cap, kb, call=call)


def _clone_gh_repo(repo_url: str, token: Optional[str], dest_dir: Path) -> Dict[str, Any]:
    """Clone a GitHub repo. Uses token for private repos."""
    import subprocess as _sp
    dest_dir.mkdir(parents=True, exist_ok=True)
    if token:
        url = repo_url.replace("https://", f"https://{token}@")
    else:
        url = repo_url
    try:
        result = _sp.run(
            ["git", "clone", "--depth=1", url, str(dest_dir)],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode != 0:
            return {"ok": False, "error": (result.stderr or result.stdout)[:500]}
        return {"ok": True}
    except FileNotFoundError:
        return {"ok": False, "error": "git not installed on server."}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def action_gh_host_clone(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"].get(str(uid), {})
    if not _user_can_host_gh(u):
        ack(call, "Pro+ only"); return
    USER_STATES[uid] = {"flow": "await_gh_repo_url"}
    bot.send_message(
        call.message.chat.id,
        f"<b>\U0001f419 {sc('Clone GitHub Repo')}</b>\n{G['div']}\n"
        f"{sc('Send the full repo URL')}:\n"
        f"<code>https://github.com/user/repo</code>\n\n"
        f"{sc('For private repos, set your token first via')} Private Token.\n"
        f"{sc('Use')} /cancel {sc('to abort')}.",
        parse_mode="HTML",
    )
    ack(call)


def action_gh_host_set_token(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    USER_STATES[uid] = {"flow": "await_gh_user_token"}
    bot.send_message(
        call.message.chat.id,
        f"<b>\U0001f511 {sc('Set GitHub Personal Access Token')}</b>\n{G['div']}\n"
        f"{sc('Token is encrypted and only used for cloning your repos')}.\n"
        f"{sc('Send token now or /cancel')}.",
        parse_mode="HTML",
    )
    ack(call)


def action_gh_host_list(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    bots = list_user_bots(uid)
    gh_bots = [b for b in bots if b.get("source") in ("github", "github_browser")]
    if not gh_bots:
        show_text(
            call.message.chat.id,
            f"<b>\U0001f4c2 {sc('GitHub-hosted Bots')}</b>\n{G['div']}\n"
            f"<i>{sc('No GitHub-hosted bots yet')}.</i>{FOOTER}",
            _adm_back("menu_gh_host"), call=call,
        )
        ack(call); return
    rows = "\n".join(
        f"{G['bullet']} <b>{esc(b['name'])}</b> \u2014 "
        f"<code>{esc((b.get('gh_repo','?'))[:40])}</code>"
        for b in gh_bots
    )
    cap = (
        f"<b>\U0001f419 {sc('Your GitHub-hosted Bots')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    for b in gh_bots:
        kb.add(Btn(f"\U0001f419  {esc(b['name'])[:30]}", callback_data=f"bot_view_{b['_id']}"))
    kb.add(Btn(f"{G['back']}  Main", callback_data="menu_main"))
    show_text(call.message.chat.id, cap, kb, call=call)
    ack(call)


# ─── GitHub File Browser ─────────────────────────────────────────────────────

def render_adm_gh_browser(call: types.CallbackQuery) -> None:
    if not admin_only_call(call, "view_stats"):
        return
    if not gh_enabled():
        show_text(
            call.message.chat.id,
            f"<b>\U0001f419 {sc('GitHub File Browser')}</b>\n{G['div']}\n"
            f"<i>{sc('GitHub backup not configured')}.</i>{FOOTER}",
            _adm_back("menu_admin"), call=call,
        )
        return
    _render_gh_dir(call, path="")


def _render_gh_dir(call: types.CallbackQuery, path: str = "") -> None:
    ack(call, "Browsing\u2026")
    def _bg() -> None:
        try:
            url = _gh_repo_url(f"contents/{path}") if path else _gh_repo_url("contents")
            r = _gh("GET", url, params={"ref": GH["branch"]})
            items = r.json() if r.status_code == 200 else []
            if not isinstance(items, list):
                items = [items]
            dirs  = sorted([x for x in items if x.get("type") == "dir"],  key=lambda x: x.get("name","").lower())
            files = sorted([x for x in items if x.get("type") == "file"], key=lambda x: x.get("name","").lower())
            path_display = f"/{path}" if path else "/ (root)"
            cap = (
                f"<b>\U0001f419 {sc('GitHub Browser')}</b>\n"
                f"{G['div_eq']}\n"
                f"{bullet('Repo',   GH.get('repo','?'))}\n"
                f"{bullet('Branch', GH.get('branch','main'))}\n"
                f"{bullet('Path',   esc(path_display))}\n"
                f"{bullet('Dirs',   len(dirs))}\n"
                f"{bullet('Files',  len(files))}\n"
                f"{G['div']}{FOOTER}"
            )
            kb = types.InlineKeyboardMarkup(row_width=1)
            if path:
                parent = "/".join(path.rstrip("/").split("/")[:-1])
                kb.add(Btn("\u2b06\ufe0f  .. (up)", callback_data=f"ghbrow_dir_{parent}"))
            for d in dirs[:15]:
                kb.add(Btn(f"\U0001f4c1  {esc(d['name'])}", callback_data=f"ghbrow_dir_{d['path']}"))
            for f in files[:20]:
                sz = fmt_bytes(f.get("size", 0))
                kb.add(Btn(f"\U0001f4c4  {esc(f['name'])} ({sz})", callback_data=f"ghbrow_file_{f['path']}"))
            kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin"))
            show_text(call.message.chat.id, cap, kb)
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                    f"<b>{G['no']} Browser Error</b>\n<code>{esc(e)}</code>", parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def _render_gh_file(call: types.CallbackQuery, path: str) -> None:
    ack(call, "Loading file\u2026")
    def _bg() -> None:
        try:
            r = _gh("GET", _gh_repo_url(f"contents/{path}"), params={"ref": GH["branch"]})
            if r.status_code != 200:
                bot.send_message(call.from_user.id, f"{G['no']} HTTP {r.status_code}"); return
            payload = r.json()
            content_b64 = payload.get("content", "")
            raw = base64.b64decode(content_b64.replace("\n", ""))
            try:
                text = raw.decode("utf-8")
                is_text = True
            except Exception:
                text = ""
                is_text = False
            fname = payload.get("name", path.split("/")[-1])
            sz = fmt_bytes(payload.get("size", len(raw)))
            cap = (
                f"<b>\U0001f4c4 {esc(fname)}</b>\n"
                f"{G['div_eq']}\n"
                f"{bullet('Path', esc(path))}\n"
                f"{bullet('Size', sz)}\n{G['div']}\n"
            )
            if is_text and len(text) <= 3000:
                cap += f"<pre>{esc(text[:2800])}</pre>"
            elif is_text:
                cap += f"<pre>{esc(text[:1500])}\u2026</pre>"
            else:
                cap += "<i>Binary file</i>"
            cap += FOOTER
            parent = "/".join(path.rstrip("/").split("/")[:-1])
            kb = types.InlineKeyboardMarkup(row_width=2)
            kb.add(
                Btn("\U0001f4e5  Download", callback_data=f"ghbrow_dl_{path}"),
                Btn("\u2b06\ufe0f  Back up",  callback_data=f"ghbrow_dir_{parent}"),
            )
            if fname.endswith((".py", ".js", ".mjs")):
                kb.add(Btn("\u25b6\ufe0f  Run this file", callback_data=f"ghbrow_run_{path}"))
            kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin"))
            show_text(call.message.chat.id, cap, kb)
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                    f"<b>{G['no']} File load error</b>\n<code>{esc(e)}</code>", parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def _action_gh_file_download(call: types.CallbackQuery, path: str) -> None:
    ack(call, "Downloading\u2026")
    def _bg() -> None:
        try:
            r = _gh("GET", _gh_repo_url(f"contents/{path}"), params={"ref": GH["branch"]})
            if r.status_code != 200:
                bot.send_message(call.from_user.id, f"{G['no']} HTTP {r.status_code}"); return
            payload = r.json()
            raw = base64.b64decode(payload.get("content", "").replace("\n", ""))
            fname = payload.get("name", path.split("/")[-1])
            tmp = Path(tempfile.mktemp(suffix=f"_{fname}"))
            tmp.write_bytes(raw)
            with tmp.open("rb") as fh:
                bot.send_document(call.from_user.id, fh,
                    caption=f"<b>\U0001f4c4 {esc(fname)}</b> ({fmt_bytes(len(raw))})",
                    parse_mode="HTML", visible_file_name=fname)
            tmp.unlink(missing_ok=True)
            audit(call.from_user.id, "gh_browser_download", f"path={path}")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                    f"<b>{G['no']} Download error</b>\n<code>{esc(e)}</code>", parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


def _action_gh_file_run(call: types.CallbackQuery, path: str) -> None:
    """Download .py/.js from GitHub and run it as a new bot."""
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    ack(call, "Running from GitHub\u2026")
    def _bg() -> None:
        try:
            r = _gh("GET", _gh_repo_url(f"contents/{path}"), params={"ref": GH["branch"]})
            if r.status_code != 200:
                bot.send_message(call.from_user.id, f"{G['no']} HTTP {r.status_code}"); return
            payload = r.json()
            raw = base64.b64decode(payload.get("content", "").replace("\n", ""))
            fname = payload.get("name", path.split("/")[-1])
            uid = call.from_user.id
            bot_id = secrets.token_hex(8)
            bot_dir = DIRS["sandbox"] / f"{uid}_{bot_id}"
            bot_dir.mkdir(parents=True, exist_ok=True)
            (bot_dir / fname).write_bytes(raw)
            name = safe_name(Path(fname).stem) + "_gh"
            doc = {
                "_id": bot_id, "owner": uid, "name": name,
                "dir": str(bot_dir), "created": ts_iso(),
                "enc_files": {}, "env": {}, "status": "stopped", "cron": {},
                "source": "github_browser", "gh_path": path, "entry": fname,
            }
            d = db_load()
            d["bots"][bot_id] = doc
            db_save(d)
            audit(uid, "gh_browser_run", f"path={path} bot_id={bot_id}")
            res = start_child(doc)
            bot.send_message(uid,
                f"<b>{'OK' if res.get('ok') else G['no']} \U0001f419 Run</b>\n"
                f"{bullet('File', fname)}\n"
                f"{bullet('Bot ID', bot_id)}\n"
                f"{bullet('Status', 'Started' if res.get('ok') else 'Error: ' + str(res.get('error', '')))}\n"
                f"{sc('Find it in My Bots')}.{FOOTER}", parse_mode="HTML")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                    f"<b>{G['no']} Run error</b>\n<code>{esc(e)}</code>", parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


# ─── Approval Group Settings ─────────────────────────────────────────────────

def render_adm_approval_group(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    grp_on = bool(get_setting("group_verify_enabled", False))
    groups = list(get_setting("required_groups", []) or [])
    rows = "\n".join(
        f"{G['bullet']} {esc(g.get('name','?'))} \u2014 "
        f"<code>{g.get('id','')}</code> "
        f"<a href='{g.get('link','#')}'>{sc('link')}</a>"
        for g in groups
    ) or f"<i>{sc('No groups configured')}</i>"
    cap = (
        f"<b>\U0001f510 {sc('Approval Group Verification')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status', 'ENABLED' if grp_on else 'DISABLED')}\n"
        f"{bullet('Groups', len(groups))}\n"
        f"{G['div']}\n"
        f"<b>{sc('Configured Groups')}:</b>\n{rows}\n"
        f"{G['div']}\n"
        f"{sc('Users must join all configured groups before accessing the bot')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{'OK' if grp_on else 'OFF'}  Verify", callback_data="adm_grpv_toggle",
            style="success" if grp_on else "danger"),
        Btn("+ Add Group", callback_data="adm_grpv_add", style="primary"),
    )
    kb.add(
        Btn("- Remove Group", callback_data="adm_grpv_remove", style="danger"),
        Btn("List Groups",    callback_data="adm_grpv_list",   style="primary"),
    )
    kb.add(
        Btn("Stats",          callback_data="adm_grpv_stats",  style="primary"),
        Btn(f"{G['back']}  Admin", callback_data="menu_admin", style="primary"),
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_grpv_stats(call: types.CallbackQuery) -> None:
    if not is_admin(call.from_user.id):
        ack(call, "Admin only"); return
    d = db_load()
    verified = sum(1 for u in d["users"].values() if u.get("verified"))
    total = len(d["users"])
    cap = (
        f"<b>\U0001f4ca {sc('Group Verification Stats')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total Users', total)}\n"
        f"{bullet('Verified', verified)}\n"
        f"{bullet('Unverified', total - verified)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("menu_admin"), call=call)


def render_adm_private_group_panel(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    pg = get_setting("private_approval_group", None)
    notify_admins_only = bool(get_setting("approval_notify_admins", True))
    cap = (
        f"<b>\U0001f512 {sc('Private Approval Group Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Approval Group', pg or '— not set —')}\n"
        f"{bullet('Notify Admins Only', 'YES' if notify_admins_only else 'NO')}\n"
        f"{G['div']}\n"
        f"{sc('Bot uploads are forwarded to this group for admin approval')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("Set Group",    callback_data="adm_apgrp_set",    style="primary"),
        Btn("Clear",        callback_data="adm_apgrp_clear",  style="danger"),
    )
    kb.add(
        Btn(f"Notify: {'Admins' if notify_admins_only else 'All'}", callback_data="adm_apgrp_toggle_notify", style="primary"),
        Btn("Test",         callback_data="adm_apgrp_test",   style="success"),
    )
    kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


# ─── Verification State (deferred declarations) ───────────────────────────────

VERIFY_STATES: Dict[int, Dict[str, Any]] = {}
_verify_lock = threading.Lock()
_CAPTCHA_POOL = "ABCDEFGHJKLMNPRSTUVWXYZ23456789"
_CAPTCHA_FONT_PATHS = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)
REQUIRED_GROUPS: List[Dict[str, Any]] = []


def _load_required_groups() -> None:
    global REQUIRED_GROUPS
    REQUIRED_GROUPS = list(get_setting("required_groups", []) or [])


def _captcha_font(size: int):
    if not _PIL_OK:
        return None
    for fp in _CAPTCHA_FONT_PATHS:
        try:
            if os.path.exists(fp):
                return ImageFont.truetype(fp, size)
        except Exception:
            continue
    try:
        return ImageFont.load_default()
    except Exception:
        return None


def _gen_captcha_image() -> Tuple[Optional[bytes], str, List[str]]:
    text = "".join(random.choice(_CAPTCHA_POOL) for _ in range(4))
    correct_idx = random.randrange(4)
    correct_ch = text[correct_idx]
    options = list(set(text))
    while len(options) < 6:
        c = random.choice(_CAPTCHA_POOL)
        if c not in options:
            options.append(c)
    random.shuffle(options)
    if not _PIL_OK:
        return None, correct_ch, options
    W, H = 720, 320
    bg = (15, 23, 42)
    img = Image.new("RGB", (W, H), bg)
    draw = ImageDraw.Draw(img)
    for _ in range(10):
        x1, y1 = random.randint(-50, W), random.randint(-50, H)
        x2, y2 = x1 + random.randint(150, 400), y1 + random.randint(-80, 80)
        draw.line([(x1, y1), (x2, y2)], fill=(40, 50, 70), width=random.randint(2, 4))
    for _ in range(450):
        x, y = random.randint(0, W - 1), random.randint(0, H - 1)
        v = random.randint(80, 200)
        draw.point((x, y), fill=(v, v, v))
    font = _captcha_font(140)
    char_centers: List[Tuple[int, int]] = []
    slot_w = W // 4
    palette = [(250, 204, 21), (96, 165, 250), (236, 72, 153), (52, 211, 153), (244, 114, 182), (251, 146, 60)]
    for i, ch in enumerate(text):
        tile = Image.new("RGBA", (200, 240), (0, 0, 0, 0))
        td = ImageDraw.Draw(tile)
        col = random.choice(palette)
        try:
            td.text((30, 30), ch, font=font, fill=col + (255,))
        except Exception:
            td.text((30, 30), ch, fill=col + (255,))
        tile = tile.rotate(random.randint(-22, 22), resample=Image.BILINEAR)
        cx = slot_w * i + slot_w // 2 - 100 + random.randint(-10, 10)
        cy = (H - 240) // 2 + random.randint(-15, 15)
        img.paste(tile, (cx, cy), tile)
        char_centers.append((cx + 100, cy + 120))
    cx, cy = char_centers[correct_idx]
    r = 90
    for dr in range(5):
        draw.ellipse([cx - r - dr, cy - r - dr, cx + r + dr, cy + r + dr], outline=(239, 68, 68))
    hint_font = _captcha_font(28)
    hint = "tap the circled character"
    try:
        bbox = draw.textbbox((0, 0), hint, font=hint_font)
        tw = bbox[2] - bbox[0]
    except Exception:
        tw = len(hint) * 10
    draw.rectangle([0, H - 44, W, H], fill=(30, 41, 59))
    try:
        draw.text(((W - tw) // 2, H - 38), hint, font=hint_font, fill=(226, 232, 240))
    except Exception:
        pass
    buf = io.BytesIO()
    img.save(buf, format="PNG", optimize=True)
    return buf.getvalue(), correct_ch, options


def _progress_bar_text(pct: int) -> str:
    pct = max(0, min(100, pct))
    filled = pct // 10
    bar = "\u25b0" * filled + "\u25b1" * (10 - filled)
    return (
        f"<b>{G['shield']} {sc('Verifying you')}\u2026</b>\n"
        f"{G['div']}\n"
        f"<b><code>[{bar}] {pct:3d}%</code></b>"
    )


def _send_captcha(chat_id: int, uid: int) -> None:
    png, correct, opts = _gen_captcha_image()
    kb = types.InlineKeyboardMarkup()
    btns = [Btn(c, callback_data=f"verify_{c}") for c in opts]
    for i in range(0, len(btns), 3):
        kb.row(*btns[i:i + 3])
    kb.row(Btn(f"\u21bb {sc('New captcha')}", callback_data="verify_new"))
    cap = (
        f"<b>{G['shield']} {sc('Human verification')}</b>\n"
        f"{G['div']}\n"
        f"{sc('One character has a red circle around it')}.\n"
        f"<b>{sc('Tap that exact character below')}.</b>{FOOTER}"
    )
    sent_id: Optional[int] = None
    try:
        if png is not None:
            m2 = bot.send_photo(chat_id, png, caption=cap, parse_mode="HTML", reply_markup=kb)
            sent_id = m2.message_id
        else:
            m2 = bot.send_message(chat_id,
                f"<b>{G['shield']}</b> Tap: <b><code>{esc(correct)}</code></b>",
                parse_mode="HTML", reply_markup=kb)
            sent_id = m2.message_id
    except Exception as e:
        print(f"[verify] send failed: {e}", flush=True)
        return
    with _verify_lock:
        prev = VERIFY_STATES.get(uid) or {}
        VERIFY_STATES[uid] = {
            "answer": correct, "options": opts, "msg_id": sent_id,
            "chat_id": chat_id, "tries": 0, "regens": int(prev.get("regens", 0)), "ts": time.time(),
        }


def _send_progress_then_captcha(chat_id: int, uid: int) -> None:
    msg_id: Optional[int] = None
    try:
        m2 = bot.send_message(chat_id, _progress_bar_text(10), parse_mode="HTML")
        msg_id = m2.message_id
    except Exception:
        pass
    for pct in (25, 45, 65, 85, 100):
        time.sleep(0.45)
        if msg_id is None:
            break
        try:
            bot.edit_message_text(_progress_bar_text(pct), chat_id, msg_id, parse_mode="HTML")
        except Exception:
            pass
    if msg_id is not None:
        try:
            bot.edit_message_text(
                f"<b>{G['shield']} {sc('Loading complete')}\u2026 {sc('solve captcha below')} \u2193</b>",
                chat_id, msg_id, parse_mode="HTML")
        except Exception:
            pass
    _send_captcha(chat_id, uid)


def _verify_state_janitor() -> None:
    while True:
        try:
            time.sleep(120)
            cutoff = time.time() - 600
            with _verify_lock:
                stale = [u for u, s in VERIFY_STATES.items() if s.get("ts", 0) < cutoff]
                for u in stale:
                    VERIFY_STATES.pop(u, None)
        except Exception as e:
            print(f"[verify] janitor error: {e}", flush=True)


def _check_group_membership(uid: int) -> List[Dict[str, Any]]:
    if not REQUIRED_GROUPS:
        return []
    not_joined = []
    for grp in REQUIRED_GROUPS:
        try:
            member = bot.get_chat_member(grp["id"], uid)
            if member.status in ("left", "kicked", "banned"):
                not_joined.append(grp)
        except Exception:
            not_joined.append(grp)
    return not_joined


def _send_join_verification(chat_id: int, uid: int, not_joined: List[Dict[str, Any]]) -> None:
    kb = types.InlineKeyboardMarkup(row_width=2)
    for grp in not_joined:
        kb.add(Btn(f"Join {grp['name']}", url=grp["link"]))
    kb.add(Btn("Verify Membership", callback_data="group_verify_check"))
    cap = (
        f"<b>{G['shield']} {sc('Group Join Required')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Join all groups below to use this bot')}:\n{G['div']}\n"
        + "\n".join(f"- <a href='{g['link']}'>{esc(g['name'])}</a>" for g in not_joined)
        + f"\n{G['div']}\n{sc('After joining, tap Verify Membership')}.{FOOTER}"
    )
    try:
        bot.send_message(chat_id, cap, parse_mode="HTML", reply_markup=kb,
                         disable_web_page_preview=True)
    except Exception as e:
        print(f"[group_verify] send failed: {e}", flush=True)


def _is_private(m) -> bool:
    try:
        return m.chat.type == "private"
    except Exception:
        return True


def _is_verified(uid: int) -> bool:
    if uid == OWNER_ID and OWNER_ID > 0:
        return True
    u = db_load_ro()["users"].get(str(uid)) or {}
    return bool(u.get("verified"))


def _mark_verified(uid: int) -> None:
    db = db_load()
    if str(uid) in db["users"]:
        db["users"][str(uid)]["verified"] = True
        db["users"][str(uid)]["verified_at"] = ts_iso()
        db_save(db)


def require_verified(chat_id: int, uid: int) -> bool:
    if _is_verified(uid):
        return True
    with _verify_lock:
        st = VERIFY_STATES.get(uid)
        now = time.time()
        if st and (st.get("msg_id") or now - st.get("ts", 0) < 6):
            return False
        VERIFY_STATES[uid] = {
            "answer": "", "options": [], "msg_id": None,
            "chat_id": chat_id, "tries": 0, "regens": 0, "ts": now, "starting": True,
        }
    threading.Thread(target=_send_progress_then_captcha, args=(chat_id, uid), daemon=True).start()
    return False


def require_group_membership(chat_id: int, uid: int) -> bool:
    if uid == OWNER_ID and OWNER_ID > 0:
        return True
    if is_admin(uid):
        return True
    if not bool(get_setting("group_verify_enabled", False)):
        return True
    not_joined = _check_group_membership(uid)
    if not not_joined:
        return True
    _send_join_verification(chat_id, uid, not_joined)
    return False


# ─── Main Menu ────────────────────────────────────────────────────────────────

def render_main_menu(chat_id: int, uid: int,
                     call: Optional[types.CallbackQuery] = None,
                     intro: Optional[str] = None) -> None:
    u = db_load()["users"].get(str(uid)) or {}
    plan = PLAN_LIMITS.get(u.get("plan", "free"), PLAN_LIMITS["free"])
    bots = list_user_bots(uid)
    running = sum(1 for b in bots if b["_id"] in RUNNING and RUNNING[b["_id"]]["proc"].poll() is None)
    intro_block = f"{intro}\n{G['div']}\n" if intro else ""
    custom_welcome = get_setting("custom_welcome", None)
    welcome_line = esc(custom_welcome) if custom_welcome else f"{sc('Welcome')}, <b>{esc(u.get('name') or 'friend')}</b>"
    cap = (
        f"<b>{esc(BRAND_TAG)}</b>\n"
        f"{G['div_eq']}\n"
        f"{intro_block}"
        f"{welcome_line}\n"
        f"{bullet('Plan', plan['name'])}\n"
        f"{bullet('Until', fmt_ts(u.get('plan_expires')) if u.get('plan_expires') else 'Forever' if plan['price'] == 0 else '—')}\n"
        f"{bullet('Bots', str(len(bots)) + ' / ' + str(user_max_bots(u)) + '  (running ' + str(running) + ')')}\n"
        f"{bullet('Wallet', money(u.get('wallet', 0)))}\n"
        f"{G['div']}\nChoose an option below.{FOOTER}"
    )
    show_menu(chat_id, PHOTOS["main"], cap, main_menu_kb(is_admin(uid)), call=call)


# ─── Render functions used by router ─────────────────────────────────────────

def render_bots_menu(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    bots = list_user_bots(uid)
    u = db_load()["users"][str(uid)]
    cap = (
        f"<b>{G['diamond']} {sc('Your Bots')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Slots', str(len(bots)) + ' / ' + str(user_max_bots(u)))}\n"
    )
    kb = types.InlineKeyboardMarkup()
    if not bots:
        cap += f"\n{sc('No bots yet. Tap Upload to begin')}."
    else:
        for b in sorted(bots, key=lambda x: x.get("name", "")):
            running = b["_id"] in RUNNING and RUNNING[b["_id"]]["proc"].poll() is None
            mark = G["play"] if running else G["stop"]
            src_mark = " \U0001f419" if b.get("source") in ("github", "github_browser") else ""
            kb.add(Btn(f"{mark}  {sc(b['name'])[:30]}{src_mark}",
                       callback_data=f"bot_view_{b['_id']}"))
    kb.add(
        Btn(f"{G['plus']}  {sc('Upload')}", callback_data="menu_upload", style="success"),
        Btn("\U0001f419  From GitHub",      callback_data="menu_gh_host", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["bots"], cap + FOOTER, kb, call=call)


def render_upload_menu(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"][str(uid)]
    used = len(list_user_bots(uid))
    rules = get_setting("hosting_rules", None)
    rules_block = f"\n{G['div']}\n<b>{sc('Hosting Rules')}:</b>\n{esc(rules)}" if rules else ""
    cap = (
        f"<b>{G['plus']} {sc('Upload Bot')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Plan', PLAN_LIMITS.get(u.get('plan','free'),PLAN_LIMITS['free'])['name'])}\n"
        f"{bullet('Slots', str(used) + ' / ' + str(user_max_bots(u)))}\n"
        f"{G['div']}\n"
        f"<b>{sc('Send your bot file as a document')}.</b>\n"
        f"Accepted: <code>.zip  .py  .js</code>\n"
        f"Entry detection: <code>bot.py main.py app.py index.js</code>\n"
        f"All files are <b>encrypted at rest</b>.{rules_block}"
    )
    USER_STATES[uid] = {"flow": "await_upload"}
    show_menu(call.message.chat.id, PHOTOS["upload"], cap + FOOTER, back_main_kb(), call=call)


def render_plans_menu(call: types.CallbackQuery) -> None:
    lines = []
    for key, v in PLAN_LIMITS.items():
        price_txt = money_or_free(v["price"])
        live_bots = int(get_setting(f"plan_max_bots_{key}", v["max_bots"]))
        detail = f"{live_bots} bots {G['bullet']} {v['ram']} MB RAM {G['bullet']} {price_txt}"
        lines.append(bullet(v["name"], detail))
    cap = (
        f"<b>{G['star']} {sc('Plans')}</b>\n"
        f"{G['div_eq']}\n"
        + "\n".join(lines)
        + f"\n{G['div']}\nTap a plan for full details.{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["plans"], cap, plans_kb(), call=call)


def render_plan_detail(call: types.CallbackQuery, plan: str) -> None:
    p = PLAN_LIMITS.get(plan)
    if not p:
        ack(call, "Unknown plan"); return
    live_bots = int(get_setting(f"plan_max_bots_{plan}", p["max_bots"]))
    cap = (
        f"<b>{G['star']} {esc(p['name'])} {sc('Plan')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Max bots', live_bots)}\n"
        f"{bullet('RAM per bot', '{} MB'.format(p['ram']))}\n"
        f"{bullet('Auto-restart', 'Yes' if p['auto_restart'] else 'No')}\n"
        f"{bullet('Duration', 'Lifetime' if plan == 'lifetime' else '{} days'.format(p['days']))}\n"
        f"{bullet('Price', money_or_free(p['price']))}\n"
        f"{bullet('GitHub hosting', 'Yes' if plan not in ('free',) else 'No')}\n"
        f"{G['div']}\n{sc('Tap buy to choose a payment method')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    if plan != "free":
        kb.add(Btn(f"{G['spark']}  {sc('Buy')} {p['name']}", callback_data=f"plan_buy_{plan}"))
    kb.add(Btn(f"{G['back']}  {sc('Plans')}", callback_data="menu_plans"))
    show_menu(call.message.chat.id, PHOTOS["buy"], cap, kb, call=call)


def render_buy_menu(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['spark']} {sc('Buy a Plan')}</b>\n"
        f"{G['div_eq']}\n{sc('Pick a plan first')}.{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["buy"], cap, plans_kb(), call=call)


def render_payment_methods_for(call: types.CallbackQuery, plan: str) -> None:
    p = PLAN_LIMITS.get(plan)
    if not p:
        ack(call, "Unknown plan"); return
    cap = (
        f"<b>{G['wallet']} {sc('Choose Payment Method')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Plan', p['name'])}\n"
        f"{bullet('Price', money(p['price']))}\n"
        f"{G['div']}\n{sc('Pick the method you will pay with')}.{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("pay", PHOTOS["wallet"]), cap, payments_kb(plan), call=call)


def render_payment_screen(call: types.CallbackQuery, data: str) -> None:
    parts = data.split("_")
    method = parts[1] if len(parts) > 1 else ""
    plan = parts[2] if len(parts) > 2 else None
    pm = PAYMENT_METHODS.get(method)
    if not pm or not bool(get_setting(f"pm_enabled_{method}", True)):
        ack(call, "Payment method unavailable")
        return

    p = PLAN_LIMITS.get(plan or "")
    amount = (p or {}).get("price", 0)
    configured = _payment_value(method)
    label = _payment_admin_label(method)

    cap = (
        f"<b>{pm['tag']} {esc(pm['name'])} — {sc('Payment')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet(label, esc(configured))}\n"
        f"{bullet('Type', esc(pm['type']))}\n"
    )
    if p:
        cap += f"{bullet('Plan', esc(p['name']))}\n{bullet('Amount', money(amount))}\n"

    qr_path = _upi_qr_path(method, plan, amount)
    if method in UPI_PAYMENT_KEYS:
        if qr_path:
            cap += f"{bullet('QR', 'Scan with any UPI app')}\n"
        else:
            cap += f"{G['no']} <b>{sc('UPI ID is not configured yet')}</b>\n"
        if method == "bharatpe":
            cap += f"{bullet('Verification', 'BharatPe Auto Verification')}\n"

    cap += (
        f"{G['div']}\n"
        f"<b>{sc('How to pay')}:</b>\n"
        f"1. {sc('Pay the exact amount shown above')}.\n"
        f"2. {sc('Tap Send Proof and send your receipt or transaction ID')}.\n"
        f"3. {sc('If auto-approval is enabled, a valid UTR can be verified automatically')}.\n"
        f"{G['div']}{FOOTER}"
    )

    USER_STATES[call.from_user.id] = {
        "flow": "await_payment_proof",
        "method": method,
        "plan": plan,
        "amount": amount,
        "payment_address": configured,
    }

    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{G['plus']}  {sc('Send Proof')}", callback_data="pay_proof"))
    kb.add(Btn(f"{G['back']}  {sc('Methods')}",
               callback_data=f"plan_buy_{plan}" if plan else "menu_buy"))

    # Send a real UPI QR when configured. If sending/editing fails, fall back
    # to the normal payment screen so the payment flow never gets stuck.
    if qr_path:
        try:
            if call.message and call.message.content_type == "photo":
                bot.edit_message_caption(
                    _html_safe_truncate(cap, 1024),
                    chat_id=call.message.chat.id,
                    message_id=call.message.message_id,
                    reply_markup=kb,
                    parse_mode="HTML",
                )
                bot.send_photo(
                    call.message.chat.id,
                    types.InputFile(qr_path),
                    caption=f"<b>{esc(pm['name'])} — UPI QR</b>\n{bullet('Amount', money(amount))}",
                    parse_mode="HTML",
                )
                return
            bot.send_photo(
                call.message.chat.id,
                types.InputFile(qr_path),
                caption=_html_safe_truncate(cap, 1024),
                parse_mode="HTML",
                reply_markup=kb,
            )
            return
        except Exception as e:
            _log_err("send_payment_qr", e)

    show_menu(
        call.message.chat.id,
        PHOTOS.get("pay", PHOTOS["wallet"]),
        cap,
        kb,
        call=call,
    )

def start_proof_flow(call: types.CallbackQuery) -> None:
    """Start proof collection without destroying the selected plan/payment state.

    The payment screen already stores method, plan and amount in USER_STATES.
    The old implementation replaced that state with only ``flow``, causing
    submitted proofs to be saved as plan=None/method=unknown/amount=0 and
    making admin approval fail.
    """
    uid = call.from_user.id
    state = dict(USER_STATES.get(uid) or {})

    # Only the proof-flow marker changes here; preserve the selected plan,
    # payment method, amount and payment address from render_payment_screen().
    if state.get("flow") != "await_payment_proof":
        state["flow"] = "await_payment_proof"
    USER_STATES[uid] = state

    if not state.get("plan") or state.get("plan") not in PLAN_LIMITS:
        bot.send_message(
            call.message.chat.id,
            f"{G['no']} {sc('Payment plan was not selected. Please choose a plan and payment method again.')}",
        )
        USER_STATES.pop(uid, None)
        return

    bot.send_message(
        call.message.chat.id,
        f"{G['plus']} {sc('Send your payment screenshot or transaction id now')}. /cancel {sc('to abort')}.",
    )


def render_profile(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"][str(uid)]
    p = PLAN_LIMITS.get(u.get("plan", "free"), PLAN_LIMITS["free"])
    bots = list_user_bots(uid)
    cap = (
        f"<b>{G['user']} {sc('Profile')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Name', u.get('name'))}\n"
        f"{bullet('Username', '@' + (u.get('username') or '—'))}\n"
        f"{bullet('User ID', uid)}\n"
        f"{bullet('Plan', p['name'])}\n"
        f"{bullet('Until', fmt_ts(u.get('plan_expires')) if u.get('plan_expires') else 'Forever' if p['price'] == 0 else '—')}\n"
        f"{bullet('Wallet', money(u.get('wallet', 0)))}\n"
        f"{bullet('Purchased', str(len(u.get('purchases', []))))}\n"
        f"{bullet('Bots', str(len(bots)) + ' / ' + str(user_max_bots(u)))}\n"
        f"{bullet('Joined', fmt_ts(u.get('joined')))}\n"
        f"{bullet('Referrals', u.get('ref_count', 0))}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("profile", PHOTOS["main"]), cap, back_main_kb(), call=call)


def render_referral(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"][str(uid)]
    try:
        me = bot.get_me()
        link = f"https://t.me/{me.username}?start={uid}"
    except Exception:
        link = f"https://t.me/YourBot?start={uid}"
    cap = (
        f"<b>{G['users']} {sc('Referral')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Your link', link)}\n"
        f"{bullet('Referrals', u.get('ref_count', 0))}\n"
        f"{bullet('Bonus slots', u.get('bot_slots_bonus', 0))}\n"
        f"{G['div']}\n"
        f"{sc('Each friend who joins via your link gives you +1 bot slot')}.\n{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("referral", PHOTOS["main"]), cap, back_main_kb(), call=call)


def render_wallet(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"][str(uid)]
    cap = (
        f"<b>{G['wallet']} {sc('Wallet')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Balance', money(u.get('wallet', 0)))}\n"
        f"{G['div']}\n"
        f"{sc('Top up by sending payment proof. Admin will credit your wallet')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{G['plus']}  {sc('Top Up')}", callback_data="wallet_topup"))
    if u.get("plan") not in ("free", None):
        kb.add(Btn(f"{G['spark']}  {sc('Gift Plan')}", callback_data="wallet_gift"))
    kb.add(Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main"))
    show_menu(call.message.chat.id, PHOTOS["wallet"], cap, kb, call=call)


def render_help(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['rec']} {sc('Help')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Upload', 'Send .py / .js / .zip')}\n"
        f"{bullet('GitHub', 'Host from GitHub repo (Pro+)')}\n"
        f"{bullet('Run', 'My Bots → pick → Start')}\n"
        f"{bullet('Logs', 'My Bots → pick → Live Logs')}\n"
        f"{bullet('Env', 'My Bots → pick → Env Vars')}\n"
        f"{bullet('Plans', 'Plans → Buy Plan → method')}\n"
        f"{bullet('Coupon', 'Coupon menu → Redeem')}\n"
        f"{bullet('Trial', 'One-time 48h Pro trial')}\n"
        f"{bullet('Tickets', 'Private support tickets')}\n"
        f"{G['div']}\nUpdates: {UPDATE_CH}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("help", PHOTOS["main"]), cap, back_main_kb(), call=call)


def render_support(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['broadcast']} {sc('Support')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('DM', SUPPORT_USR)}\n"
        f"{bullet('Channel', UPDATE_CH)}\n"
        f"{G['div']}\n"
        f"{sc('Or open a ticket from Tickets menu')}.{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS.get("support", PHOTOS["main"]), cap, back_main_kb(), call=call)


def render_trial(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    u = db_load()["users"][str(uid)]
    cap = (
        f"<b>{G['eye']} {sc('Free Trial')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Get a free 48-hour Pro trial — one time per account')}.\n"
        f"{bullet('Status', 'Already used' if u.get('trial_used') else 'Available')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    if not u.get("trial_used"):
        kb.add(Btn(f"{G['ok']}  {sc('Claim 48h Pro Trial')}", callback_data="trial_claim"))
    kb.add(Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main"))
    show_menu(call.message.chat.id, PHOTOS.get("trial", PHOTOS["main"]), cap, kb, call=call)


def action_trial_claim(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    d = db_load()
    u = d["users"][str(uid)]
    if u.get("trial_used"):
        ack(call, "Already used"); return
    u["trial_used"] = True
    db_save(d)
    grant_plan(uid, "pro", days=2)
    audit(0, "trial_grant", f"uid={uid}")
    ack(call, "Trial activated!")
    render_main_menu(call.message.chat.id, uid, call)


def render_coupon(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['key']} {sc('Coupon')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Have a discount code? Tap redeem and send the code')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{G['plus']}  {sc('Redeem Code')}", callback_data="coupon_redeem"))
    kb.add(Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main"))
    show_menu(call.message.chat.id, PHOTOS.get("coupon", PHOTOS["main"]), cap, kb, call=call)


def render_user_stats(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    d = db_load()
    u = d["users"][str(uid)]
    p = PLAN_LIMITS.get(u.get("plan", "free"), PLAN_LIMITS["free"])
    bots = list_user_bots(uid)
    running = sum(1 for b in bots if b["_id"] in RUNNING and RUNNING[b["_id"]]["proc"].poll() is None)
    pays = [x for x in d.get("payments", []) if x.get("uid") == uid and x.get("status") == "approved"]
    tickets = d.get("tickets", {})
    my_tickets = [t for t in tickets.values() if t.get("uid") == uid]
    plan_expires = u.get("plan_expires")
    expires_txt = fmt_ts(plan_expires) if plan_expires else ("Forever" if p["price"] == 0 else "\u2014")
    cap = (
        f"<b>{G['graph']} {sc('My Stats')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Name', u.get('name', '—'))}\n"
        f"{bullet('User ID', uid)}\n"
        f"{bullet('Plan', p['name'])}\n"
        f"{bullet('Expires', expires_txt)}\n"
        f"{bullet('RAM', str(p['ram']) + ' MB')}\n"
        f"{G['div']}\n"
        f"{bullet('Total Bots', len(bots))}\n"
        f"{bullet('Running', running)}\n"
        f"{bullet('Slots', str(len(bots)) + ' / ' + str(user_max_bots(u)))}\n"
        f"{G['div']}\n"
        f"{bullet('Payments', len(pays))}\n"
        f"{bullet('Wallet', money(u.get('wallet', 0)))}\n"
        f"{G['div']}\n"
        f"{bullet('Referrals', u.get('ref_count', 0))}\n"
        f"{bullet('Bonus Slots', u.get('bot_slots_bonus', 0))}\n"
        f"{bullet('Free Trial', 'Used' if u.get('trial_used') else 'Available')}\n"
        f"{bullet('Tickets', len(my_tickets))}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["stats"], cap, back_main_kb(), call=call)


def render_user_tickets(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    d = db_load()["tickets"]
    mine = [t for t in d.values() if t.get("uid") == uid][-10:]
    rows = "\n".join(
        f"{G['bullet']} <code>{t['id']}</code> {G['bullet']} {esc(t.get('status'))} {G['bullet']} {esc(t.get('subject', ''))[:40]}"
        for t in mine
    ) or f"<i>{sc('no tickets yet')}</i>"
    cap = (
        f"<b>{G['ticket']} {sc('Your Tickets')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    for t in mine:
        kb.add(Btn(f"#{t['id']} {esc(t.get('subject', ''))[:25]}", callback_data=f"ticket_view_{t['id']}"))
    kb.add(
        Btn(f"{G['plus']}  {sc('Open Ticket')}", callback_data="ticket_open"),
        Btn(f"{G['back']}  {sc('Main Menu')}", callback_data="menu_main"),
    )
    show_menu(call.message.chat.id, PHOTOS.get("ticket", PHOTOS["main"]), cap, kb, call=call)


def start_ticket_flow(call: types.CallbackQuery) -> None:
    USER_STATES[call.from_user.id] = {"flow": "await_ticket_subject"}
    bot.send_message(
        call.message.chat.id,
        f"{G['ticket']} {sc('Send the ticket subject (one line)')}.\n/cancel {sc('to abort')}.",
    )


def render_ticket_view(call: types.CallbackQuery, tid: str) -> None:
    d = db_load()["tickets"]
    t = d.get(tid)
    if not t:
        ack(call, "Not found"); return
    uid = call.from_user.id
    if t["uid"] != uid and not is_admin(uid):
        ack(call, "Not yours"); return
    msgs = t.get("messages", [])[-5:]
    rows = "\n".join(
        f"<b>{esc(x.get('from', '?'))}</b>: {esc(x.get('text', ''))[:200]}"
        for x in msgs
    ) or "(empty)"
    cap = (
        f"<b>{G['ticket']} {sc('Ticket')} #{tid}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Subject', t.get('subject', '—'))}\n"
        f"{bullet('Status', t.get('status', '—'))}\n"
        f"{G['div']}\n{rows}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['fwd']}  {sc('Reply')}", callback_data=f"ticket_reply_{tid}"),
        Btn(f"{G['no']}  {sc('Close')}", callback_data=f"ticket_close_{tid}"),
    )
    kb.add(Btn(f"{G['back']}  {sc('Tickets')}", callback_data="menu_tickets"))
    show_text(call.message.chat.id, cap, kb, call=call)


def action_ticket_close(call: types.CallbackQuery, tid: str) -> None:
    d = db_load()
    t = d["tickets"].get(tid)
    if not t:
        ack(call, "Not found"); return
    if t["uid"] != call.from_user.id and not is_admin(call.from_user.id):
        ack(call, "Not yours"); return
    t["status"] = "closed"
    db_save(d)
    audit(call.from_user.id, "ticket_close", f"tid={tid}")
    ack(call, "Ticket closed")
    render_user_tickets(call)


def start_ticket_reply(call: types.CallbackQuery, tid: str) -> None:
    USER_STATES[call.from_user.id] = {"flow": "await_ticket_reply", "tid": tid}
    bot.send_message(
        call.message.chat.id,
        f"{G['ticket']} #{tid} \u2014 {sc('send your reply text')}.\n/cancel {sc('to abort')}.",
    )
    ack(call)


def start_coupon_flow(call: types.CallbackQuery) -> None:
    USER_STATES[call.from_user.id] = {"flow": "await_coupon"}
    bot.send_message(call.message.chat.id,
        f"{G['key']} {sc('Send your coupon code')}. /cancel {sc('to abort')}.")


def start_wallet_topup(call: types.CallbackQuery) -> None:
    USER_STATES[call.from_user.id] = {"flow": "await_topup_proof"}
    bot.send_message(call.message.chat.id,
        f"{G['plus']} {sc('Send a screenshot of your top-up payment')}.\n"
        f"{sc('Include the amount in the caption e.g.')} <code>200</code>.", parse_mode="HTML")


def start_wallet_gift(call: types.CallbackQuery) -> None:
    USER_STATES[call.from_user.id] = {"flow": "await_gift_target"}
    bot.send_message(call.message.chat.id,
        f"{G['spark']} {sc('Send the user id of the person to gift your plan to')}.")


# ─── Bot view and actions ─────────────────────────────────────────────────────

def render_bot_view(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b:
        ack(call, "Not found"); return
    if b["owner"] != call.from_user.id and not is_admin(call.from_user.id):
        ack(call, "Not yours"); return
    st = child_status(bot_id, b)
    err_block = ""
    if not st["running"]:
        rc = b.get("last_exit_code")
        last_err = (b.get("last_error") or "").strip()
        if last_err or (rc not in (None, 0)):
            err_block = (
                f"\n{G['div']}\n<b>{G['no']} Last error"
                + (f" (exit {rc})" if rc not in (None, 0) else "") + "</b>\n"
                f"<pre>{esc(last_err or '(no log captured)')[:900]}</pre>"
            )
    appr = (b.get("approval_status") or "").lower()
    if appr == "pending":
        status_lbl = "\u23f3 Pending Approval"
    elif appr == "rejected":
        status_lbl = "\u274c Rejected"
    elif st["running"]:
        status_lbl = "\u25b6 Running"
    elif b.get("status") == "crashed":
        status_lbl = "\U0001f4a5 Crashed"
    else:
        status_lbl = "\u23f9 Stopped"
    src_info = ""
    if b.get("source") in ("github", "github_browser"):
        src_info = f"\n{bullet('Source', '🐙 GitHub')}\n{bullet('Repo', esc((b.get('gh_repo','?'))[:40]))}"
    cap = (
        f"<b>{G['diamond']} {esc(b['name'])}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status', status_lbl)}\n"
        f"{bullet('Kind', st['kind'] or '—')}\n"
        f"{bullet('Uptime', fmt_dur(st['uptimeMs']))}\n"
        f"{bullet('CPU', '{:.1f}%'.format(st['cpuPct']))}\n"
        f"{bullet('Memory', fmt_bytes(st['memBytes']))}\n"
        f"{bullet('Size', fmt_bytes(st['sizeBytes']))}\n"
        f"{bullet('Created', fmt_ts(b.get('created')))}"
        f"{src_info}"
        f"{err_block}\n"
        f"{G['div']}{FOOTER}"
    )
    owner_doc = db_load()["users"].get(str(b["owner"])) or {}
    is_premium = owner_doc.get("plan", "free") != "free" and user_plan_active(owner_doc)
    tun = TUNNELS.get(bot_id) if "TUNNELS" in globals() else None
    if tun and tun.get("proc") and tun["proc"].poll() is None and tun.get("url"):
        cap = cap[:-len(FOOTER)] + f"\n{bullet('Public URL', tun['url'])}" + FOOTER
    show_menu(call.message.chat.id, PHOTOS["bot"], cap,
              bot_actions_kb(bot_id, st["running"], premium=is_premium), call=call)


def action_bot_start(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found / not yours"); return
    loading(call, "Starting bot")
    res = start_child(b)
    ack(call, "Started" if res["ok"] else f"Err: {res.get('error')}")
    render_bot_view(call, bot_id)


def action_bot_stop(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found / not yours"); return
    loading(call, "Stopping bot")
    stop_child(bot_id, manual=True)
    ack(call, "Stopped")
    render_bot_view(call, bot_id)


def action_bot_restart(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found / not yours"); return
    loading(call, "Restarting bot")
    res = restart_child(b)
    ack(call, "Restarted" if res.get("ok") else f"Err: {res.get('error')}")
    render_bot_view(call, bot_id)


def action_bot_logs(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found"); return
    ack(call, "Fetching logs\u2026")
    logs = tail_log(bot_id, lines=60)
    if not logs:
        logs = "(no output yet)"
    cap = (
        f"<b>{G['eye']} {sc('Logs')}: {esc(b['name'])}</b>\n"
        f"{G['div_eq']}\n"
        f"<pre>{esc(logs[-3000:])}</pre>\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"\u21bb  {sc('Refresh')}", callback_data=f"bot_logs_{bot_id}"))
    kb.add(Btn(f"{G['back']}  {sc('Bot')}", callback_data=f"bot_view_{bot_id}"))
    show_text(call.message.chat.id, cap, kb, call=call)


def action_bot_info(call: types.CallbackQuery, bot_id: str) -> None:
    render_bot_view(call, bot_id)


def render_env_menu(call: types.CallbackQuery, bot_id: str, page: int = 0) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found"); return

    # Keep the UI within Telegram's message/button limits while allowing an
    # unlimited number of stored variables. Values are NEVER displayed.
    # Do not call save_bot() merely while rendering the ENV screen. Rendering
    # must be read-only; an old/stale bot document must never overwrite the
    # dedicated ENV sidecar. find_bot() merges the authoritative sidecar.
    env = _repair_env_dict(b.get("env") or {})
    keys = sorted(set(env.keys()) | set(b.get("env_keys") or []), key=str.upper)
    per_page = 12
    pages = max(1, (len(keys) + per_page - 1) // per_page)
    page = max(0, min(int(page or 0), pages - 1))
    visible = keys[page * per_page:(page + 1) * per_page]

    rows = "\n".join(
        f"{G['bullet']} <code>{esc(k)}</code> = <code>{'*' * min(len(str(env.get(k, ''))), 6)}…</code>"
        for k in visible
    ) or f"<i>{sc('No env vars set')}</i>"
    cap = (
        f"<b>{G['key']} {sc('Env Vars')}: {esc(b['name'])}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}\n"
        f"{sc('Variables')}: {len(keys)}  •  {sc('Page')}: {page + 1}/{pages}\n"
        f"{sc('Values are hidden and are never forwarded to admins/channels.')}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(Btn(f"{G['plus']}  {sc('Add / Edit Var')}", callback_data=f"env_add_{bot_id}"))
    # Use page/index in callback data instead of embedding the ENV key.
    # This keeps Telegram's 64-byte callback_data limit from breaking deletion
    # for long-but-valid variable names. The actual key is resolved from the
    # freshly loaded ENV dictionary when the button is pressed.
    for idx, k in enumerate(visible):
        kb.add(Btn(f"🗑️ {k[:35]}", callback_data=f"env_del_{bot_id}_{page}_{idx}"))
    nav = []
    if page > 0:
        nav.append(Btn("◀️", callback_data=f"env_page_{bot_id}_{page - 1}"))
    if page + 1 < pages:
        nav.append(Btn("▶️", callback_data=f"env_page_{bot_id}_{page + 1}"))
    if nav:
        kb.row(*nav)
    kb.add(Btn(f"{G['back']}  {sc('Bot')}", callback_data=f"bot_view_{bot_id}"))
    show_text(call.message.chat.id, cap, kb, call=call)


def start_env_add(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    USER_STATES[call.from_user.id] = {"flow": "await_env_kv", "bot_id": bot_id}
    bot.send_message(call.message.chat.id,
        f"{G['key']} {sc('Send env var in format')}: <code>KEY=VALUE</code>\n"
        f"{sc('Example')}: <code>BOT_TOKEN=123456:AAA...</code>\n/cancel {sc('to abort')}.",
        parse_mode="HTML")
    ack(call)


def _persist_bot_env(bot_id: str, env: Dict[str, Any]) -> bool:
    """Persist child ENV through the mutable DB path and verify the write.

    This deliberately does not rely on a read-only cached bot object.  ENV
    values are encrypted by db_save(), while env_keys is kept in sync for
    diagnostics/backup.  The post-write verification catches stale-cache or
    serialization regressions instead of reporting a false "saved" result.
    """
    clean = _repair_env_dict(env or {})
    with _db_lock:
        d = db_load()
        b = d.get("bots", {}).get(bot_id)
        if not b:
            return False
        b["env"] = clean
        b["env_keys"] = sorted(clean.keys(), key=str.upper)
        db_save(d)
        _write_env_sidecar(bot_id, clean)
    # Force a fresh read after the atomic write and compare keys only; values
    # remain secret and are never logged or sent anywhere.
    fresh = find_bot(bot_id)
    return bool(fresh is not None and set((fresh.get("env") or {}).keys()) == set(clean.keys()))


def action_env_delete(call: types.CallbackQuery, bot_id: str, key_or_page: str, idx: Optional[str] = None) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    env = _repair_env_dict(b.get("env") or {})
    key = key_or_page
    # New callback form: env_del_<bot_id>_<page>_<index>. Keep legacy direct-key
    # callbacks working for old messages.
    if idx is not None:
        try:
            page = max(0, int(key_or_page))
            pos = int(idx)
            keys = sorted(env.keys(), key=str.upper)
            key = keys[page * 12 + pos]
        except (ValueError, IndexError):
            ack(call, "Variable not found"); return
    if key not in env:
        ack(call, "Variable not found"); return
    env.pop(key, None)
    if not _persist_bot_env(bot_id, env):
        ack(call, "Save failed"); return
    audit(call.from_user.id, "env_del", f"bot={bot_id} key={key}")
    ack(call, f"Deleted {key}")
    render_env_menu(call, bot_id)


def render_cron(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    cron = b.get("cron", {})
    cap = (
        f"<b>{G['settings']} {sc('Cron / Auto Tasks')}: {esc(b['name'])}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Auto-restart hours', cron.get('restart_hours', '—'))}\n"
        f"{bullet('Auto-backup hours',  cron.get('backup_hours',  '—'))}\n"
        f"{G['div']}\n"
        f"Send: <code>restart_hours N</code> {sc('or')} <code>backup_hours N</code>\n"
        f"{sc('Set 0 to disable')}.\n/cancel {sc('to abort')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_cron", "bot_id": bot_id}
    show_text(call.message.chat.id, cap, _adm_back(f"bot_view_{bot_id}"), call=call)


def start_pip_install_flow(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    USER_STATES[call.from_user.id] = {"flow": "await_pip_install", "bot_id": bot_id}
    bot.send_message(call.message.chat.id,
        f"{G['plus']} {sc('Send package names space-separated')}:\n"
        f"<code>requests aiohttp python-dotenv</code>\n/cancel {sc('to abort')}.",
        parse_mode="HTML")
    ack(call)


def start_tunnel_flow(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    USER_STATES[call.from_user.id] = {"flow": "await_tunnel_port", "bot_id": bot_id}
    bot.send_message(call.message.chat.id,
        f"\U0001f310 {sc('Send the port your bot listens on (e.g. 8080) to start a tunnel')}.\n/cancel {sc('to abort')}.")
    ack(call)


def render_bot_delete_confirm(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    cap = (
        f"<b>{G['warn']} {sc('Confirm Delete')}</b>\n{G['div']}\n"
        f"{sc('Delete')} <b>{esc(b['name'])}</b>?\n"
        f"{sc('Keeps files but removes the bot record')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  Delete Record", callback_data=f"bot_delyes_{bot_id}", style="danger"),
        Btn(f"{G['no']}  Cancel",         callback_data=f"bot_view_{bot_id}",  style="primary"),
    )
    show_text(call.message.chat.id, cap, kb, call=call)


def action_bot_delete(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    # Tombstone first so a background worker cannot resurrect this bot while
    # the child process is being stopped.
    _mark_bot_deleted(bot_id)
    stop_child(bot_id, manual=True)
    delete_bot_doc(bot_id)
    audit(call.from_user.id, "bot_delete", f"bot={bot_id}")
    ack(call, "Deleted")
    render_bots_menu(call)


def render_bot_delfiles_confirm(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    cap = (
        f"<b>{G['warn']} {sc('Delete Files')}</b>\n{G['div']}\n"
        f"{sc('Delete files of')} <b>{esc(b['name'])}</b>?\n"
        f"{sc('Record stays but all uploaded files will be removed')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  Delete Files", callback_data=f"bot_delfilesyes_{bot_id}", style="danger"),
        Btn(f"{G['no']}  Cancel",        callback_data=f"bot_view_{bot_id}",       style="primary"),
    )
    show_text(call.message.chat.id, cap, kb, call=call)


def action_bot_delfiles(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    try:
        rmrf(b.get("dir", ""))
    except Exception:
        pass
    # Remove durable encrypted copies and keys too.  Keep the bot record itself.
    for f in list(b.get("enc_files") or []):
        try:
            _mongo_blob_delete(str(f.get("mongo_file_id") or ""))
            KEYRING.remove(str(f.get("key_id") or ""))
        except Exception:
            pass
    b["enc_files"] = []
    b["status"] = "stopped"
    save_bot(b)
    stop_child(bot_id, manual=True)
    audit(call.from_user.id, "bot_delfiles", f"bot={bot_id}")
    ack(call, "Files deleted")
    render_bot_view(call, bot_id)


def render_bot_delall_confirm(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    cap = (
        f"<b>{G['no']} {sc('Delete Everything')}</b>\n{G['div']}\n"
        f"{sc('Delete')} <b>{esc(b['name'])}</b> including all files and record?{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['no']}  Delete All", callback_data=f"bot_delalyes_{bot_id}", style="danger"),
        Btn(f"{G['ok']}  Cancel",     callback_data=f"bot_view_{bot_id}",     style="primary"),
    )
    show_text(call.message.chat.id, cap, kb, call=call)


def action_bot_delall(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    _mark_bot_deleted(bot_id)
    stop_child(bot_id, manual=True)
    try:
        rmrf(b.get("dir", ""))
    except Exception:
        pass
    delete_bot_doc(bot_id)
    audit(call.from_user.id, "bot_delall", f"bot={bot_id}")
    ack(call, "Deleted everything")
    render_bots_menu(call)


def action_bot_clone(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not yours"); return
    uid = call.from_user.id
    u = db_load()["users"].get(str(uid), {})
    if len(list_user_bots(uid)) >= user_max_bots(u):
        ack(call, "Bot slot limit reached"); return
    ack(call, "Cloning\u2026")
    new_id = secrets.token_hex(8)
    new_dir = DIRS["sandbox"] / f"{uid}_{new_id}"
    src_dir = Path(b.get("dir", ""))
    try:
        if src_dir.exists():
            shutil.copytree(str(src_dir), str(new_dir), dirs_exist_ok=True)
        else:
            new_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        new_dir.mkdir(parents=True, exist_ok=True)
    new_doc = dict(b)
    new_doc.update({
        "_id": new_id, "name": b["name"] + "_copy", "dir": str(new_dir),
        "created": ts_iso(), "status": "stopped",
    })
    new_doc.pop("last_started", None)
    d = db_load()
    d["bots"][new_id] = new_doc
    db_save(d)
    audit(uid, "bot_clone", f"src={bot_id} new={new_id}")
    bot.send_message(uid,
        f"<b>{G['ok']} {sc('Bot cloned')}</b>\n{bullet('New Bot ID', new_id)}\n{bullet('Name', new_doc['name'])}",
        parse_mode="HTML")
    render_bots_menu(call)


def action_bot_download(call: types.CallbackQuery, bot_id: str) -> None:
    b = find_bot(bot_id)
    if not b or (b["owner"] != call.from_user.id and not is_admin(call.from_user.id)):
        ack(call, "Not found"); return
    ack(call, "Packaging\u2026")
    def _bg() -> None:
        try:
            bot_dir = Path(b.get("dir", ""))
            # A redeployed panel may have lost its ephemeral sandbox. Rebuild
            # it from the durable encrypted source store before packaging.
            if not bot_dir.exists() or not any(bot_dir.rglob("*")):
                try:
                    materialize_bot_files(b)
                except Exception:
                    pass
            if not bot_dir.exists() or not any(bot_dir.rglob("*")):
                bot.send_message(call.from_user.id, f"{G['no']} No files to download."); return
            tmp = Path(tempfile.mktemp(suffix=f"_{b['name']}.zip"))
            with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
                for root, _, files in os.walk(bot_dir):
                    for fname in files:
                        fp = Path(root) / fname
                        zf.write(fp, arcname=fp.relative_to(bot_dir))
            sz = tmp.stat().st_size
            with tmp.open("rb") as fh:
                bot.send_document(call.from_user.id, fh,
                    caption=f"<b>\U0001f4e6 {esc(b['name'])}</b> ({fmt_bytes(sz)})",
                    parse_mode="HTML", visible_file_name=f"{b['name']}.zip")
            tmp.unlink(missing_ok=True)
            audit(call.from_user.id, "bot_download", f"bot={bot_id}")
        except Exception as e:
            try:
                bot.send_message(call.from_user.id,
                    f"{G['no']} Download error: <code>{esc(e)}</code>", parse_mode="HTML")
            except Exception:
                pass
    threading.Thread(target=_bg, daemon=True).start()


# ─── Admin panel ──────────────────────────────────────────────────────────────

def render_admin(call: types.CallbackQuery) -> None:
    if not admin_only_call(call, "view_stats"):
        return
    d = db_load()
    revenue = sum(p.get("amount", 0) for p in d["payments"] if p.get("status") == "approved")
    running_n = sum(1 for x in RUNNING.values() if x["proc"].poll() is None)
    pending_n = len(_pending_load())
    cap = (
        f"<b>{G['shield']} {sc('Admin Panel')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Users',   len(d['users']))}\n"
        f"{bullet('Bots',    len(d['bots']))}\n"
        f"{bullet('Running', running_n)}\n"
        f"{bullet('Revenue', money(revenue))}\n"
        f"{bullet('Pending', pending_n)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, admin_kb(), call=call)


# ─── Admin sub-panel renders ──────────────────────────────────────────────────

def render_adm_stats(call: types.CallbackQuery) -> None:
    d = db_load()
    revenue = sum(p.get("amount", 0) for p in d["payments"] if p.get("status") == "approved")
    today_str = now_utc().strftime("%Y-%m-%d")
    new_today = sum(1 for u in d["users"].values() if str(u.get("joined", "")).startswith(today_str))
    rss = 0
    if psutil is not None:
        try:
            rss = psutil.Process(os.getpid()).memory_info().rss
        except Exception:
            pass
    cap = (
        f"<b>{G['graph']} {sc('System Stats')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Total users', len(d['users']))}\n"
        f"{bullet('New today', new_today)}\n"
        f"{bullet('Total bots', len(d['bots']))}\n"
        f"{bullet('Running', sum(1 for x in RUNNING.values() if x['proc'].poll() is None))}\n"
        f"{bullet('Revenue', money(revenue))}\n"
        f"{bullet('Panel RAM', fmt_bytes(int(rss)))}\n"
        f"{bullet('Uptime', fmt_dur(int(time.time() * 1000) - START_TS))}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["stats"], cap, back_admin_kb(), call=call)


def render_adm_users(call: types.CallbackQuery) -> None:
    d = db_load()["users"]
    items = sorted(d.values(), key=lambda u: u.get("joined", ""), reverse=True)[:20]
    rows = "\n".join(
        f"{G['bullet']} <code>{u['_id']}</code> \u2014 {esc(u.get('name', ''))} "
        f"@{esc(u.get('username') or '—')} {G['bullet']} <i>{esc(PLAN_LIMITS.get(u.get('plan','free'),{}).get('name','?'))}</i>"
        for u in items
    ) or f"<i>{sc('no users yet')}</i>"
    cap = (
        f"<b>{G['users']} {sc('Recent Users')} ({len(d)} {sc('total')})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}\n"
        f"{sc('Send a numeric user id to look one up')}.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_admin_finduser"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_allbots(call: types.CallbackQuery) -> None:
    d = db_load()["bots"]
    items = list(d.values())[:25]
    rows = "\n".join(
        f"{G['bullet']} <code>{b['_id']}</code> \u2014 {esc(b['name'])} "
        f"{G['bullet']} uid {b['owner']} "
        f"{'&#x25B6;' if b['_id'] in RUNNING and RUNNING[b['_id']]['proc'].poll() is None else '&#x23F9;'}"
        f"{' 🐙' if b.get('source') in ('github','github_browser') else ''}"
        for b in items
    ) or f"<i>{sc('no bots')}</i>"
    cap = (
        f"<b>{G['diamond']} {sc('All Bots')} ({len(d)})</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_payments(call: types.CallbackQuery) -> None:
    d = db_load()
    pays = [p for p in d["payments"] if p.get("status") == "pending"][-15:]
    rows = "\n".join(
        f"{G['bullet']} <code>{p['id']}</code> {G['bullet']} uid {p['uid']} "
        f"{G['bullet']} {esc(p.get('plan', '—'))} {G['bullet']} {esc(p.get('method', ''))}"
        for p in pays
    ) or f"<i>{sc('no pending payments')}</i>"
    cap = (
        f"<b>{G['wallet']} {sc('Pending Payments')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_broadcast(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['broadcast']} {sc('Broadcast')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Send message text now')}.\n"
        f"Prefix <code>plan:pro</code> \u2014 only pro users.\n"
        f"Prefix <code>at:YYYY-MM-DD HH:MM</code> \u2014 schedule.{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_broadcast"}
    show_menu(call.message.chat.id, PHOTOS.get("broadcast", PHOTOS["admin"]), cap, back_admin_kb(), call=call)


def render_adm_ban(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['no']} {sc('Ban / Unban')}</b>\n"
        f"{G['div_eq']}\n"
        f"Send: <code>ban user_id reason</code>\n"
        f"Send: <code>unban user_id</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_ban_cmd"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_giveplan(call: types.CallbackQuery) -> None:
    cap = (
        f"<b>{G['plus']} {sc('Give Plan')}</b>\n"
        f"{G['div_eq']}\n"
        f"Send: <code>user_id plan [days]</code>\n"
        f"Plans: {', '.join(PLAN_LIMITS.keys())}{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_giveplan"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_approve(call: types.CallbackQuery) -> None:
    render_adm_payments(call)


def render_adm_coupons(call: types.CallbackQuery) -> None:
    d = db_load()["coupons"]
    rows = "\n".join(
        f"{G['bullet']} <code>{esc(code)}</code> \u2014 {esc(c.get('percent'))}% {G['bullet']} {esc(c.get('uses_left'))} uses"
        for code, c in d.items()
    ) or f"<i>{sc('no coupons yet')}</i>"
    cap = (
        f"<b>{G['key']} {sc('Coupons')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}\n"
        f"Send: <code>add CODE PERCENT USES</code>\n"
        f"Send: <code>del CODE</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_coupon_admin"}
    show_menu(call.message.chat.id, PHOTOS.get("coupon", PHOTOS["admin"]), cap, back_admin_kb(), call=call)


def render_adm_tickets(call: types.CallbackQuery) -> None:
    d = db_load()["tickets"]
    open_t = [t for t in d.values() if t.get("status") == "open"][-15:]
    rows = "\n".join(
        f"{G['bullet']} <code>{t['id']}</code> uid {t['uid']} \u2014 {esc(t.get('subject', ''))[:40]}"
        for t in open_t
    ) or f"<i>{sc('no open tickets')}</i>"
    cap = (
        f"<b>{G['ticket']} {sc('Open Tickets')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    for t in open_t:
        kb.add(Btn(f"{G['eye']}  #{t['id']}", callback_data=f"ticket_view_{t['id']}"))
    kb.add(Btn(f"{G['back']}  {sc('Admin')}", callback_data="menu_admin"))
    show_menu(call.message.chat.id, PHOTOS.get("ticket", PHOTOS["admin"]), cap, kb, call=call)


def render_adm_admins(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    d = db_load()["admins"]
    rows = "\n".join(
        f"{G['bullet']} <code>{uid}</code> \u2014 {esc(a.get('role'))}"
        for uid, a in d.items()
    ) or f"<i>{sc('no extra admins yet')}</i>"
    cap = (
        f"<b>{G['shield']} {sc('Admins')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}\n"
        f"Send: <code>add uid role</code>\n"
        f"Roles: <code>view-only</code>, <code>manage-users</code>, <code>full-access</code>\n"
        f"Send: <code>del uid</code>{FOOTER}"
    )
    USER_STATES[call.from_user.id] = {"flow": "await_admin_admins"}
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)


def render_adm_audit(call: types.CallbackQuery) -> None:
    d = db_load()["audit"][-25:]
    rows = "\n".join(
        f"{G['bullet']} {esc(a.get('ts', ''))[11:19]} uid {a['uid']} \u2192 {esc(a['action'])} {esc(a.get('detail', ''))[:60]}"
        for a in reversed(d)
    ) or f"<i>{sc('no audit entries yet')}</i>"
    cap = (
        f"<b>{G['eye']} {sc('Recent Audit')}</b>\n"
        f"{G['div_eq']}\n{rows}\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["security"], cap, back_admin_kb(), call=call)


def render_adm_pending(call: types.CallbackQuery) -> None:
    if not admin_only_call(call, "approve_payment"):
        return
    items = pending_list()
    if not items:
        cap = (
            f"<b>{G['eye']} {sc('Pending Uploads')}</b>\n"
            f"{G['div_eq']}\n<i>{sc('Inbox is empty')}.</i>\n{G['div']}{FOOTER}"
        )
        show_menu(call.message.chat.id, PHOTOS["admin"], cap, back_admin_kb(), call=call)
        return
    rows = []
    kb = types.InlineKeyboardMarkup(row_width=2)
    for bid, info in items[:15]:
        b = find_bot(bid)
        nm = (b or {}).get("name") or info.get("file_name") or bid
        rows.append(
            f"{G['bullet']} <code>{esc(bid)}</code> \u2014 {esc(nm)} "
            f"{G['bullet']} uid {info.get('user_id')} "
            f"{G['bullet']} {fmt_bytes(info.get('size', 0))}"
        )
        kb.add(
            Btn(f"{G['ok']}  OK {esc(nm)[:18]}", callback_data=f"appr_ok_{bid}"),
            Btn(f"{G['no']}  No {esc(nm)[:18]}", callback_data=f"appr_no_{bid}"),
        )
    kb.add(Btn(f"{G['back']}  {sc('Admin')}", callback_data="menu_admin"))
    cap = (
        f"<b>{G['eye']} {sc('Pending Uploads')} ({len(items)})</b>\n"
        f"{G['div_eq']}\n" + "\n".join(rows) + f"\n{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_photos(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id) and not admin_can(call.from_user.id, "manage_admins"):
        ack(call, "Owner / full-access only."); return
    cap = (
        f"<b>{G['upload']} {sc('Menu Photos')}</b>\n"
        f"{G['div_eq']}\n"
        f"{sc('Tap any menu below, then send a photo to replace its banner')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    for key, label in sorted(PHOTO_KEYS_FRIENDLY.items()):
        if key in _PHOTO_SPECS:
            kb.add(Btn(f"{G['cog']}  {sc(label)}", callback_data=f"adm_photo_{key}"))
    kb.add(Btn(f"{G['back']}  {sc('Admin')}", callback_data="menu_admin"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_security(call: types.CallbackQuery) -> None:
    d = db_load()
    scan_log = d.get("scan_log", [])
    blocked = sum(1 for s in scan_log if s.get("verdict") == "DANGEROUS")
    cap = (
        f"<b>{G['lock']} {sc('Security')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Scan log entries', len(scan_log))}\n"
        f"{bullet('Blocked uploads', blocked)}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("\U0001f6e1\ufe0f  Sec Center",       callback_data="adm_sec_center",    style="danger"),
        Btn(f"{G['eye']}  Scan Log",    callback_data="adm_security_log",  style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin"))
    show_menu(call.message.chat.id, PHOTOS["security"], cap, kb, call=call)


def render_adm_maintenance(call: types.CallbackQuery) -> None:
    if not is_owner(call.from_user.id):
        ack(call, "Owner only"); return
    on = bool(get_setting("maintenance", False))
    cap = (
        f"<b>{G['warn']} {sc('Maintenance Mode')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status', 'ON' if on else 'OFF')}\n"
        f"{G['div']}\n"
        f"{sc('When enabled, only admins can use the bot')}.{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{'Disable' if on else 'Enable'} Maintenance",
               callback_data="adm_maint_toggle",
               style="danger" if on else "success"))
    kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_settings(call: types.CallbackQuery) -> None:
    if not admin_only_call(call, "view_stats"):
        return
    on = bool(get_setting("maintenance", False))
    cap = (
        f"<b>{G['settings']} {sc('Settings')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Brand', BRAND_TAG)}\n"
        f"{bullet('Announce Ch', ANNOUNCE_CHANNEL or '—')}\n"
        f"{bullet('Maintenance', 'ON' if on else 'OFF')}\n"
        f"{bullet('TG Backup Ch', _tg_backup_channel() or '—')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("\u270f\ufe0f  Brand Name",      callback_data="adm_set_brand",       style="primary"),
        Btn("\U0001f4e3  Announce Ch",       callback_data="adm_set_announce",    style="primary"),
    )
    kb.add(
        Btn("\U0001f451  Transfer Owner",    callback_data="adm_set_owner",       style="danger"),
        Btn("\U0001f527  Maint Mode",        callback_data="adm_maint",           style="danger"),
    )
    kb.add(
        Btn("\U0001f504  Restart All Bots",  callback_data="adm_set_restart_all", style="success"),
        Btn("\U0001f534  Stop All Bots",     callback_data="adm_set_stop_all",    style="danger"),
    )
    kb.add(
        Btn("\U0001f9f9  Clean Orphans",     callback_data="adm_set_clean_orphans",style="primary"),
        Btn("\U0001f4e4  Export Data",       callback_data="adm_set_export",      style="primary"),
    )
    kb.add(
        Btn("\U0001f4e1  TG Ch Backup",      callback_data="adm_tg_backup",       style="primary"),
        Btn("\U0001f510  Approval Groups",   callback_data="adm_approval_group",  style="primary"),
    )
    kb.add(
        Btn("\U0001f512  Private Appr Grp",  callback_data="adm_private_group",   style="primary"),
        Btn("\U0001f4ca  Plan Editor",       callback_data="adm_set_plans",       style="primary"),
    )
    kb.add(
        Btn("\U0001f5a5\ufe0f  Sys Info",    callback_data="adm_set_sysinfo",     style="primary"),
        Btn("\U0001f504  Reload Caches",     callback_data="adm_set_reload",      style="success"),
    )
    kb.add(
        Btn("\u270f\ufe0f  Footer Text",     callback_data="adm_set_footer_text", style="primary"),
        Btn("\U0001f44b  Welcome Msg",       callback_data="adm_set_welcome_text",style="primary"),
    )
    kb.add(
        Btn("\U0001f4dc  Hosting Rules",     callback_data="adm_set_rules_text",  style="primary"),
        Btn("\U0001f5c4\ufe0f  DB Info",     callback_data="adm_db_info",         style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_github(call: types.CallbackQuery) -> None:
    if not admin_only_call(call, "view_stats"):
        return
    enabled = gh_enabled()
    auto = bool(get_setting("github_auto_enabled", True))
    repo = GH.get("repo", "\u2014")
    branch = GH.get("branch", "main")
    interval = GH.get("intervalMin", 360)
    cap = (
        f"<b>{G['cog']} {sc('GitHub Backup')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Status', 'Active' if enabled else 'Not Configured')}\n"
        f"{bullet('Repo', repo)}\n"
        f"{bullet('Branch', branch)}\n"
        f"{bullet('Interval', f'{interval}min')}\n"
        f"{bullet('Auto', 'ON' if auto else 'OFF')}\n"
        f"{G['div']}{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn("\U0001f511  Token",    callback_data="gh_set_token",   style="primary"),
        Btn("\U0001f4e6  Repo",     callback_data="gh_set_repo",    style="primary"),
    )
    kb.add(
        Btn("\U0001f33f  Branch",   callback_data="gh_set_branch",  style="primary"),
        Btn("\u23f1\ufe0f  Interval",callback_data="gh_set_interval",style="primary"),
    )
    kb.add(
        Btn(f"{'OK' if auto else 'OFF'}  Auto", callback_data="gh_toggle_auto",
            style="success" if auto else "danger"),
        Btn("\U0001f4be  Backup Now", callback_data="gh_backup_now", style="success"),
    )
    kb.add(
        Btn("\U0001f4e5  Restore",    callback_data="gh_restore_now", style="danger"),
        Btn("\U0001f419  Browse",     callback_data="adm_gh_browser", style="primary"),
    )
    kb.add(Btn(f"{G['back']}  Admin", callback_data="menu_admin", style="primary"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_sysinfo(call: types.CallbackQuery) -> None:
    import platform
    rss = vms = cpu_p = 0.0
    if psutil is not None:
        try:
            p = psutil.Process(os.getpid())
            mi = p.memory_info()
            rss, vms = mi.rss, mi.vms
            cpu_p = p.cpu_percent(interval=0.3)
        except Exception:
            pass
    up_secs = int(time.time() - START_TS / 1000)
    cap = (
        f"<b>\U0001f441\ufe0f {sc('System Info')}</b>\n"
        f"{G['div_eq']}\n"
        f"{bullet('Python', platform.python_version())}\n"
        f"{bullet('OS', platform.system() + ' ' + platform.release())}\n"
        f"{bullet('PID', os.getpid())}\n"
        f"{bullet('Uptime', fmt_dur(up_secs * 1000))}\n"
        f"{bullet('RAM RSS', fmt_bytes(int(rss)))}\n"
        f"{bullet('CPU', f'{cpu_p:.1f}%')}\n"
        f"{bullet('Brand', BRAND_TAG)}\n"
        f"{bullet('Owner ID', OWNER_ID)}\n"
        f"{G['div']}{FOOTER}"
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, _adm_back("adm_settings"), call=call)


def render_adm_plans(call: types.CallbackQuery) -> None:
    rows = []
    for k, v in PLAN_LIMITS.items():
        live = int(get_setting(f"plan_max_bots_{k}", v["max_bots"]))
        rows.append(f"{bullet(v['name'], f'max_bots = {live}')}")
    cap = (
        f"<b>{G['diamond']} {sc('Plans Editor')}</b>\n"
        f"{G['div_eq']}\n"
        + "\n".join(rows) + "\n"
        f"{G['div']}\n"
        f"<i>{sc('Adjust bot quotas per plan')}.</i>{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=3)
    for k, v in PLAN_LIMITS.items():
        live = int(get_setting(f"plan_max_bots_{k}", v["max_bots"]))
        kb.add(
            Btn(f"\u2796 {sc(v['name'])}", callback_data=f"adm_set_plan_dec_{k}"),
            Btn(str(live),                  callback_data=f"adm_set_plan_show_{k}"),
            Btn(f"\u2795 {sc(v['name'])}", callback_data=f"adm_set_plan_inc_{k}"),
        )
    kb.add(Btn("\u21ba  Reset Defaults", callback_data="adm_set_plans_reset"))
    kb.add(Btn(f"{G['back']}  Settings", callback_data="adm_settings"))
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_confirm(call: types.CallbackQuery, action: str, label: str) -> None:
    cap = (
        f"<b>{G['warn']} {sc('Confirm')}</b>\n{G['div_eq']}\n"
        f"{sc('About to')}: <b>{esc(label)}</b>.\n{sc('Continue')}?{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  Yes, do it",   callback_data=f"{action}_yes", style="danger"),
        Btn(f"{G['no']}  Cancel",        callback_data="adm_settings",  style="primary"),
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


def render_adm_confirm_custom(call: types.CallbackQuery, action: str,
                               label: str, back_cb: str = "menu_admin") -> None:
    cap = (
        f"<b>{G['warn']} {sc('Confirm')}</b>\n{G['div_eq']}\n"
        f"{sc('About to')}: <b>{esc(label)}</b>. {sc('Are you sure')}?{FOOTER}"
    )
    kb = types.InlineKeyboardMarkup(row_width=2)
    kb.add(
        Btn(f"{G['ok']}  Yes", callback_data=action,  style="danger"),
        Btn(f"{G['no']}  No",  callback_data=back_cb, style="primary"),
    )
    show_menu(call.message.chat.id, PHOTOS["admin"], cap, kb, call=call)


# ─── Payment handlers ─────────────────────────────────────────────────────────

def _activate_plan_payment(d: Dict[str, Any], pay: Dict[str, Any], actor_id: int = 0) -> Tuple[bool, str]:
    """Atomically activate a paid plan and record its purchase.

    The payment id is the idempotency key: a retry/callback for an already
    completed payment never grants the plan twice.  This function also makes
    lifetime plans truly non-expiring.
    """
    uid = int(pay.get("uid") or 0)
    plan = str(pay.get("plan") or "")
    payment_id = str(pay.get("id") or "")
    if not uid or plan not in PLAN_LIMITS or not payment_id:
        return False, "Invalid payment/plan."
    if str(pay.get("status")) == "approved":
        return True, "Already approved."

    u = d.setdefault("users", {}).get(str(uid))
    if not u:
        return False, "User account not found."

    now = now_utc()
    pl = PLAN_LIMITS[plan]
    if plan == "lifetime":
        u["plan"] = "lifetime"
        u["plan_expires"] = None
        u["last_expiry_warn"] = -1
    else:
        days = int(pl.get("days", 30) or 30)
        old_plan = str(u.get("plan", "free") or "free")
        expires = u.get("plan_expires")
        try:
            cur_exp = datetime.fromisoformat(str(expires or "").replace("Z", "+00:00"))
        except Exception:
            cur_exp = now
        if cur_exp.tzinfo is None:
            cur_exp = cur_exp.replace(tzinfo=timezone.utc)
        if old_plan != plan or cur_exp <= now:
            cur_exp = now
        u["plan"] = plan
        u["plan_expires"] = (cur_exp + timedelta(days=days)).isoformat()
        u["last_expiry_warn"] = -1

    # Permanent purchase history, keyed by payment id.
    purchases = u.setdefault("purchases", [])
    if not any(str(x.get("payment_id")) == payment_id for x in purchases):
        purchases.append({
            "payment_id": payment_id,
            "plan": plan,
            "plan_name": pl.get("name", plan),
            "amount": float(pay.get("amount", 0) or 0),
            "method": pay.get("method"),
            "purchased_at": ts_iso(),
            "approved_at": ts_iso(),
            "approved_by": int(actor_id or 0),
            "status": "completed",
        })
        if len(purchases) > 100:
            u["purchases"] = purchases[-100:]

    pay["status"] = "approved"
    pay["approved_by"] = int(actor_id or 0)
    pay["approved_at"] = ts_iso()
    pay["updated"] = ts_iso()
    d["payments"] = d.get("payments", [])
    db_save(d)
    return True, "Activated."

def _finish_loading(call: Optional[types.CallbackQuery], label: str = "Completed") -> None:
    """Stop the animated loader and show its terminal 100% frame."""
    if not call or not call.message:
        return
    chat_id = call.message.chat.id
    msg_id = call.message.message_id
    # Stop first so the animation thread cannot overwrite the 100% frame.
    _cancel_loading(chat_id, msg_id)
    body = (
        f"<b>✓ {esc(label)}…</b>\n"
        f"{G['div']}\n"
        f"<code>{_progress_bar(100)}</code>\n"
        f"<i>{sc('Complete')}</i>{FOOTER}"
    )
    try:
        if call.message.content_type == "photo":
            bot.edit_message_caption(body, chat_id=chat_id, message_id=msg_id, parse_mode="HTML")
        else:
            bot.edit_message_text(body, chat_id=chat_id, message_id=msg_id, parse_mode="HTML", disable_web_page_preview=True)
    except Exception:
        pass

def action_payment_approve(call: types.CallbackQuery, pid: str) -> None:
    if not admin_only_call(call, "approve_payment"):
        return
    d = db_load()
    pay = next((x for x in d["payments"] if x.get("id") == pid), None)
    if not pay:
        ack(call, "Not found")
        return
    if pay.get("status") in ("approved", "rejected"):
        ack(call, f"Already {pay['status']}.")
        return

    loading(call, "Approving payment")
    try:
        if pay.get("kind") == "wallet_topup":
            u = d["users"].get(str(pay["uid"]))
            if not u:
                raise RuntimeError("User account not found")
            # 92% → 100% is the approval-complete transition. Only after the
            # terminal 100% frame is shown do we credit the user's wallet.
            _finish_loading(call, "Payment approved")
            time.sleep(0.7)
            u["wallet"] = round(float(u.get("wallet", 0)) + float(pay.get("amount", 0)), 2)
            pay["status"] = "approved"
            pay["approved_by"] = call.from_user.id
            pay["approved_at"] = ts_iso()
            pay["updated"] = ts_iso()
            db_save(d)
            try:
                bot.send_message(pay["uid"],
                    f"<b>{G['ok']} {sc('Wallet credited')}</b>\n"
                    f"{bullet('Amount', money(pay['amount']))}", parse_mode="HTML")
            except Exception:
                pass
        elif pay.get("plan"):
            uid = int(pay.get("uid") or 0)
            plan = str(pay.get("plan") or "")
            if not uid or plan not in PLAN_LIMITS or not d["users"].get(str(uid)):
                raise RuntimeError("Invalid payment/plan/user")

            # First finish the visible approval progress at 100%.
            _finish_loading(call, "Payment approved")
            time.sleep(0.7)

            # Only after 100% do we activate the plan and persist the purchase.
            ok, msg = _activate_plan_payment(d, pay, call.from_user.id)
            if not ok:
                raise RuntimeError(msg)
            u = db_load()["users"].get(str(uid), {})
            try:
                p = PLAN_LIMITS[plan]
                bot.send_message(
                    uid,
                    f"<b>{G['ok']} {sc('Plan activated')}</b>\n"
                    f"{bullet('Plan', p['name'])}\n"
                    f"{bullet('Bots', user_max_bots(u))}\n"
                    f"{bullet('RAM', str(p['ram']) + ' MB')}\n"
                    f"{bullet('Auto-restart', 'Yes' if p['auto_restart'] else 'No')}\n"
                    f"{bullet('Until', fmt_ts(u.get('plan_expires')) if u.get('plan_expires') else 'Lifetime')}\n"
                    f"{sc('Purchase saved to your account history.')}",
                    parse_mode="HTML",
                )
            except Exception:
                pass
        else:
            raise RuntimeError("Payment has no wallet/plan target")

        audit(call.from_user.id, "pay_approve", f"pid={pid}")
        ack(call, "Approved")
        # Keep the 100% terminal frame visible instead of immediately replacing
        # it with another message.
    except Exception as exc:
        _log_err("payment_approve", exc)
        # If plan activation failed, the payment remains pending.
        try:
            d2 = db_load()
            p2 = next((x for x in d2.get("payments", []) if x.get("id") == pid), None)
            if p2 and p2.get("status") == "approved" and p2.get("plan"):
                p2["status"] = "pending"
                p2.pop("approved_by", None)
                p2.pop("approved_at", None)
                db_save(d2)
        except Exception:
            pass
        _cancel_loading(call.message.chat.id, call.message.message_id)
        ack(call, "Approval failed")
        try:
            bot.edit_message_text(
                f"<b>{G['no']} Approval failed #{pid}</b>",
                chat_id=call.message.chat.id,
                message_id=call.message.message_id,
                parse_mode="HTML",
            )
        except Exception:
            pass
    finally:
        _cancel_loading(call.message.chat.id, call.message.message_id)

def action_payment_reject(call: types.CallbackQuery, pid: str) -> None:
    if not admin_only_call(call, "approve_payment"):
        return
    d = db_load()
    pay = next((x for x in d["payments"] if x.get("id") == pid), None)
    if not pay:
        ack(call, "Not found"); return
    if pay.get("status") in ("approved", "rejected"):
        ack(call, f"Already {pay['status']}."); return
    loading(call, "Rejecting payment")
    pay["status"] = "rejected"
    pay["rejected_by"] = call.from_user.id
    pay["rejected_at"] = ts_iso()
    db_save(d)
    audit(call.from_user.id, "pay_reject", f"pid={pid}")
    try:
        bot.send_message(pay["uid"],
            f"<b>{G['no']} {sc('Payment rejected')}</b> #{pid}\n{sc('Contact')} {SUPPORT_USR}",
            parse_mode="HTML")
    except Exception:
        pass
    ack(call, "Rejected")
    try:
        bot.edit_message_text(f"<b>{G['no']} {sc('Rejected')} #{pid}</b>",
                              chat_id=call.message.chat.id,
                              message_id=call.message.message_id, parse_mode="HTML")
    except Exception:
        pass
    finally:
        # Always stop the progress animation on rejection too.
        if call and call.message:
            _cancel_loading(call.message.chat.id, call.message.message_id)


# ─── Admin subroute dispatcher ────────────────────────────────────────────────

def render_admin_subroute(call: types.CallbackQuery, data: str) -> None:
    uid = call.from_user.id

    if data == "adm_stats":              return render_adm_stats(call)
    if data == "adm_users":              return render_adm_users(call)
    if data == "adm_allbots":            return render_adm_allbots(call)
    if data == "adm_payments":           return render_adm_payments(call)
    if data == "adm_broadcast":          return render_adm_broadcast(call)
    if data == "adm_ban":                return render_adm_ban(call)
    if data == "adm_giveplan":           return render_adm_giveplan(call)
    if data == "adm_approve":            return render_adm_approve(call)
    if data == "adm_coupons":            return render_adm_coupons(call)
    if data == "adm_tickets":            return render_adm_tickets(call)
    if data == "adm_admins":             return render_adm_admins(call)
    if data == "adm_audit":              return render_adm_audit(call)
    if data == "adm_github":             return render_adm_github(call)
    if data == "adm_security":           return render_adm_security(call)
    if data == "adm_maint":              return render_adm_maintenance(call)
    if data == "adm_settings":           return render_adm_settings(call)
    if data == "adm_pending":            return render_adm_pending(call)
    if data == "adm_photos":             return render_adm_photos(call)
    if data == "adm_tg_backup":          return render_adm_tg_channel_backup(call)
    if data == "adm_gh_browser":         return render_adm_gh_browser(call)
    if data == "adm_approval_group":     return render_adm_approval_group(call)
    if data == "adm_private_group":      return render_adm_private_group_panel(call)

    # GitHub browser callbacks
    if data.startswith("ghbrow_dir_"):
        _render_gh_dir(call, data[len("ghbrow_dir_"):]); return
    if data.startswith("ghbrow_file_"):
        _render_gh_file(call, data[len("ghbrow_file_"):]); return
    if data.startswith("ghbrow_dl_"):
        _action_gh_file_download(call, data[len("ghbrow_dl_"):]); return
    if data.startswith("ghbrow_run_"):
        _action_gh_file_run(call, data[len("ghbrow_run_"):]); return

    # TG channel backup callbacks
    if data == "adm_tg_bkp_now":
        ack(call, "Backing up to channel\u2026")
        def _tg_bkp():
            res = tg_channel_backup_now()
            try:
                bot.send_message(uid,
                    f"<b>{'OK' if res.get('ok') else G['no']} {sc('TG Channel Backup')}</b>\n"
                    f"{bullet('Size', fmt_bytes(res.get('size', 0)))}\n"
                    f"{bullet('Error', res.get('error', '') or 'none')}",
                    parse_mode="HTML")
            except Exception:
                pass
        threading.Thread(target=_tg_bkp, daemon=True).start(); return
    if data == "adm_tg_bkp_set_ch":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_tg_backup_channel"}
        bot.send_message(call.message.chat.id,
            f"\U0001f4e1 {sc('Send the channel handle or numeric ID (add bot as admin first)')}.\n"
            f"<code>@MyChannel</code> or <code>-1001234567890</code>", parse_mode="HTML"); return
    if data == "adm_tg_bkp_toggle_auto":
        if not is_owner(uid): ack(call, "Owner only"); return
        cur = bool(get_setting("tg_backup_auto", False))
        set_setting("tg_backup_auto", not cur)
        ack(call, f"Auto TG backup: {'ON' if not cur else 'OFF'}")
        return render_adm_tg_channel_backup(call)
    if data == "adm_tg_bkp_restore":
        ack(call, "See latest zip in channel")
        bot.send_message(uid, f"\U0001f4e5 {sc('Download the latest backup zip from your channel and upload it manually to restore')}."); return

    # Approval group callbacks
    if data == "adm_grpv_toggle":
        if not is_owner(uid): ack(call, "Owner only"); return
        cur = bool(get_setting("group_verify_enabled", False))
        set_setting("group_verify_enabled", not cur)
        _load_required_groups()
        ack(call, f"Group verify: {'ON' if not cur else 'OFF'}")
        return render_adm_approval_group(call)
    if data == "adm_grpv_add":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_adm_grpv_add"}
        bot.send_message(call.message.chat.id,
            f"\U0001f510 {sc('Send group info')}:\n"
            f"<code>NAME|GROUP_ID|INVITE_LINK</code>", parse_mode="HTML"); return
    if data == "adm_grpv_remove":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_adm_grpv_remove"}
        grps = get_setting("required_groups", []) or []
        names = "\n".join(f"{i+1}. {g['name']}" for i, g in enumerate(grps))
        bot.send_message(call.message.chat.id,
            f"\U0001f510 {sc('Send the number to remove')}:\n{names or 'none'}"); return
    if data == "adm_grpv_list":
        grps = get_setting("required_groups", []) or []
        rows = "\n".join(f"{i+1}. {g['name']} ({g.get('id','')})" for i, g in enumerate(grps)) or "none"
        bot.send_message(uid, f"\U0001f510 Groups:\n{rows}"); return
    if data == "adm_grpv_stats":
        return render_adm_grpv_stats(call)

    # Private approval group callbacks
    if data == "adm_apgrp_set":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_adm_private_apgrp"}
        bot.send_message(call.message.chat.id,
            f"\U0001f512 {sc('Send the private approval group/channel ID or handle')}."); return
    if data == "adm_apgrp_clear":
        if not is_owner(uid): ack(call, "Owner only"); return
        set_setting("private_approval_group", None)
        ack(call, "Approval group cleared")
        return render_adm_private_group_panel(call)
    if data == "adm_apgrp_toggle_notify":
        if not is_owner(uid): ack(call, "Owner only"); return
        cur = bool(get_setting("approval_notify_admins", True))
        set_setting("approval_notify_admins", not cur)
        ack(call, f"Notify: {'Admins only' if not cur else 'All'}")
        return render_adm_private_group_panel(call)
    if data == "adm_apgrp_test":
        pg = get_setting("private_approval_group", None)
        if not pg: ack(call, "No group configured"); return
        ack(call, "Testing\u2026")
        try:
            bot.send_message(pg,
                f"<b>\U0001f512 {sc('Test message from')} {BRAND_TAG}</b>\n"
                f"{sc('Approval group is configured correctly!')}",
                parse_mode="HTML")
            ack(call, "Test sent!")
        except Exception as e:
            ack(call, f"Failed: {e}")
        return

    # Maintenance toggle
    if data == "adm_maint_toggle":
        if not is_owner(uid): ack(call, "Owner only"); return
        cur = bool(get_setting("maintenance", False))
        set_setting("maintenance", not cur)
        audit(uid, "maintenance_toggle", f"now={'on' if not cur else 'off'}")
        ack(call, f"Maintenance: {'ON' if not cur else 'OFF'}")
        return render_adm_maintenance(call)

    # Settings sub-routes
    if data == "adm_set_sysinfo":        return render_adm_sysinfo(call)
    if data == "adm_set_plans":          return render_adm_plans(call)
    if data == "adm_set_plans_reset":
        if not is_owner(uid): ack(call, "Owner only"); return
        s = settings_load()
        for k in list(s.keys()):
            if k.startswith("plan_max_bots_"):
                s.pop(k, None)
        settings_save(s)
        audit(uid, "plans_reset", "")
        ack(call, "Plans reset to defaults")
        return render_adm_plans(call)
    if data.startswith("adm_set_plan_show_"):
        ack(call, "Use +/- to adjust"); return
    if data.startswith("adm_set_plan_inc_") or data.startswith("adm_set_plan_dec_"):
        if not is_owner(uid): ack(call, "Owner only"); return
        inc = data.startswith("adm_set_plan_inc_")
        key = data.split("_")[-1]
        if key not in PLAN_LIMITS: ack(call, "Unknown plan"); return
        cur_val = int(get_setting(f"plan_max_bots_{key}", PLAN_LIMITS[key]["max_bots"]))
        cur_val = max(1, cur_val + (1 if inc else -1))
        set_setting(f"plan_max_bots_{key}", cur_val)
        audit(uid, "plan_edit", f"{key} max_bots={cur_val}")
        ack(call, f"{PLAN_LIMITS[key]['name']}: {cur_val}")
        return render_adm_plans(call)
    if data == "adm_set_reload":
        cache_clear_all()
        audit(uid, "reload_caches", "")
        ack(call, "Caches dropped")
        return render_adm_settings(call)
    if data in ("adm_set_brand", "adm_set_announce", "adm_set_owner",
                "adm_set_footer_text", "adm_set_welcome_text", "adm_set_rules_text"):
        if not is_owner(uid): ack(call, "Owner only"); return
        prompts = {
            "adm_set_brand":        f"\u270f\ufe0f {sc('Send the new brand tag')}:",
            "adm_set_announce":     f"\U0001f4e3 {sc('Send the announce channel handle')} (<code>@ch</code> or <code>-</code>):",
            "adm_set_owner":        f"\U0001f451 {sc('Send the new owner numeric Telegram ID')}. <i>{sc('You will lose owner rights')}.</i>",
            "adm_set_footer_text":  f"\u270f\ufe0f {sc('Send new footer text')} (or <code>-</code> to reset):",
            "adm_set_welcome_text": f"\U0001f44b {sc('Send new welcome message')}:",
            "adm_set_rules_text":   f"\U0001f4dc {sc('Send new hosting rules text')}:",
        }
        flows = {
            "adm_set_brand": "await_set_brand",
            "adm_set_announce": "await_set_announce",
            "adm_set_owner": "await_set_owner",
            "adm_set_footer_text": "await_set_footer",
            "adm_set_welcome_text": "await_set_welcome",
            "adm_set_rules_text": "await_set_rules",
        }
        USER_STATES[uid] = {"flow": flows[data]}
        bot.send_message(call.message.chat.id, prompts[data], parse_mode="HTML"); return
    if data == "adm_set_restart_all":
        return render_adm_confirm(call, "adm_set_restart_all", "Restart all running bots")
    if data == "adm_set_restart_all_yes":
        if not is_owner(uid): ack(call, "Owner only"); return
        ack(call, "Restarting\u2026")
        def _rb():
            ok = fail = 0
            for bid in list(RUNNING.keys()):
                b = find_bot(bid)
                if not b: continue
                try:
                    r = restart_child(b)
                    if r.get("ok"): ok += 1
                    else: fail += 1
                except Exception: fail += 1
            audit(uid, "restart_all_bots", f"ok={ok} fail={fail}")
            try: bot.send_message(uid, f"{G['ok']} Restart-all done: {ok} ok, {fail} fail.")
            except Exception: pass
        threading.Thread(target=_rb, daemon=True).start(); return
    if data == "adm_set_stop_all":
        return render_adm_confirm(call, "adm_set_stop_all", "Stop every running bot")
    if data == "adm_set_stop_all_yes":
        if not is_owner(uid): ack(call, "Owner only"); return
        ack(call, "Stopping\u2026")
        def _sb():
            n = 0
            for bid in list(RUNNING.keys()):
                try: stop_child(bid, manual=True); n += 1
                except Exception: pass
            audit(uid, "stop_all_bots", f"stopped={n}")
            try: bot.send_message(uid, f"{G['ok']} Stopped {n} bot(s).")
            except Exception: pass
        threading.Thread(target=_sb, daemon=True).start(); return
    if data == "adm_set_clean_orphans":
        if not is_admin(uid): ack(call, "No permission"); return
        ack(call, "Scanning\u2026")
        def _co():
            valid_ids = set(db_load()["bots"].keys())
            valid_keys = {f"{b.get('owner')}_{b['_id']}" for b in db_load()["bots"].values()}
            dirs = files = 0
            sx = BASE_DIR / "sandbox"
            if sx.exists():
                for e in sx.iterdir():
                    if e.is_dir() and e.name not in valid_keys:
                        try: shutil.rmtree(e, ignore_errors=True); dirs += 1
                        except Exception: pass
            bd = BASE_DIR / "storage" / "bot_data"
            if bd.exists():
                for f in bd.iterdir():
                    if f.is_file() and f.suffix == ".json" and f.stem not in valid_ids:
                        try: f.unlink(); files += 1
                        except Exception: pass
            audit(uid, "clean_orphans", f"sandboxes={dirs} files={files}")
            try: bot.send_message(uid, f"{G['ok']} Cleaned: {dirs} sandbox(es), {files} orphan file(s).")
            except Exception: pass
        threading.Thread(target=_co, daemon=True).start(); return
    if data == "adm_set_export":
        if not is_owner(uid): ack(call, "Owner only"); return
        ack(call, "Packing\u2026")
        def _ex():
            try:
                out = BASE_DIR / "exports"
                out.mkdir(exist_ok=True)
                stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
                target = out / f"kryon_export_{stamp}.zip"
                with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
                    for name in ("user_data.json", "settings.json", "audit.log"):
                        p = BASE_DIR / "storage" / name
                        if p.exists(): zf.write(p, arcname=name)
                audit(uid, "export_data", f"file={target.name}")
                with target.open("rb") as fh:
                    bot.send_document(uid, fh,
                        caption=f"{G['ok']} Export ({target.stat().st_size // 1024} KB)")
            except Exception as e:
                try: bot.send_message(uid, f"{G['no']} Export error: <code>{esc(e)}</code>", parse_mode="HTML")
                except Exception: pass
        threading.Thread(target=_ex, daemon=True).start(); return

    # Photo replacement
    if data.startswith("adm_photo_"):
        if not is_owner(uid) and not admin_can(uid, "manage_admins"):
            ack(call, "Owner / full-access only."); return
        key = data[len("adm_photo_"):]
        if key not in _PHOTO_SPECS: ack(call, "Unknown photo key"); return
        USER_STATES[uid] = {"flow": "await_menu_photo", "photo_key": key}
        label = PHOTO_KEYS_FRIENDLY.get(key, key)
        bot.send_message(call.message.chat.id,
            f"{G['upload']} {sc('Send the new photo for')} <b>{esc(label)}</b> {sc('now')}.\n/cancel {sc('to abort')}.",
            parse_mode="HTML"); return

    # Mega advanced panels from base file (call via function names)
    _ADVANCED_PANEL_MAP = {
        "adm_analytics":     "render_adm_analytics",
        "adm_user_tools":    "render_adm_user_tools",
        "adm_bot_manager":   "render_adm_bot_manager",
        "adm_sec_center":    "render_adm_sec_center",
        "adm_notify_center": "render_adm_notify_center",
        "adm_sys_tools":     "render_adm_sys_tools",
        "adm_pay_config":    "render_adm_pay_config",
        "adm_bot_cfg":       "render_adm_bot_cfg",
        "adm_appearance":    "render_adm_appearance",
        "adm_coupon_plus":   "render_adm_coupon_plus",
        "adm_templates":     "render_adm_templates",
        "adm_referral_sys":  "render_adm_referral_sys",
        "adm_janitor":       "render_adm_janitor",
        "adm_webhooks":      "render_adm_webhooks",
        "adm_feature_flags": "render_adm_feature_flags",
        "adm_rate_config":   "render_adm_rate_config",
        "adm_live_monitor":  "render_adm_live_monitor",
        "adm_rev_goals":     "render_adm_rev_goals",
        "adm_scheduler":     "render_adm_scheduler",
        "adm_import_export": "render_adm_export_menu",
        "adm_leaderboard":   "render_adm_leaderboard",
        "adm_languages":     "render_adm_languages",
        "adm_bot_controls":  "render_adm_bot_controls",
        "adm_subscriptions": "render_adm_subscriptions",
        "adm_admin_2fa":     "render_adm_admin_2fa",
        "adm_revenue_report":"render_adm_revenue_report",
        "adm_growth_stats":  "render_adm_growth_stats",
        "adm_top_users":     "render_adm_top_users",
        "adm_plan_dist":     "render_adm_plan_dist",
        "adm_bot_activity":  "render_adm_bot_activity",
        "adm_user_search":   "render_adm_user_search",
        "adm_banned_list":   "render_adm_banned_list",
        "adm_wallet_admin":  "render_adm_wallet_admin",
        "adm_user_export_csv": "render_adm_user_export_csv",
        "adm_notify_user":   "render_adm_notify_user",
        "adm_user_reset":    "render_adm_user_reset_prompt",
        "adm_crashed_bots":  "render_adm_crashed_bots",
        "adm_bot_search":    "render_adm_bot_search",
        "adm_bot_size_report":"render_adm_bot_size_report",
        "adm_force_scan_all":"action_adm_force_scan_all",
        "adm_threat_log":    "render_adm_threat_log",
        "adm_sec_stats":     "render_adm_sec_stats",
        "adm_sec_whitelist": "render_adm_sec_whitelist_prompt",
        "adm_scan_report":   "render_adm_scan_report",
        "adm_sec_blacklist": "render_adm_sec_blacklist",
        "adm_notify_all":    "render_adm_notify_all",
        "adm_notify_running":"render_adm_notify_running",
        "adm_schedule_msg":  "render_adm_schedule_msg",
        "adm_quick_announce":"render_adm_quick_announce",
        "adm_sys_health":    "render_adm_sys_health",
        "adm_disk_usage":    "render_adm_disk_usage",
        "adm_db_info":       "render_adm_db_info",
        "adm_token_check":   "render_adm_token_check",
        "adm_security_log":  "render_adm_security_log" if "render_adm_security_log" in dir() else None,
    }
    # sub-callbacks
    if data == "adm_mass_restart_stopped":
        fn = globals().get("render_adm_mass_restart_stopped")
        if fn: fn(call); return
    if data == "adm_mass_restart_stopped_yes":
        fn = globals().get("action_adm_mass_restart_stopped")
        if fn: fn(call); return
    if data == "adm_kill_all_now":
        return render_adm_confirm_custom(call, "adm_kill_all_now_yes", "Kill ALL running bots immediately", "adm_bot_manager")
    if data == "adm_kill_all_now_yes":
        fn = globals().get("action_adm_kill_all")
        if fn: fn(call); return
    if data.startswith("adm_notify_plan_"):
        fn = globals().get("render_adm_notify_plan")
        if fn: fn(call, data[len("adm_notify_plan_"):]); return
    if data == "adm_notify_plan_select":
        fn = globals().get("render_adm_notify_plan_select")
        if fn: fn(call); return
    if data == "adm_clear_cache":
        cache_clear_all()
        audit(uid, "clear_cache", "manual")
        ack(call, "Caches cleared!")
        fn = globals().get("render_adm_sys_tools")
        if fn: fn(call)
        return

    if data in _ADVANCED_PANEL_MAP:
        fn_name = _ADVANCED_PANEL_MAP[data]
        if fn_name:
            fn = globals().get(fn_name)
            if fn: fn(call); return
        ack(call, "?"); return

    # Comprehensive fallback for admin callbacks.  The project contains many
    # admin screens whose callback name directly matches their render function;
    # route those automatically instead of silently doing nothing.
    _direct_admin_fn = {
        "adm_pay_auto_approve": None,
        "adm_pay_merchant_name": None,
        "adm_pay_method_number": None,
        "adm_pay_method_toggle": None,
        "adm_pay_method_setnumber": None,
        "adm_tmpl_edit_payment_received": None,
        "adm_tmpl_reset_payment_received": None,
        "adm_bc_toggle_notif_on_new_payment": None,
        "adm_bc_toggle_notif_on_approved": None,
        "adm_bc_toggle_notif_on_rejected": None,
        "adm_bc_set_payment_notif_channel": None,
    }
    if data == "adm_pay_auto_approve":
        cur = bool(get_setting("auto_approve_payments", False))
        set_setting("auto_approve_payments", not cur)
        audit(uid, "payment_auto_approve_toggle", f"now={not cur}")
        ack(call, f"Auto-Approve: {'ON' if not cur else 'OFF'}")
        render_adm_pay_config(call); return
    if data.startswith("adm_pay_method_toggle_") or data.startswith("adm_pay_method_setnumber_"):
        action_adm_pay_method_number(call, data); return
    if data == "adm_pay_merchant_name":
        USER_STATES[uid] = {"flow": "await_adm_payment_setting", "setting_key": "payment_merchant_name", "kind": "text"}
        bot.send_message(call.message.chat.id, f"{G['settings']} Send the new payment merchant/display name:", parse_mode="HTML"); return
    if data.startswith("adm_bc_set_"):
        raw = data[len("adm_bc_set_"):]
        # Inputs are handled by one safe generic state handler below.
        mapping = {
            "min_payment_amount": ("min_payment_amount", "number"),
            "max_payment_amount": ("max_payment_amount", "number"),
            "discount_threshold": ("discount_threshold", "number"),
            "discount_pct": ("discount_pct", "number"),
            "payment_tax_pct": ("payment_tax_pct", "number"),
            "payment_currency": ("payment_currency", "currency"),
            "currency_symbol": ("currency_symbol", "text"),
            "payment_notif_channel": ("payment_notif_channel", "text"),
        }
        if raw in mapping:
            key, kind = mapping[raw]
            USER_STATES[uid] = {"flow": "await_adm_payment_setting", "setting_key": key, "kind": kind}
            bot.send_message(call.message.chat.id, f"{G['settings']} Send new value for <b>{esc(raw)}</b>:", parse_mode="HTML"); return
    if data == "adm_bc_set_currency_INR_₹":
        set_setting("payment_currency", "INR"); set_setting("currency_symbol", "₹")
        audit(uid, "currency_set", "INR/₹"); ack(call, "Currency set to INR ₹")
        render_adm_pay_currency(call); return
    if data == "adm_bc_toggle_notif_on_new_payment":
        k="notif_on_new_payment"; v=bool(get_setting(k, True)); set_setting(k, not v); ack(call, f"New payment notifications: {'ON' if not v else 'OFF'}"); render_adm_pay_notif_settings(call); return
    if data == "adm_bc_toggle_notif_on_approved":
        k="notif_on_approved"; v=bool(get_setting(k, True)); set_setting(k, not v); ack(call, f"Approved notifications: {'ON' if not v else 'OFF'}"); render_adm_pay_notif_settings(call); return
    if data == "adm_bc_toggle_notif_on_rejected":
        k="notif_on_rejected"; v=bool(get_setting(k, True)); set_setting(k, not v); ack(call, f"Rejected notifications: {'ON' if not v else 'OFF'}"); render_adm_pay_notif_settings(call); return
    if data == "adm_tmpl_edit_payment_received":
        USER_STATES[uid] = {"flow": "await_adm_payment_template", "template_key": "payment_received"}
        bot.send_message(call.message.chat.id, f"{G['settings']} Send the new payment receipt template. Variables: <code>{{name}}</code>, <code>{{amount}}</code>, <code>{{plan}}</code>, <code>{{tx_id}}</code>, <code>{{date}}</code>", parse_mode="HTML"); return
    if data == "adm_tmpl_reset_payment_received":
        set_setting("tmpl_payment_received", "")
        ack(call, "Payment receipt template reset")
        render_adm_pay_receipt_tmpl(call); return
    # Dynamic admin callbacks (buttons created with runtime keys/IDs)
    # These routes are intentionally handled before the generic name lookup.
    if data.startswith("adm_pay_edit_"):
        return render_adm_pay_method_edit(call, data[len("adm_pay_edit_"):])
    if data.startswith("adm_app_theme_"):
        key = data[len("adm_app_theme_"):]
        if key in _APPEARANCE_THEMES:
            set_setting("ui_theme", key); ack(call, f"Theme: {key}"); return render_adm_app_theme(call)
        ack(call, "Unknown theme"); return
    if data.startswith("adm_app_emoji_set_"):
        key = data[len("adm_app_emoji_set_"):]
        USER_STATES[uid] = {"flow":"await_adm_emoji", "emoji_key":key}
        bot.send_message(call.message.chat.id, f"✏️ Send emoji for <code>{esc(key)}</code> (send <code>-</code> to reset).", parse_mode="HTML"); return
    if data == "adm_app_emoji_reset":
        set_setting("custom_emojis", {}); ack(call, "Custom emojis reset"); return render_adm_app_emojis(call)
    if data.startswith("adm_tmpl_edit_"):
        key = data[len("adm_tmpl_edit_"):]
        if key in _MESSAGE_TEMPLATES:
            USER_STATES[uid] = {"flow":"await_adm_template", "template_key":key}
            bot.send_message(call.message.chat.id, f"📝 Send the new template for <b>{esc(_MESSAGE_TEMPLATES[key]['label'])}</b>.", parse_mode="HTML"); return
        ack(call, "Unknown template"); return
    if data.startswith("adm_jan_toggle_"):
        key = data[len("adm_jan_toggle_"):]
        set_setting(f"jan_{key}", not bool(get_setting(f"jan_{key}", False))); ack(call, "Janitor rule updated"); return render_adm_janitor(call)
    if data.startswith("adm_ff_toggle_"):
        key = data[len("adm_ff_toggle_"):]
        if key in _FEATURE_FLAG_DEFAULTS:
            _ff_set(key, not _ff_get(key)); ack(call, "Feature flag updated"); return render_adm_feature_flags(call)
        ack(call, "Unknown feature"); return
    if data.startswith("adm_rate_plan_"):
        return render_adm_rate_plan(call, data[len("adm_rate_plan_"):])
    if data.startswith("adm_rate_set_"):
        raw = data[len("adm_rate_set_"):]
        parts = raw.split("_", 1)
        if len(parts) == 2 and parts[0] in _RATE_LIMIT_DEFAULTS and parts[1] in ("uploads_per_day","starts_per_hour","msgs_per_min"):
            USER_STATES[uid] = {"flow":"await_adm_rate", "plan":parts[0], "metric":parts[1]}
            bot.send_message(call.message.chat.id, f"⏱️ Send new value for <code>{esc(parts[0])} / {esc(parts[1])}</code>:", parse_mode="HTML"); return
        ack(call, "Invalid rate setting"); return
    if data.startswith("adm_sched_toggle_"):
        tid = data[len("adm_sched_toggle_"):]; val = _sched_toggle_task(tid); ack(call, "Task enabled" if val else "Task disabled" if val is False else "Task not found"); return render_adm_sched_list(call)
    if data.startswith("adm_sched_del_"):
        tid = data[len("adm_sched_del_"):]; ok = _sched_remove_task(tid); ack(call, "Task deleted" if ok else "Task not found"); return render_adm_sched_list(call)
    if data.startswith("adm_lang_set_"):
        code = data[len("adm_lang_set_"):]
        if code in _SUPPORTED_LANGUAGES:
            set_setting("default_language", code); ack(call, f"Language: {_SUPPORTED_LANGUAGES[code]}"); return render_adm_languages(call)
        ack(call, "Unknown language"); return
    if data.startswith("adm_bcbot_"):
        prefix = data[len("adm_bcbot_"):]
        b = next((x for x in db_load()["bots"].values() if str(x.get("_id",""))[:20] == prefix), None)
        if b: return render_adm_bc_single(call, b["_id"])
        ack(call, "Bot not found"); return
    if data.startswith("adm_bc_stop_") or data.startswith("adm_bc_restart_"):
        prefix = data.split("_", 3)[3]
        b = next((x for x in db_load()["bots"].values() if str(x.get("_id",""))[:20] == prefix), None)
        if not b: ack(call, "Bot not found"); return
        try:
            if data.startswith("adm_bc_stop_"): stop_child(b["_id"], manual=True); ack(call, "Stopped")
            else: start_child(b["_id"]); ack(call, "Started")
        except Exception as e: ack(call, f"Failed: {e}")
        return render_adm_bc_single(call, b["_id"])
    if data.startswith("adm_bc_logs_") or data.startswith("adm_bc_env_") or data.startswith("adm_bc_res_") or data.startswith("adm_bc_del_"):
        prefix = data.split("_", 3)[3]
        b = next((x for x in db_load()["bots"].values() if str(x.get("_id",""))[:20] == prefix), None)
        if not b: ack(call, "Bot not found"); return
        bid = b["_id"]
        if data.startswith("adm_bc_logs_"): return render_adm_bc_logs(call, bid)
        if data.startswith("adm_bc_env_"): return render_adm_bc_env_editor(call, bid)
        if data.startswith("adm_bc_res_"): return render_adm_bc_resources(call, bid)
        return render_bot_delete_confirm(call, bid)
    if data.startswith("adm_ghrepo_"):
        repo = data[len("adm_ghrepo_"):]
        return render_adm_gh_files(call, repo, "")
    if data.startswith("adm_ghfile_"):
        try: idx = int(data[len("adm_ghfile_"):])
        except Exception: ack(call, "Invalid file"); return
        state = get_setting("github_browser_files", []) or []
        if 0 <= idx < len(state): return render_adm_gh_file_view(call, state[idx].get("repo", GH.get("repo","")), state[idx].get("path", ""))
        ack(call, "File not found"); return
    if data.startswith("adm_photo_"):
        return render_adm_photo_one(call, data[len("adm_photo_"):])

    # Generic exact-name routing covers the large advanced admin surface.
    _candidate = "render_" + data
    _fn = globals().get(_candidate)
    if callable(_fn):
        _fn(call); return
    _candidate = "render_adm_" + data[4:] if data.startswith("adm_") else ""
    _fn = globals().get(_candidate)
    if callable(_fn):
        _fn(call); return
    # delegate to _register_extra_routes from new file
    if not _register_extra_routes(data, call):
        ack(call, "?")


def render_github_subroute(call: types.CallbackQuery, data: str) -> None:
    uid = call.from_user.id
    if data == "gh_set_token":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_gh_token"}
        bot.send_message(call.message.chat.id,
            f"{G['key']} {sc('Send your GitHub personal access token')} (repo scope).",
            parse_mode="HTML"); return
    if data == "gh_set_repo":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_gh_repo"}
        bot.send_message(call.message.chat.id,
            f"{G['cog']} Send repo as <code>user/repo</code>.", parse_mode="HTML"); return
    if data == "gh_set_branch":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_gh_branch"}
        bot.send_message(call.message.chat.id,
            f"{G['cog']} Send branch name (e.g. <code>main</code>).", parse_mode="HTML"); return
    if data == "gh_set_interval":
        if not is_owner(uid): ack(call, "Owner only"); return
        USER_STATES[uid] = {"flow": "await_gh_interval"}
        bot.send_message(call.message.chat.id,
            f"{G['cog']} Send backup interval in minutes (min 15).", parse_mode="HTML"); return
    if data == "gh_toggle_auto":
        if not is_owner(uid): ack(call, "Owner only"); return
        cur = bool(get_setting("github_auto_enabled", True))
        set_setting("github_auto_enabled", not cur)
        GH["autoEnabled"] = not cur
        audit(uid, "gh_auto_toggle", f"now={'on' if not cur else 'off'}")
        ack(call, f"GitHub auto: {'ON' if not cur else 'OFF'}")
        return render_adm_github(call)
    if data == "gh_backup_now":
        ack(call, "Backing up\u2026")
        def _bg():
            try:
                res = gh_backup_now()
                bot.send_message(uid,
                    f"<b>{'OK' if res.get('ok') else G['no']} GitHub Backup</b>\n"
                    f"{bullet('Size', fmt_bytes(res.get('sizeBytes', 0)))}\n"
                    f"{bullet('Error', res.get('error', '') or 'none')}", parse_mode="HTML")
            except Exception as e:
                bot.send_message(uid, f"{G['no']} {esc(e)}", parse_mode="HTML")
        threading.Thread(target=_bg, daemon=True).start(); return
    if data == "gh_restore_now":
        if not is_owner(uid): ack(call, "Owner only"); return
        ack(call, "Restoring\u2026")
        def _rg():
            try:
                res = gh_restore_latest()
                bot.send_message(uid,
                    f"<b>{'OK' if res.get('ok') else G['no']} GitHub Restore</b>\n"
                    f"{bullet('Error', res.get('error', '') or 'none')}", parse_mode="HTML")
            except Exception as e:
                bot.send_message(uid, f"{G['no']} {esc(e)}", parse_mode="HTML")
        threading.Thread(target=_rg, daemon=True).start(); return
    # Generic fallback for static admin screens.  A large part of the panel
    # follows the convention callback_data="adm_<name>" ->
    # render_adm_<name>(call).  Older revisions had buttons for these screens
    # without adding every single entry to the dispatcher, so the button
    # appeared to do nothing.  Keep explicit/dynamic routes above, then safely
    # resolve any matching renderer here.
    if data.startswith("adm_"):
        fn = globals().get("render_" + data)
        if callable(fn):
            try:
                fn(call)
            except Exception as e:
                _log_err(f"admin_callback:{data}", e)
                ack(call, "Unable to open this section")
            return

    ack(call, "?")


# ─── Callback de-duplication ──────────────────────────────────────────────────

_CB_SEEN: "deque" = deque(maxlen=512)
_CB_SEEN_LOCK = threading.Lock()
_CB_DEDUP_WINDOW = 12.0


def _is_duplicate_callback(call_id: str) -> bool:
    if not call_id:
        return False
    now = time.time()
    with _CB_SEEN_LOCK:
        while _CB_SEEN and now - _CB_SEEN[0][1] > _CB_DEDUP_WINDOW:
            _CB_SEEN.popleft()
        for cid, _ in _CB_SEEN:
            if cid == call_id:
                return True
        _CB_SEEN.append((call_id, now))
    return False


# ─── Action helpers used by on_text / on_photo ────────────────────────────────

def _handle_env_kv(m: types.Message, st: Dict[str, Any]) -> None:
    bot_id = st.get("bot_id")
    b = find_bot(bot_id) if bot_id else None
    if not b or (b["owner"] != m.from_user.id and not is_admin(m.from_user.id)):
        bot.reply_to(m, f"{G['no']} bot not found"); USER_STATES.pop(m.from_user.id, None); return
    text = (m.text or "").strip()
    if "=" not in text:
        bot.reply_to(m, f"{G['no']} Format: <code>KEY=VALUE</code>", parse_mode="HTML"); return
    parsed = {}
    if "\n" in text or "\r" in text:
        parsed = _repair_env_dict({"__PASTED_ENV__": text})
    else:
        k, v = text.split("=", 1)
        k = k.strip().upper()
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", k):
            bot.reply_to(m, f"{G['no']} invalid env key"); return
        parsed = _split_embedded_env_value(k, v)
    if not parsed:
        bot.reply_to(m, f"{G['no']} no valid env assignments"); return
    current = _repair_env_dict(b.get("env") or {})
    current.update(parsed)
    # Persist directly to the mutable DB and verify the write. This fixes the
    # previous false-positive "keys saved" response where the next Env Vars
    # screen could still show 0 variables. There is intentionally no plaintext
    # secret in the audit record or confirmation message.
    if not _persist_bot_env(bot_id, current):
        bot.reply_to(m, f"{G['no']} Could not persist ENV variables. Please try again.")
        return
    audit(m.from_user.id, "env_set", f"bot={bot_id} keys={','.join(sorted(parsed.keys()))}")
    USER_STATES.pop(m.from_user.id, None)
    bot.reply_to(m, f"{G['ok']} <code>{esc(', '.join(sorted(parsed.keys())))}</code> saved.\nVariables: <b>{len(current)}</b>", parse_mode="HTML")


def _handle_pip_install(m: types.Message, st: Dict[str, Any]) -> None:
    bot_id = st.get("bot_id")
    b = find_bot(bot_id) if bot_id else None
    if not b:
        bot.reply_to(m, f"{G['no']} bot not found"); USER_STATES.pop(m.from_user.id, None); return
    packages = (m.text or "").strip().split()
    if not packages:
        bot.reply_to(m, f"{G['no']} no packages"); USER_STATES.pop(m.from_user.id, None); return
    USER_STATES.pop(m.from_user.id, None)
    bot.reply_to(m, f"\u23f3 Installing {' '.join(packages[:5])}\u2026")
    def _bg():
        import subprocess as _sp
        try:
            bot_dir = Path(b.get("dir", ""))
            bot_dir.mkdir(parents=True, exist_ok=True)
            venv_pip = bot_dir / "venv" / "bin" / "pip"
            pip_cmd = str(venv_pip) if venv_pip.exists() else "pip"
            result = _sp.run([pip_cmd, "install"] + packages[:10],
                             capture_output=True, text=True, timeout=120)
            out = (result.stdout + result.stderr)[-1500:]
            ok = result.returncode == 0
            audit(m.from_user.id, "pip_install", f"bot={bot_id} ok={ok}")
            bot.send_message(m.chat.id,
                f"<b>{'OK' if ok else G['no']} pip install</b>\n<pre>{esc(out)}</pre>",
                parse_mode="HTML")
        except Exception as e:
            bot.send_message(m.chat.id,
                f"{G['no']} pip error: <code>{esc(e)}</code>", parse_mode="HTML")
    threading.Thread(target=_bg, daemon=True).start()


def _handle_tunnel_port(m: types.Message, st: Dict[str, Any]) -> None:
    USER_STATES.pop(m.from_user.id, None)
    try:
        port = int((m.text or "").strip())
    except Exception:
        bot.reply_to(m, f"{G['no']} Invalid port"); return
    bot.reply_to(m, f"\U0001f310 Tunnel on port {port} \u2014 ngrok/cloudflared must be installed on the server.")


def _handle_cron(m: types.Message, st: Dict[str, Any]) -> None:
    bot_id = st.get("bot_id")
    b = find_bot(bot_id) if bot_id else None
    if not b or (b["owner"] != m.from_user.id and not is_admin(m.from_user.id)):
        bot.reply_to(m, f"{G['no']} bot not found"); USER_STATES.pop(m.from_user.id, None); return
    parts = (m.text or "").strip().split()
    if len(parts) >= 2 and parts[0] in ("restart_hours", "backup_hours"):
        try:
            val = max(0, int(parts[1]))
        except Exception:
            bot.reply_to(m, f"{G['no']} bad number"); return
        b.setdefault("cron", {})[parts[0]] = val
        save_bot(b)
        audit(m.from_user.id, "cron_set", f"bot={bot_id} {parts[0]}={val}")
        USER_STATES.pop(m.from_user.id, None)
        bot.reply_to(m, f"{G['ok']} Saved: <code>{parts[0]} = {val}</code>", parse_mode="HTML")
    else:
        bot.reply_to(m, f"{G['no']} Use: <code>restart_hours N</code> or <code>backup_hours N</code>",
                     parse_mode="HTML")


def _handle_admin_finduser(m: types.Message) -> None:
    USER_STATES.pop(m.from_user.id, None)
    try:
        target_uid = int(m.text.strip())
    except Exception:
        bot.reply_to(m, f"{G['no']} bad uid"); return
    d = db_load()
    u = d["users"].get(str(target_uid))
    if not u:
        bot.reply_to(m, f"{G['no']} user not found"); return
    bots = [b for b in d["bots"].values() if str(b.get("owner")) == str(target_uid)]
    cap = (
        f"<b>{G['user']} User Info</b>\n{G['div_eq']}\n"
        f"{bullet('ID', target_uid)}\n"
        f"{bullet('Name', u.get('name', '—'))}\n"
        f"{bullet('Username', '@' + (u.get('username') or '—'))}\n"
        f"{bullet('Plan', u.get('plan', 'free'))}\n"
        f"{bullet('Joined', fmt_ts(u.get('joined')))}\n"
        f"{bullet('Bots', len(bots))}\n"
        f"{bullet('Wallet', money(u.get('wallet', 0)))}\n"
        f"{bullet('Banned', u.get('banned', False))}\n"
        f"{bullet('Verified', 'Yes' if u.get('verified') else 'No')}\n"
        f"{G['div']}{FOOTER}"
    )
    bot.reply_to(m, cap, parse_mode="HTML")


def _handle_ban_cmd(m: types.Message) -> None:
    USER_STATES.pop(m.from_user.id, None)
    parts = (m.text or "").split(None, 2)
    if not parts: return
    op = parts[0].lower()
    d = db_load()
    if op == "ban" and len(parts) >= 2:
        try: uid = int(parts[1])
        except Exception: bot.reply_to(m, f"{G['no']} bad uid"); return
        reason = parts[2] if len(parts) >= 3 else "banned by admin"
        u = d["users"].get(str(uid))
        if not u: bot.reply_to(m, f"{G['no']} user not found"); return
        u["banned"] = True
        u["ban_reason"] = reason
        db_save(d)
        for b in list(d["bots"].values()):
            if str(b.get("owner")) == str(uid):
                try: stop_child(b["_id"], manual=True)
                except Exception: pass
        audit(m.from_user.id, "ban_user", f"uid={uid}")
        bot.reply_to(m, f"{G['ok']} banned {uid}")
    elif op == "unban" and len(parts) >= 2:
        try: uid = int(parts[1])
        except Exception: bot.reply_to(m, f"{G['no']} bad uid"); return
        u = d["users"].get(str(uid))
        if not u: bot.reply_to(m, f"{G['no']} user not found"); return
        u["banned"] = False
        u["ban_reason"] = ""
        db_save(d)
        audit(m.from_user.id, "unban_user", f"uid={uid}")
        bot.reply_to(m, f"{G['ok']} unbanned {uid}")


def _handle_giveplan_cmd(m: types.Message) -> None:
    USER_STATES.pop(m.from_user.id, None)
    parts = (m.text or "").split()
    if len(parts) < 2:
        bot.reply_to(m, f"{G['no']} Format: <code>uid plan [days]</code>", parse_mode="HTML"); return
    try:
        uid = int(parts[0])
        plan = parts[1]
        days = int(parts[2]) if len(parts) >= 3 else None
    except Exception:
        bot.reply_to(m, f"{G['no']} bad args"); return
    if plan not in PLAN_LIMITS:
        bot.reply_to(m, f"{G['no']} Unknown plan: {plan}"); return
    ok = grant_plan(uid, plan, days=days)
    audit(m.from_user.id, "give_plan", f"uid={uid} plan={plan} days={days}")
    bot.reply_to(m, f"{G['ok']} given {plan} to {uid}" if ok else f"{G['no']} user not found")


def _handle_broadcast(m: types.Message) -> None:
    if not is_admin(m.from_user.id):
        USER_STATES.pop(m.from_user.id, None); return
    text = (m.text or "").strip()
    USER_STATES.pop(m.from_user.id, None)
    plan_filter: Optional[str] = None
    scheduled_at: Optional[str] = None
    if text.startswith("plan:"):
        parts = text.split(None, 1)
        plan_filter = parts[0][5:]
        text = parts[1] if len(parts) > 1 else ""
    elif text.startswith("at:"):
        parts = text.split(None, 1)
        try:
            scheduled_at = parts[0][3:].strip()
            text = parts[1] if len(parts) > 1 else ""
        except Exception:
            pass
    if not text:
        bot.reply_to(m, f"{G['no']} empty message"); return
    if scheduled_at:
        try:
            when = datetime.strptime(scheduled_at, "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
        except Exception:
            bot.reply_to(m, f"{G['no']} bad datetime format (use YYYY-MM-DD HH:MM)"); return
        d = db_load()
        d.setdefault("scheduled_broadcasts", []).append({
            "text": text, "plan": plan_filter, "at": when.isoformat(), "by": m.from_user.id,
        })
        db_save(d)
        audit(m.from_user.id, "broadcast_scheduled", f"at={scheduled_at}")
        bot.reply_to(m, f"{G['ok']} Scheduled for {scheduled_at}")
        return
    bot.reply_to(m, f"\u23f3 Broadcasting\u2026")
    def _bg():
        users = db_load()["users"]
        sent = fail = 0
        for uid_str, u in users.items():
            if u.get("banned"): continue
            if plan_filter and u.get("plan") != plan_filter: continue
            try:
                bot.send_message(int(uid_str),
                    f"<b>\U0001f4e2 {BRAND_TAG}</b>\n{G['div']}\n{esc(text)}",
                    parse_mode="HTML", disable_web_page_preview=True)
                sent += 1
            except Exception: fail += 1
            time.sleep(0.05)
        audit(m.from_user.id, "broadcast_sent", f"sent={sent} fail={fail}")
        try: bot.send_message(m.from_user.id, f"{G['ok']} Broadcast done: {sent} sent, {fail} fail.")
        except Exception: pass
    threading.Thread(target=_bg, daemon=True).start()


def _handle_coupon_user(m: types.Message) -> None:
    code = (m.text or "").strip().upper()
    USER_STATES.pop(m.from_user.id, None)
    d = db_load()
    c = d["coupons"].get(code)
    if not c:
        bot.reply_to(m, f"{G['no']} Invalid code"); return
    if int(c.get("uses_left", 0)) <= 0:
        bot.reply_to(m, f"{G['no']} Code expired"); return
    c["uses_left"] = int(c.get("uses_left", 0)) - 1
    pct = int(c.get("percent", 0))
    d["users"].get(str(m.from_user.id), {}).setdefault("coupons_used", []).append(code)
    db_save(d)
    audit(m.from_user.id, "coupon_redeem", f"code={code} pct={pct}")
    bot.reply_to(m,
        f"<b>{G['ok']} Coupon applied</b>: <code>{esc(code)}</code>\n"
        f"{bullet('Discount', f'{pct}% off next plan purchase')}",
        parse_mode="HTML")


def _handle_coupon_admin(m: types.Message) -> None:
    if not is_admin(m.from_user.id):
        USER_STATES.pop(m.from_user.id, None); return
    parts = (m.text or "").strip().split()
    if not parts: return
    op = parts[0].lower()
    d = db_load()
    if op == "add" and len(parts) >= 4:
        code = parts[1].upper()
        try:
            pct = int(parts[2])
            uses = int(parts[3])
        except Exception:
            bot.reply_to(m, f"{G['no']} bad numbers"); return
        d["coupons"][code] = {"percent": pct, "uses_left": uses, "created": ts_iso()}
        db_save(d)
        audit(m.from_user.id, "coupon_add", f"code={code}")
        USER_STATES.pop(m.from_user.id, None)
        bot.reply_to(m, f"{G['ok']} created {code}")
    elif op == "del" and len(parts) >= 2:
        code = parts[1].upper()
        if d["coupons"].pop(code, None):
            db_save(d)
            audit(m.from_user.id, "coupon_del", f"code={code}")
            USER_STATES.pop(m.from_user.id, None)
            bot.reply_to(m, f"{G['ok']} removed {code}")
        else:
            bot.reply_to(m, f"{G['no']} code not found")
    else:
        bot.reply_to(m, f"{G['no']} Use: <code>add CODE PCT USES</code> or <code>del CODE</code>",
                     parse_mode="HTML")


def _handle_admin_admins(m: types.Message) -> None:
    if not is_owner(m.from_user.id):
        return
    USER_STATES.pop(m.from_user.id, None)
    parts = m.text.split()
    if len(parts) < 2: return
    op = parts[0].lower()
    d = db_load()
    if op == "add" and len(parts) >= 3:
        try: uid = int(parts[1])
        except Exception: bot.reply_to(m, f"{G['no']} bad uid"); return
        role = parts[2]
        if role not in {"view-only", "manage-users", "full-access"}:
            bot.reply_to(m, f"{G['no']} bad role"); return
        d["admins"][str(uid)] = {"role": role, "added": ts_iso(), "by": m.from_user.id}
        db_save(d)
        audit(m.from_user.id, "admin_add", f"uid={uid} role={role}")
        bot.reply_to(m, f"{G['ok']} added admin {uid} ({role})")
    elif op == "del" and len(parts) >= 2:
        try: uid = int(parts[1])
        except Exception: bot.reply_to(m, f"{G['no']} bad uid"); return
        if d["admins"].pop(str(uid), None):
            db_save(d)
            audit(m.from_user.id, "admin_del", f"uid={uid}")
            bot.reply_to(m, f"{G['ok']} removed {uid}")


def _handle_ticket_subject(m: types.Message) -> None:
    USER_STATES[m.from_user.id] = {"flow": "await_ticket_body", "subject": m.text.strip()[:120]}
    bot.reply_to(m, f"{G['ticket']} Now send the ticket body (describe your issue).")


def _handle_ticket_body(m: types.Message, st: Dict[str, Any]) -> None:
    subject = st.get("subject") or "Support"
    d = db_load()
    tid = rand_token(6)
    d["tickets"][tid] = {
        "id": tid, "uid": m.from_user.id, "subject": subject, "status": "open",
        "messages": [{"from": "user", "text": m.text, "ts": ts_iso()}],
        "opened_at": ts_iso(),
    }
    db_save(d)
    USER_STATES.pop(m.from_user.id, None)
    bot.reply_to(m, f"<b>{G['ok']} Ticket opened #{tid}</b>", parse_mode="HTML")
    notify_owner(
        f"<b>{G['ticket']} New Ticket #{tid}</b>\n"
        f"{bullet('From', m.from_user.id)}\n"
        f"{bullet('Subject', subject)}\n"
        f"{bullet('Body', m.text[:400])}"
    )
    pg = get_setting("private_approval_group", None)
    if pg:
        try:
            bot.send_message(pg,
                f"<b>{G['ticket']} New Support Ticket #{tid}</b>\n"
                f"{bullet('From', m.from_user.id)}\n"
                f"{bullet('Subject', subject)}\n"
                f"{esc(m.text[:300])}",
                parse_mode="HTML")
        except Exception:
            pass


def _handle_ticket_reply(m: types.Message, st: Dict[str, Any]) -> None:
    tid = st.get("tid")
    d = db_load()
    t = d["tickets"].get(tid)
    if not t:
        USER_STATES.pop(m.from_user.id, None); return
    if t["uid"] != m.from_user.id and not is_admin(m.from_user.id):
        USER_STATES.pop(m.from_user.id, None); return
    who = "admin" if is_admin(m.from_user.id) and t["uid"] != m.from_user.id else "user"
    t.setdefault("messages", []).append({"from": who, "text": m.text, "ts": ts_iso()})
    db_save(d)
    USER_STATES.pop(m.from_user.id, None)
    target = OWNER_ID if who == "user" else t["uid"]
    try:
        bot.send_message(target,
            f"<b>{G['ticket']} Ticket #{tid}</b> \u2014 {who} replied\n{esc(m.text)[:1000]}",
            parse_mode="HTML")
    except Exception:
        pass
    bot.reply_to(m, f"{G['ok']} reply sent")



# ─────────────────────────────────────────────────────────────────────────────
# BharatPe UTR auto-verification (optional, env-configured)
# ─────────────────────────────────────────────────────────────────────────────

def _extract_utr(text: str) -> Optional[str]:
    text = str(text or "").strip()
    m = re.search(r"(?:\bUTR\b|\bRRN\b|\bTransaction(?:\s+ID)?\b)\s*[:#=\-]?\s*([A-Za-z0-9]{8,30})",
                  text, re.I)
    if m:
        return m.group(1).strip()
    # Common UPI UTR/RRN values are 10–22 digits. Only treat a bare numeric
    # message as a UTR when it is long enough to avoid accidental matches.
    if re.fullmatch(r"\d{10,22}", text):
        return text
    return None


def _verify_bharatpe_payment(utr: str, amount: float) -> str:
    """Return SUCCESS, DUPLICATE, NOT_FOUND, or API_ERROR."""
    utr = str(utr or "").strip()
    if not utr:
        return "NOT_FOUND"

    # Prevent the same UTR from being approved twice.
    try:
        d = db_load_ro()
        for payment in d.get("payments", []):
            if str(payment.get("utr", "")).strip() == utr:
                return "DUPLICATE"
    except Exception:
        pass

    merchant_id = _HOST_SECRET_ENV.get("BHARATPE_MERCHANT_ID", "").strip()
    token = _HOST_SECRET_ENV.get("BHARATPE_TOKEN", "").strip()
    if not merchant_id or not token:
        return "API_ERROR"

    url = "https://payments-tesseract.bharatpe.in/api/v1/merchant/transactions"
    params = {"module": "PAYMENT_QR", "merchantId": merchant_id}
    headers = {"token": token, "Content-Type": "application/json"}

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=10)
        if resp.status_code != 200:
            return "API_ERROR"
        result = resp.json()
        transactions = (result.get("data") or {}).get("transactions") or []
        for tx in transactions:
            tx_utr = (
                tx.get("utr")
                or tx.get("bankReferenceNo")
                or tx.get("bankTxnId")
                or tx.get("transactionId")
                or tx.get("id")
            )
            if not tx_utr or str(tx_utr).strip() != utr:
                continue
            try:
                tx_amount = float(tx.get("amount"))
            except (TypeError, ValueError):
                continue
            if abs(tx_amount - float(amount)) >= 0.01:
                continue
            status = str(tx.get("status", "")).upper()
            if status in {"SUCCESS", "SUCCESSFUL", "COMPLETED", "ACTIVE", "PAID"}:
                return "SUCCESS"
        return "NOT_FOUND"
    except Exception as e:
        _log_err("bharatpe_verify", e)
        return "API_ERROR"


def _auto_approve_payment(pid: str, actor_id: int = 0) -> bool:
    """Approve and activate a payment idempotently without a callback object."""
    d = db_load()
    pay = next((x for x in d.get("payments", []) if x.get("id") == pid), None)
    if not pay or pay.get("status") != "pending":
        return False

    if pay.get("kind") == "wallet_topup":
        u = d.get("users", {}).get(str(pay.get("uid")))
        if not u:
            return False
        u["wallet"] = round(float(u.get("wallet", 0)) + float(pay.get("amount", 0)), 2)
        pay["status"] = "approved"
        pay["approved_by"] = int(actor_id or 0)
        pay["approved_at"] = ts_iso()
        pay["updated"] = ts_iso()
        db_save(d)
    elif pay.get("plan"):
        ok, _ = _activate_plan_payment(d, pay, actor_id)
        if not ok:
            return False
    else:
        return False

    audit(int(actor_id or 0), "pay_auto_approve", f"pid={pid};utr={pay.get('utr','')}")
    try:
        plan = str(pay.get("plan") or "")
        if plan in PLAN_LIMITS:
            p = PLAN_LIMITS[plan]
            bot.send_message(
                pay["uid"],
                f"<b>{G['ok']} Payment verified automatically</b>\n"
                f"{bullet('Plan', p['name'])}\n"
                f"{bullet('Amount', money(pay.get('amount', 0)))}\n"
                f"{bullet('Status', 'Active')}\n"
                f"{sc('Purchase saved to your account history.')}",
                parse_mode="HTML",
            )
        else:
            bot.send_message(
                pay["uid"],
                f"<b>{G['ok']} Payment verified automatically</b>\n"
                f"{bullet('Amount', money(pay.get('amount', 0)))}",
                parse_mode="HTML",
            )
    except Exception:
        pass
    return True

def _handle_payment_proof(m: types.Message, st: Dict[str, Any]) -> None:
    method = st.get("method") or "unknown"
    plan = st.get("plan")
    p = PLAN_LIMITS.get(plan or "")
    amount = float(st.get("amount", (p or {}).get("price", 0)) or 0)
    text = (m.text or m.caption or "").strip()
    utr = _extract_utr(text)

    pid = rand_token(8)
    d = db_load()
    payment = {
        "id": pid, "uid": m.from_user.id, "method": method, "plan": plan,
        "amount": amount, "status": "pending", "ts": ts_iso(),
        "telegram_msg_id": m.message_id,
    }
    if utr:
        payment["utr"] = utr
    d["payments"].append(payment)
    db_save(d)
    USER_STATES.pop(m.from_user.id, None)

    auto_enabled = bool(get_setting("auto_approve_payments", False))
    verification = "SKIPPED"
    if auto_enabled and utr and method in UPI_PAYMENT_KEYS and amount > 0:
        verification = _verify_bharatpe_payment(utr, amount)
        if verification == "SUCCESS" and _auto_approve_payment(pid, OWNER_ID):
            bot.reply_to(
                m,
                f"<b>{G['ok']} Payment verified & approved automatically.</b>\n"
                f"{bullet('UTR', esc(utr))}\n{bullet('Amount', money(amount))}",
                parse_mode="HTML",
            )
            return

    try:
        _safe_forward_message(OWNER_ID, m.chat.id, m)
    except Exception:
        pass

    kb = types.InlineKeyboardMarkup()
    kb.add(
        Btn(f"{G['ok']}  Approve", callback_data=f"payapprove_{pid}"),
        Btn(f"{G['no']}  Reject", callback_data=f"payreject_{pid}"),
    )
    notify_owner(
        f"<b>{G['wallet']} New Payment Proof</b>\n"
        f"{bullet('ID', pid)}\n{bullet('From', m.from_user.id)}\n"
        f"{bullet('Method', method)}\n{bullet('Plan', plan or '—')}\n"
        f"{bullet('Amount', money(amount))}\n{bullet('UTR', utr or '—')}\n"
        f"{bullet('Auto check', verification)}"
    )
    try:
        bot.send_message(OWNER_ID, f"<b>Decide #{pid}</b>",
                         parse_mode="HTML", reply_markup=kb)
    except Exception:
        pass

    pg = get_setting("private_approval_group", None)
    if pg:
        try:
            _safe_forward_message(pg, m.chat.id, m)
            bot.send_message(pg, f"<b>Payment Proof #{pid}</b>",
                             parse_mode="HTML", reply_markup=kb)
        except Exception:
            pass

    bot.reply_to(m, f"<b>{G['ok']} Proof received</b> #{pid} — await admin.",
                 parse_mode="HTML")

def _handle_payment_proof_text(m: types.Message, st: Dict[str, Any]) -> None:
    _handle_payment_proof(m, st)


def _handle_topup_proof(m: types.Message) -> None:
    pid = rand_token(8)
    cap = (m.caption or m.text or "").strip()
    amt = 0
    ms = re.search(r"\d+", cap)
    if ms:
        amt = int(ms.group(0))
    d = db_load()
    d["payments"].append({
        "id": pid, "uid": m.from_user.id, "method": "topup", "plan": None,
        "amount": amt, "status": "pending", "ts": ts_iso(), "kind": "wallet_topup",
    })
    db_save(d)
    USER_STATES.pop(m.from_user.id, None)
    try: _safe_forward_message(OWNER_ID, m.chat.id, m)
    except Exception: pass
    kb = types.InlineKeyboardMarkup()
    kb.add(
        Btn(f"{G['ok']}  Approve", callback_data=f"payapprove_{pid}"),
        Btn(f"{G['no']}  Reject",  callback_data=f"payreject_{pid}"),
    )
    notify_owner(
        f"<b>{G['wallet']} Wallet Top-up</b>\n"
        f"{bullet('ID', pid)}\n{bullet('From', m.from_user.id)}\n"
        f"{bullet('Amount', money(amt))}"
    )
    try: bot.send_message(OWNER_ID, f"<b>Decide #{pid}</b>", parse_mode="HTML", reply_markup=kb)
    except Exception: pass
    bot.reply_to(m, f"<b>{G['ok']} Top-up proof received</b>", parse_mode="HTML")


def _handle_gift_target(m: types.Message, st: Dict[str, Any]) -> None:
    try: tgt = int(m.text.strip())
    except Exception: bot.reply_to(m, f"{G['no']} bad uid"); return
    d = db_load()
    if str(tgt) not in d["users"]:
        bot.reply_to(m, f"{G['no']} user not found"); return
    USER_STATES[m.from_user.id] = {"flow": "await_gift_confirm", "target": tgt}
    bot.reply_to(m,
        f"<b>{G['warn']} Confirm gift</b>\n{bullet('To', tgt)}\nSend <code>YES</code> to confirm.",
        parse_mode="HTML")


def _handle_gift_confirm(m: types.Message, st: Dict[str, Any]) -> None:
    USER_STATES.pop(m.from_user.id, None)
    if (m.text or "").strip().upper() != "YES":
        bot.reply_to(m, f"{G['no']} cancelled"); return
    tgt = int(st["target"])
    d = db_load()
    me = d["users"][str(m.from_user.id)]
    if me.get("plan") in ("free", None):
        bot.reply_to(m, f"{G['no']} no active plan to gift"); return
    plan = me["plan"]
    exp = me.get("plan_expires")
    me["plan"] = "free"
    me["plan_expires"] = None
    if str(tgt) in d["users"]:
        d["users"][str(tgt)]["plan"] = plan
        d["users"][str(tgt)]["plan_expires"] = exp
    db_save(d)
    audit(m.from_user.id, "plan_gift", f"to={tgt} plan={plan}")
    bot.reply_to(m, f"{G['ok']} plan gifted to {tgt}")
    try:
        bot.send_message(tgt,
            f"<b>{G['spark']} You received a gift plan</b>\n"
            f"{bullet('Plan', PLAN_LIMITS.get(plan, {}).get('name', plan))}",
            parse_mode="HTML")
    except Exception: pass


# ═══════════════════════════════════════════════════════════════════════════════
# REGISTERED BOT HANDLERS
# ═══════════════════════════════════════════════════════════════════════════════

@bot.callback_query_handler(func=lambda c: c.data == "group_verify_check")
def cb_group_verify(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    chat_id = call.message.chat.id
    not_joined = _check_group_membership(uid)
    if not_joined:
        ack(call, "You have not joined all groups yet!")
        try: bot.delete_message(chat_id, call.message.message_id)
        except Exception: pass
        _send_join_verification(chat_id, uid, not_joined)
    else:
        ack(call, "\u2713 Verified! Welcome.")
        try: bot.delete_message(chat_id, call.message.message_id)
        except Exception: pass
        render_main_menu(chat_id, uid)


@bot.callback_query_handler(func=lambda c: bool(c.data) and c.data.startswith("verify_"))
def cb_verify(call: types.CallbackQuery) -> None:
    uid = call.from_user.id
    chat_id = call.message.chat.id
    data = call.data[len("verify_"):]
    if data == "new":
        with _verify_lock:
            st = VERIFY_STATES.get(uid)
            if st and st.get("regens", 0) >= 5:
                ack(call, "Too many regenerations."); return
        try: bot.delete_message(chat_id, call.message.message_id)
        except Exception: pass
        ack(call, "New captcha\u2026")
        _send_captcha(chat_id, uid)
        with _verify_lock:
            if uid in VERIFY_STATES:
                VERIFY_STATES[uid]["regens"] = VERIFY_STATES[uid].get("regens", 0) + 1
        return
    with _verify_lock:
        state = VERIFY_STATES.get(uid)
    if not state:
        ack(call, "Session expired \u2014 send /start again."); return
    if data == state["answer"]:
        with _verify_lock:
            VERIFY_STATES.pop(uid, None)
        _mark_verified(uid)
        ack(call, "\u2713 Verified")
        try: bot.delete_message(chat_id, state["msg_id"])
        except Exception: pass
        try: audit(uid, "captcha_pass", f"tries={state.get('tries', 0)}")
        except Exception: pass
        render_main_menu(chat_id, uid,
            intro=f"<b>{G['ok']} Verification complete</b> \u2014 welcome, <b>{esc(call.from_user.first_name or 'friend')}</b>!")
        return
    state["tries"] = state.get("tries", 0) + 1
    left = max(0, 3 - state["tries"])
    if state["tries"] >= 3:
        with _verify_lock:
            VERIFY_STATES.pop(uid, None)
        try: bot.delete_message(chat_id, state["msg_id"])
        except Exception: pass
        ack(call, "Wrong 3 times \u2014 new captcha.")
        _send_captcha(chat_id, uid)
    else:
        ack(call, f"Wrong. {left} try(s) left.")


@bot.callback_query_handler(func=lambda c: True)
def cb_root(call: types.CallbackQuery) -> None:
    if _is_duplicate_callback(getattr(call, "id", "")):
        try: bot.answer_callback_query(call.id)
        except Exception: pass
        return
    uid = call.from_user.id
    if not RATE.allow(uid):
        ack(call, "Slow down.")
        maybe_auto_ban(uid, "callback rate")
        return
    if banned_block(call):
        ack(call); return
    get_or_create_user(call.from_user)
    if maintenance_block(uid):
        ack(call, "Maintenance mode"); return
    if not _is_verified(uid):
        ack(call, "Please solve the captcha first \u2014 send /start."); return
    data = call.data or ""
    try:
        _route_callback(call, data)
    except Exception as e:
        traceback.print_exc()
        try:
            bot.send_message(call.message.chat.id,
                f"<b>{G['no']}</b> Error: <code>{esc(e)}</code>")
        except Exception:
            pass


def _route_callback(call: types.CallbackQuery, data: str) -> None:
    # Core menus
    if data == "menu_main":     ack(call); render_main_menu(call.message.chat.id, call.from_user.id, call); return
    if data == "menu_bots":     ack(call); render_bots_menu(call); return
    if data == "menu_upload":   ack(call); render_upload_menu(call); return
    if data == "menu_plans":    ack(call); render_plans_menu(call); return
    if data == "menu_buy":      ack(call); render_buy_menu(call); return
    if data == "menu_profile":  ack(call); render_profile(call); return
    if data == "menu_referral": ack(call); render_referral(call); return
    if data == "menu_wallet":   ack(call); render_wallet(call); return
    if data == "menu_help":     ack(call); render_help(call); return
    if data == "menu_support":  ack(call); render_support(call); return
    if data == "menu_tickets":  ack(call); render_user_tickets(call); return
    if data == "menu_trial":    ack(call); render_trial(call); return
    if data == "menu_coupon":   ack(call); render_coupon(call); return
    if data == "menu_stats":    ack(call); render_user_stats(call); return
    if data == "menu_admin":    ack(call); render_admin(call); return
    if data == "menu_gh_host":  ack(call); render_gh_repo_host_menu(call); return
    # Plans
    if data.startswith("plan_view_"): ack(call); render_plan_detail(call, data.split("_", 2)[2]); return
    if data.startswith("plan_buy_"):  ack(call); render_payment_methods_for(call, data.split("_", 2)[2]); return
    # Payment
    if data.startswith("pay_") and data != "pay_proof": ack(call); render_payment_screen(call, data); return
    if data == "pay_proof": ack(call); start_proof_flow(call); return
    # Bot actions
    if data.startswith("bot_view_"):        ack(call); render_bot_view(call, data.split("_", 2)[2]); return
    if data.startswith("bot_start_"):       ack(call); action_bot_start(call, data.split("_", 2)[2]); return
    if data.startswith("bot_stop_"):        ack(call); action_bot_stop(call, data.split("_", 2)[2]); return
    if data.startswith("bot_restart_"):     ack(call); action_bot_restart(call, data.split("_", 2)[2]); return
    if data.startswith("bot_logs_"):        ack(call); action_bot_logs(call, data.split("_", 2)[2]); return
    if data.startswith("bot_info_"):        ack(call); action_bot_info(call, data.split("_", 2)[2]); return
    if data.startswith("bot_env_"):         ack(call); render_env_menu(call, data.split("_", 2)[2], 0); return
    if data.startswith("env_page_"):
        parts = data.split("_")
        if len(parts) >= 4:
            try:
                ack(call); render_env_menu(call, parts[2], int(parts[3])); return
            except (TypeError, ValueError):
                pass
    if data.startswith("env_add_"):         ack(call); start_env_add(call, data.split("_", 2)[2]); return
    if data.startswith("env_del_"):
        parts = data.split("_")
        if len(parts) >= 5:
            ack(call); action_env_delete(call, parts[2], parts[3], parts[4]); return
        if len(parts) >= 4:
            ack(call); action_env_delete(call, parts[2], parts[3]); return
    if data.startswith("bot_cron_"):        ack(call); render_cron(call, data.split("_", 2)[2]); return
    if data.startswith("bot_clone_"):       ack(call); action_bot_clone(call, data.split("_", 2)[2]); return
    if data.startswith("bot_dl_"):          ack(call); action_bot_download(call, data.split("_", 2)[2]); return
    if data.startswith("bot_pip_"):         ack(call); start_pip_install_flow(call, data.split("_", 2)[2]); return
    if data.startswith("bot_tunnel_"):      ack(call); start_tunnel_flow(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delete_"):      ack(call); render_bot_delete_confirm(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delyes_"):      ack(call); action_bot_delete(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delfiles_"):    ack(call); render_bot_delfiles_confirm(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delall_"):      ack(call); render_bot_delall_confirm(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delfilesyes_"): ack(call); action_bot_delfiles(call, data.split("_", 2)[2]); return
    if data.startswith("bot_delalyes_"):    ack(call); action_bot_delall(call, data.split("_", 2)[2]); return
    # GitHub user hosting
    if data == "gh_host_clone":       ack(call); action_gh_host_clone(call); return
    if data == "gh_host_set_token":   ack(call); action_gh_host_set_token(call); return
    if data == "gh_host_list":        ack(call); action_gh_host_list(call); return
    if data == "gh_host_remove_sel":
        ack(call)
        show_text(call.message.chat.id,
            f"<i>{sc('Select a bot from My GitHub Bots to manage and delete from there')}.</i>",
            _adm_back("menu_gh_host"), call=call); return
    # Approval
    if data.startswith("appr_ok_"):
        if not admin_only_call(call, "approve_payment"): return
        bid = data[len("appr_ok_"):]
        res = approve_bot(bid, call.from_user.id)
        ack(call, "Approved" if res.get("ok") else f"Err: {res.get('error')}")
        try: bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
        except Exception: pass
        return
    if data.startswith("appr_no_"):
        if not admin_only_call(call, "approve_payment"): return
        bid = data[len("appr_no_"):]
        res = reject_bot(bid, call.from_user.id, reason="rejected by admin")
        ack(call, "Rejected" if res.get("ok") else f"Err: {res.get('error')}")
        try: bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=None)
        except Exception: pass
        return
    # Admin sub-routes
    if data.startswith("adm_"):
        if not admin_only_call(call, "view_stats"): return
        ack(call); render_admin_subroute(call, data); return
    if data.startswith("gh_"):
        if not admin_only_call(call, "view_stats"): return
        ack(call); render_github_subroute(call, data); return
    # Misc
    if data == "trial_claim":     ack(call); action_trial_claim(call); return
    if data == "coupon_redeem":   ack(call); start_coupon_flow(call); return
    if data == "ticket_open":     ack(call); start_ticket_flow(call); return
    if data.startswith("ticket_view_"):  ack(call); render_ticket_view(call, data.split("_", 2)[2]); return
    if data.startswith("ticket_close_"): ack(call); action_ticket_close(call, data.split("_", 2)[2]); return
    if data.startswith("ticket_reply_"): ack(call); start_ticket_reply(call, data.split("_", 2)[2]); return
    if data == "wallet_topup":    ack(call); start_wallet_topup(call); return
    if data == "wallet_gift":     ack(call); start_wallet_gift(call); return
    if data.startswith("payapprove_"): ack(call); action_payment_approve(call, data.split("_", 1)[1]); return
    if data.startswith("payreject_"):  ack(call); action_payment_reject(call, data.split("_", 1)[1]); return
    if data == "noop": ack(call); return
    ack(call, "?")


# ─── Command Handlers ─────────────────────────────────────────────────────────

@bot.message_handler(commands=["start"])
def cmd_start(m: types.Message) -> None:
    if not _is_private(m): return
    uid = m.from_user.id
    if not RATE.allow(uid):
        maybe_auto_ban(uid, "rate"); return
    if banned_block(m): return
    global OWNER_ID
    if OWNER_ID <= 0:
        stored = int(get_setting("owner_id", 0) or 0)
        if stored > 0:
            OWNER_ID = stored
        else:
            OWNER_ID = uid
            set_setting("owner_id", uid)
            audit(uid, "owner_claim", f"first /start uid={uid}")
            try:
                bot.send_message(m.chat.id,
                    f"<b>{G['crown']} You are now the panel owner</b>\n"
                    f"{G['div']}\n{bullet('Owner ID', uid)}\n"
                    f"{sc('Set OWNER_ID env var to lock ownership permanently')}.",
                    parse_mode="HTML")
            except Exception: pass
    ref: Optional[int] = None
    parts = (m.text or "").split(maxsplit=1)
    if len(parts) == 2 and parts[1].isdigit():
        ref = int(parts[1])
    u, is_new = get_or_create_user(m.from_user, ref=ref)
    if maintenance_block(uid):
        bot.send_message(m.chat.id,
            f"<b>{G['warn']} Panel under maintenance</b>\n\nWe will be back shortly. {SUPPORT_USR} for urgent issues.")
        return
    if not require_verified(m.chat.id, uid): return
    if not require_group_membership(m.chat.id, uid): return
    intro = (
        f"{sc('You are now registered')}. Tap <b>Plans</b> or <b>Upload Bot</b> to begin."
        if is_new else
        f"{sc('Welcome back')}, <b>{esc(m.from_user.first_name or 'friend')}</b>!"
    )
    render_main_menu(m.chat.id, uid, intro=intro)


@bot.message_handler(commands=["help"])
def cmd_help(m: types.Message) -> None:
    if not _is_private(m): return
    if banned_block(m): return
    if not require_verified(m.chat.id, m.from_user.id): return
    render_help(type("_FakeCall", (), {
        "from_user": m.from_user,
        "message": m,
    })())


@bot.message_handler(commands=["menu"])
def cmd_menu(m: types.Message) -> None:
    if not _is_private(m): return
    if banned_block(m): return
    get_or_create_user(m.from_user)
    if not require_verified(m.chat.id, m.from_user.id): return
    render_main_menu(m.chat.id, m.from_user.id)


@bot.message_handler(commands=["id"])
def cmd_id(m: types.Message) -> None:
    if not _is_private(m): return
    bot.reply_to(m, f"<code>{m.from_user.id}</code>", parse_mode="HTML")


@bot.message_handler(commands=["cancel"])
def cmd_cancel(m: types.Message) -> None:
    if not _is_private(m): return
    USER_STATES.pop(m.from_user.id, None)
    bot.reply_to(m, f"{G['ok']} {sc('Cancelled')}")


@bot.message_handler(commands=["admin"])
def cmd_admin(m: types.Message) -> None:
    if not _is_private(m): return
    if not is_admin(m.from_user.id):
        bot.reply_to(m, f"{G['no']} Admin only."); return
    get_or_create_user(m.from_user)
    kb = types.InlineKeyboardMarkup()
    kb.add(Btn(f"{G['shield']}  Admin Panel", callback_data="menu_admin"))
    bot.send_message(m.chat.id,
        f"<b>{G['shield']} Admin Panel</b>", parse_mode="HTML", reply_markup=kb)


@bot.message_handler(func=lambda m: True, content_types=["photo"])
def on_photo(m: types.Message) -> None:
    if not _is_private(m): return
    if banned_block(m): return
    uid = m.from_user.id
    if not RATE.allow(uid): return
    get_or_create_user(m.from_user)
    if maintenance_block(uid): return
    st = USER_STATES.get(uid) or {}
    flow = st.get("flow", "")
    if flow == "await_menu_photo":
        if not is_owner(uid) and not admin_can(uid, "manage_admins"):
            USER_STATES.pop(uid, None); return
        key = st.get("photo_key", "")
        photo = m.photo[-1]
        try:
            f = bot.get_file(photo.file_id)
            raw = bot.download_file(f.file_path)
        except Exception as e:
            bot.reply_to(m, f"{G['no']} download error: <code>{esc(e)}</code>", parse_mode="HTML"); return
        ok = replace_menu_photo(key, raw)
        USER_STATES.pop(uid, None)
        label = PHOTO_KEYS_FRIENDLY.get(key, key)
        if ok:
            audit(uid, "menu_photo_replace", f"key={key} bytes={len(raw)}")
            bot.reply_to(m,
                f"<b>{G['ok']} Banner updated</b>\n{bullet('Menu', label)}\n{bullet('Size', fmt_bytes(len(raw)))}",
                parse_mode="HTML")
        else:
            bot.reply_to(m, f"{G['no']} Failed to save photo.")
        return
    if flow == "await_payment_proof": _handle_payment_proof(m, st); return
    if flow == "await_topup_proof":   _handle_topup_proof(m); return


@bot.message_handler(func=lambda m: True, content_types=["document"])
def on_document(m: types.Message) -> None:
    if not _is_private(m): return
    if banned_block(m): return
    uid = m.from_user.id
    if not RATE.allow(uid): return
    get_or_create_user(m.from_user)
    if maintenance_block(uid): return
    if not require_verified(m.chat.id, uid): return
    st = USER_STATES.get(uid) or {}
    flow = st.get("flow", "")
    if flow == "await_import_db":
        if not is_owner(uid): USER_STATES.pop(uid, None); return
        doc = m.document
        try:
            f = bot.get_file(doc.file_id)
            raw = bot.download_file(f.file_path)
            import json as _json2
            imported = _json2.loads(raw)
            _atomic_write(DB_FILE, imported)
            _cache_invalidate(DB_FILE)
            _mongo_put("db", imported)
            audit(uid, "import_db", f"size={len(raw)}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} DB imported. Restart bot to apply.")
        except Exception as e:
            bot.reply_to(m, f"{G['no']} Import error: <code>{esc(e)}</code>", parse_mode="HTML")
        return
    if flow == "await_payment_proof": _handle_payment_proof(m, st); return
    if flow == "await_topup_proof":   _handle_topup_proof(m); return
    doc = m.document
    fname = (doc.file_name or "").lower()
    is_bot_file = fname.endswith((".py", ".js", ".zip"))
    if flow == "await_upload" or is_bot_file:
        d = db_load()
        if str(uid) not in d["users"]:
            bot.reply_to(m, f"{G['no']} Please /start first."); return
        _handle_bot_upload(m)


@bot.message_handler(func=lambda m: True, content_types=["text"])
def on_text(m: types.Message) -> None:
    if not _is_private(m): return
    if banned_block(m): return
    uid = m.from_user.id
    text = (m.text or "").strip()
    if text.startswith("/"): return
    if not RATE.allow(uid): return
    get_or_create_user(m.from_user)
    if maintenance_block(uid): return
    if not require_verified(m.chat.id, uid): return
    st = USER_STATES.get(uid) or {}
    flow = st.get("flow", "")
    try:
        if flow == "await_adm_payment_setting":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            key = str(st.get("setting_key", "")); kind = str(st.get("kind", "text"))
            value = text
            try:
                if kind == "number":
                    value = float(text)
                    if value < 0: raise ValueError("value must be non-negative")
                    if float(value).is_integer(): value = int(value)
                elif kind == "currency":
                    value = text.upper().strip()
                    if value not in _CURRENCY_SYMBOLS: raise ValueError("unsupported currency code")
                elif not value and key != "payment_notif_channel":
                    raise ValueError("empty value")
                set_setting(key, value)
                audit(uid, "payment_setting", f"{key}={value}")
                USER_STATES.pop(uid, None)
                bot.reply_to(m, f"{G['ok']} {esc(key)} updated.", parse_mode="HTML")
            except Exception as e:
                bot.reply_to(m, f"{G['no']} Invalid value: <code>{esc(e)}</code>", parse_mode="HTML")
            return
        if flow == "await_adm_payment_template":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            set_setting("tmpl_payment_received", text[:1000])
            audit(uid, "payment_template_set", "payment_received")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Payment receipt template updated.", parse_mode="HTML"); return
        if flow == "await_env_kv":            return _handle_env_kv(m, st)
        if flow == "await_pip_install":       return _handle_pip_install(m, st)
        if flow == "await_tunnel_port":       return _handle_tunnel_port(m, st)
        if flow == "await_cron":              return _handle_cron(m, st)
        if flow == "await_admin_finduser":    return _handle_admin_finduser(m)
        if flow == "await_ban_cmd":           return _handle_ban_cmd(m)
        if flow == "await_giveplan":          return _handle_giveplan_cmd(m)
        if flow == "await_broadcast":         return _handle_broadcast(m)
        if flow == "await_coupon":            return _handle_coupon_user(m)
        if flow == "await_coupon_admin":      return _handle_coupon_admin(m)
        if flow == "await_admin_admins":      return _handle_admin_admins(m)
        if flow == "await_ticket_subject":    return _handle_ticket_subject(m)
        if flow == "await_ticket_body":       return _handle_ticket_body(m, st)
        if flow == "await_ticket_reply":      return _handle_ticket_reply(m, st)
        if flow == "await_payment_proof":     return _handle_payment_proof_text(m, st)
        if flow == "await_topup_proof":       return _handle_topup_proof(m)
        if flow == "await_gift_target":       return _handle_gift_target(m, st)
        if flow == "await_gift_confirm":      return _handle_gift_confirm(m, st)
        # GitHub config (admin)
        if flow == "await_gh_token":
            gh_set_config({"token": text}); gh_load_config()
            USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} token saved"); return
        if flow == "await_gh_repo":
            gh_set_config({"repo": text}); gh_load_config()
            USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} repo saved"); return
        if flow == "await_gh_branch":
            gh_set_config({"branch": text}); gh_load_config()
            USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} branch saved"); return
        if flow == "await_gh_interval":
            try: v = max(15, int(text))
            except Exception: v = 360
            gh_set_config({"intervalMin": v}); gh_load_config()
            USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} interval saved"); return
        # Settings flows
        if flow == "await_set_brand":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            new = (text or "").strip()[:64]
            if not new: bot.reply_to(m, f"{G['no']} empty"); USER_STATES.pop(uid, None); return
            global BRAND_TAG
            BRAND_TAG = new
            set_setting("brand_tag", new)
            audit(uid, "set_brand", new)
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Brand: <b>{esc(new)}</b>", parse_mode="HTML"); return
        if flow == "await_set_announce":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            v = (text or "").strip()
            if v == "-": v = ""
            global ANNOUNCE_CHANNEL
            ANNOUNCE_CHANNEL = v
            set_setting("announce_channel", v)
            audit(uid, "set_announce", v or "(cleared)")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Announce channel: <code>{esc(v) if v else '—'}</code>",
                         parse_mode="HTML"); return
        if flow == "await_set_owner":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            try: new_owner = int((text or "").strip())
            except Exception: bot.reply_to(m, f"{G['no']} invalid id"); return
            if new_owner <= 0: bot.reply_to(m, f"{G['no']} invalid id"); return
            global OWNER_ID
            OWNER_ID = new_owner
            set_setting("owner_id", new_owner)
            audit(uid, "transfer_owner", f"new={new_owner}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m,
                f"{G['ok']} Ownership transferred to <code>{new_owner}</code>.",
                parse_mode="HTML"); return
        if flow == "await_set_footer":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            v = (text or "").strip()
            set_setting("custom_footer", "" if v == "-" else v)
            audit(uid, "set_footer", v)
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Footer updated."); return
        if flow == "await_set_welcome":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            set_setting("custom_welcome", (text or "").strip())
            audit(uid, "set_welcome", "")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Welcome message updated."); return
        if flow == "await_set_rules":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            set_setting("hosting_rules", (text or "").strip())
            audit(uid, "set_rules", "")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Hosting rules updated."); return
        # GitHub user hosting flows
        if flow == "await_gh_repo_url":
            d = db_load()
            u_doc = d["users"].get(str(uid), {})
            if not is_admin(uid) and not _user_can_host_gh(u_doc):
                USER_STATES.pop(uid, None); return
            repo_url = (text or "").strip()
            if not repo_url.startswith("http"):
                bot.reply_to(m, f"{G['no']} Invalid URL \u2014 must start with https://"); return
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"\u23f3 Cloning repo\u2026 This may take a minute.")
            def _bg_clone():
                d2 = db_load()
                u_doc2 = d2["users"].get(str(uid), {})
                user_token = u_doc2.get("gh_user_token")
                bot_id = secrets.token_hex(8)
                bot_dir = DIRS["sandbox"] / f"{uid}_{bot_id}"
                res = _clone_gh_repo(repo_url, user_token, bot_dir)
                if not res.get("ok"):
                    try:
                        bot.send_message(uid,
                            f"<b>{G['no']} Clone failed</b>\n<code>{esc(res.get('error', ''))}</code>",
                            parse_mode="HTML")
                    except Exception: pass
                    return
                repo_name = repo_url.rstrip("/").split("/")[-1]
                name = safe_name(repo_name)
                entry = "bot.py"
                for candidate in ("bot.py", "main.py", "app.py", "index.js", "bot.js"):
                    if (bot_dir / candidate).exists():
                        entry = candidate; break
                doc = {
                    "_id": bot_id, "owner": uid, "name": name,
                    "dir": str(bot_dir), "created": ts_iso(),
                    "enc_files": {}, "env": {}, "status": "stopped", "cron": {},
                    "source": "github", "gh_repo": repo_url, "entry": entry,
                }
                d3 = db_load()
                d3["bots"][bot_id] = doc
                db_save(d3)
                audit(uid, "gh_repo_clone", f"repo={repo_url} bot_id={bot_id}")
                try:
                    bot.send_message(uid,
                        f"<b>{G['ok']} \U0001f419 Repo cloned</b>\n"
                        f"{bullet('Name', name)}\n{bullet('Entry', entry)}\n{bullet('Bot ID', bot_id)}\n"
                        f"{sc('Find it in My Bots to start')}.{FOOTER}",
                        parse_mode="HTML")
                except Exception: pass
            threading.Thread(target=_bg_clone, daemon=True).start(); return
        if flow == "await_gh_user_token":
            tok = (text or "").strip()
            USER_STATES.pop(uid, None)
            d = db_load()
            d["users"].setdefault(str(uid), {})["gh_user_token"] = tok
            db_save(d)
            audit(uid, "gh_user_token_set", "")
            bot.reply_to(m, f"{G['ok']} GitHub token saved."); return
        # TG backup channel setting
        if flow == "await_tg_backup_channel":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            ch = (text or "").strip()
            if not ch: bot.reply_to(m, f"{G['no']} empty"); return
            set_setting("tg_backup_channel", ch)
            audit(uid, "tg_backup_channel_set", f"ch={ch}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} TG backup channel: <code>{esc(ch)}</code>",
                         parse_mode="HTML"); return
        # Group verification flows
        if flow == "await_adm_grpv_add":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            parts = (text or "").strip().split("|")
            if len(parts) < 3:
                bot.reply_to(m, f"{G['no']} Format: <code>NAME|GROUP_ID|INVITE_LINK</code>",
                             parse_mode="HTML"); return
            name_grp, gid_str, link = parts[0].strip(), parts[1].strip(), parts[2].strip()
            try: gid = int(gid_str)
            except Exception: bot.reply_to(m, f"{G['no']} Group ID must be numeric"); return
            grps = list(get_setting("required_groups", []) or [])
            grps.append({"name": name_grp, "id": gid, "link": link})
            set_setting("required_groups", grps)
            _load_required_groups()
            audit(uid, "grpv_add", f"name={name_grp} id={gid}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Group added: {esc(name_grp)}"); return
        if flow == "await_adm_grpv_remove":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            try: idx = int((text or "").strip()) - 1
            except Exception: bot.reply_to(m, f"{G['no']} Send the group number"); return
            grps = list(get_setting("required_groups", []) or [])
            if 0 <= idx < len(grps):
                removed = grps.pop(idx)
                set_setting("required_groups", grps)
                _load_required_groups()
                audit(uid, "grpv_remove", f"name={removed.get('name')}")
                USER_STATES.pop(uid, None)
                bot.reply_to(m, f"{G['ok']} Group removed: {esc(removed.get('name', '?'))}")
            else:
                bot.reply_to(m, f"{G['no']} Invalid number"); return
            return
        if flow == "await_adm_private_apgrp":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            val = (text or "").strip()
            if not val: bot.reply_to(m, f"{G['no']} empty"); return
            set_setting("private_approval_group", val)
            audit(uid, "private_apgrp_set", f"val={val}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} Private approval group: <code>{esc(val)}</code>",
                         parse_mode="HTML"); return
        if flow == "await_adm_pay_number":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            key = str(st.get("pm_key", ""))
            if key not in PAYMENT_METHODS:
                USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['no']} Unknown payment method."); return
            val = text.strip()
            if PAYMENT_METHODS[key].get("type") == "UPI" and not _is_valid_upi_id(val):
                bot.reply_to(m, f"{G['no']} Invalid UPI ID. Example: <code>name@upi</code>", parse_mode="HTML"); return
            set_setting(f"pm_number_{key}", val)
            audit(uid, f"pm_set_{key}", "payment details updated")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} {esc(PAYMENT_METHODS[key]['name'])} details updated.", parse_mode="HTML"); return
        if flow == "await_adm_emoji":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            key = str(st.get("emoji_key", "")).strip()
            val = (text or "").strip()
            custom = get_setting("custom_emojis", {}) or {}
            if val == "-": custom.pop(key, None)
            elif key and len(val) <= 16: custom[key] = val
            else: bot.reply_to(m, f"{G['no']} Invalid emoji value"); return
            set_setting("custom_emojis", custom); USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} Emoji updated."); return
        if flow == "await_adm_template":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            key = str(st.get("template_key", ""))
            if key not in _MESSAGE_TEMPLATES: USER_STATES.pop(uid, None); return
            set_setting(f"tmpl_{key}", text.strip()); USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} Template updated."); return
        if flow == "await_adm_rate":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            plan, metric = str(st.get("plan","")), str(st.get("metric",""))
            try: val = max(0, int(text.strip()))
            except Exception: bot.reply_to(m, f"{G['no']} Send a whole number."); return
            if plan not in _RATE_LIMIT_DEFAULTS or metric not in ("uploads_per_day","starts_per_hour","msgs_per_min"):
                USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['no']} Invalid rate setting."); return
            set_setting(f"rl_{plan}_{metric}", val); USER_STATES.pop(uid, None); bot.reply_to(m, f"{G['ok']} Rate limit updated."); return
        # Advanced panel text flows
        if flow == "await_adm_user_search":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            q = (text or "").strip().lstrip("@").lower()
            d = db_load()
            results = []
            for _uid, u in d["users"].items():
                if (q.isdigit() and _uid == q) or \
                   q in str(u.get("username","")).lower() or \
                   q in str(u.get("name","")).lower():
                    bc = sum(1 for b in d["bots"].values() if str(b.get("owner")) == _uid)
                    results.append(
                        f"{G['bullet']} <code>{_uid}</code> <b>{esc(u.get('name','?'))}</b> "
                        f"@{esc(u.get('username','—'))} plan={u.get('plan','free')} bots={bc}"
                    )
            USER_STATES.pop(uid, None)
            reply = "\n".join(results[:10]) or f"<i>{sc('No users found')}</i>"
            bot.reply_to(m, f"<b>\U0001f50d Results</b>\n{G['div_eq']}\n{reply}", parse_mode="HTML"); return
        if flow == "await_adm_wallet_adjust":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            parts = (text or "").strip().split(None, 1)
            if len(parts) < 2:
                bot.reply_to(m, f"{G['no']} Format: <code>uid +/-/=amount</code>", parse_mode="HTML"); return
            target_uid, op_str = parts[0].strip(), parts[1].strip()
            d = db_load()
            if target_uid not in d["users"]:
                bot.reply_to(m, f"{G['no']} User not found."); return
            u = d["users"][target_uid]
            try:
                cur = float(u.get("wallet", 0))
                if op_str.startswith("+"): new_bal = cur + float(op_str[1:])
                elif op_str.startswith("-"): new_bal = max(0, cur - float(op_str[1:]))
                elif op_str.startswith("="): new_bal = float(op_str[1:])
                else: new_bal = float(op_str)
                u["wallet"] = round(new_bal, 2)
                db_save(d)
                audit(uid, "wallet_adjust", f"uid={target_uid} old={cur} new={new_bal}")
                USER_STATES.pop(uid, None)
                bot.reply_to(m, f"{G['ok']} uid <code>{target_uid}</code>: <b>{money(cur)}</b> \u2192 <b>{money(new_bal)}</b>",
                             parse_mode="HTML")
            except Exception as _we:
                bot.reply_to(m, f"{G['no']} Error: <code>{esc(_we)}</code>", parse_mode="HTML")
            return
        if flow == "await_adm_notify_user":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            parts = (text or "").split(None, 1)
            if len(parts) < 2:
                bot.reply_to(m, f"{G['no']} Format: <code>user_id message</code>", parse_mode="HTML"); return
            target_uid_str, msg_text = parts[0].strip(), parts[1].strip()
            USER_STATES.pop(uid, None)
            try:
                bot.send_message(int(target_uid_str),
                    f"<b>\U0001f4e8 Message from Admin</b>\n{G['div']}\n{esc(msg_text)}",
                    parse_mode="HTML")
                audit(uid, "notify_user", f"to={target_uid_str}")
                bot.reply_to(m, f"{G['ok']} Message sent.")
            except Exception as _ne:
                bot.reply_to(m, f"{G['no']} Failed: <code>{esc(_ne)}</code>", parse_mode="HTML")
            return
        if flow == "await_adm_user_reset":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            target_uid_str = (text or "").strip()
            d = db_load()
            if target_uid_str not in d["users"]:
                bot.reply_to(m, f"{G['no']} User not found."); return
            for b in list(d["bots"].values()):
                if str(b.get("owner")) == target_uid_str:
                    try: stop_child(b["_id"])
                    except Exception: pass
                    d["bots"].pop(b["_id"], None)
            d["users"][target_uid_str]["plan"] = "free"
            d["users"][target_uid_str]["plan_expires"] = None
            d["users"][target_uid_str]["wallet"] = 0
            db_save(d)
            audit(uid, "user_reset", f"uid={target_uid_str}")
            USER_STATES.pop(uid, None)
            bot.reply_to(m, f"{G['ok']} uid <code>{target_uid_str}</code> reset.",
                         parse_mode="HTML"); return
        if flow == "await_adm_bot_search":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            q = (text or "").strip().lower()
            bots = db_load()["bots"]
            results = []
            for bid, b in bots.items():
                if q in bid.lower() or q in b.get("name", "").lower():
                    running = bid in RUNNING and RUNNING[bid]["proc"].poll() is None
                    results.append(
                        f"{G['bullet']} <code>{bid}</code> <b>{esc(b.get('name','?'))}</b> "
                        f"uid={b.get('owner')} {'&#x25B6;' if running else '&#x23F9;'}"
                    )
            USER_STATES.pop(uid, None)
            reply = "\n".join(results[:10]) or f"<i>{sc('No bots found')}</i>"
            bot.reply_to(m, f"<b>\U0001f50d Bot Search</b>\n{G['div_eq']}\n{reply}",
                         parse_mode="HTML"); return
        if flow == "await_adm_notify_running":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            target_uids = st.get("target_uids", [])
            msg_text = (text or "").strip()
            USER_STATES.pop(uid, None)
            if not msg_text:
                bot.reply_to(m, f"{G['no']} Empty message."); return
            def _bg_nr():
                sent = fail = 0
                for t_uid in target_uids:
                    try:
                        bot.send_message(int(t_uid),
                            f"<b>\U0001f4e2 Admin Message</b>\n{G['div']}\n{esc(msg_text)}",
                            parse_mode="HTML")
                        sent += 1
                    except Exception: fail += 1
                audit(uid, "notify_targeted", f"sent={sent} fail={fail}")
                try: bot.send_message(uid, f"{G['ok']} Sent to {sent} ({fail} failed).")
                except Exception: pass
            threading.Thread(target=_bg_nr, daemon=True).start()
            bot.reply_to(m, f"{G['ok']} Sending to {len(target_uids)} users\u2026"); return
        if flow == "await_adm_quick_announce":
            if not is_owner(uid): USER_STATES.pop(uid, None); return
            msg_text = (text or "").strip()
            USER_STATES.pop(uid, None)
            if not msg_text or not ANNOUNCE_CHANNEL:
                bot.reply_to(m, f"{G['no']} No message or channel not configured."); return
            try:
                sent = bot.send_message(_normalize_chat_ref(ANNOUNCE_CHANNEL),
                    f"\U0001f4e3 <b>{BRAND_TAG}</b>\n{G['div']}\n{esc(msg_text)}", parse_mode="HTML")
                try: bot.pin_chat_message(_normalize_chat_ref(ANNOUNCE_CHANNEL), sent.message_id)
                except Exception: pass
                audit(uid, "quick_announce", "")
                bot.reply_to(m, f"{G['ok']} Announced and pinned.")
            except Exception as _qe:
                bot.reply_to(m, f"{G['no']} Failed: <code>{esc(_qe)}</code>", parse_mode="HTML")
            return
        if flow == "await_adm_whitelist":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            parts = (text or "").strip().split(None, 1)
            cmd = parts[0].lower() if parts else ""
            target = parts[1].strip() if len(parts) > 1 else ""
            wl = list(get_setting("scan_whitelist", []) or [])
            if cmd == "add" and target:
                if target not in wl: wl.append(target)
                set_setting("scan_whitelist", wl)
                audit(uid, "whitelist_add", target)
                bot.reply_to(m, f"{G['ok']} Added.", parse_mode="HTML")
            elif cmd == "del" and target:
                if target in wl: wl.remove(target)
                set_setting("scan_whitelist", wl)
                audit(uid, "whitelist_del", target)
                bot.reply_to(m, f"{G['ok']} Removed.", parse_mode="HTML")
            else:
                bot.reply_to(m, f"{G['no']} Use: <code>add uid</code> or <code>del uid</code>", parse_mode="HTML")
            USER_STATES.pop(uid, None); return
        if flow == "await_adm_blacklist":
            if not is_admin(uid): USER_STATES.pop(uid, None); return
            parts = (text or "").strip().split(None, 1)
            cmd = parts[0].lower() if parts else ""
            domain = parts[1].strip() if len(parts) > 1 else ""
            bl = list(get_setting("domain_blacklist", []) or [])
            if cmd == "add" and domain:
                if domain not in bl: bl.append(domain)
                set_setting("domain_blacklist", bl)
                audit(uid, "blacklist_add", domain)
                bot.reply_to(m, f"{G['ok']} Added.", parse_mode="HTML")
            elif cmd == "del" and domain:
                if domain in bl: bl.remove(domain)
                set_setting("domain_blacklist", bl)
                audit(uid, "blacklist_del", domain)
                bot.reply_to(m, f"{G['ok']} Removed.", parse_mode="HTML")
            else:
                bot.reply_to(m, f"{G['no']} Use: <code>add domain.com</code> or <code>del domain.com</code>",
                             parse_mode="HTML")
            USER_STATES.pop(uid, None); return
    except Exception as e:
        traceback.print_exc()
        bot.reply_to(m, f"{G['no']} error: <code>{esc(e)}</code>", parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════════════
# SCHEDULER / CRON RUNNER
# ═══════════════════════════════════════════════════════════════════════════════

def cron_runner() -> None:
    """Every minute: plan expiry, scheduled broadcasts, per-bot cron, TG backup."""
    last_per_bot: Dict[str, Dict[str, float]] = {}
    last_tg_backup: float = 0.0
    while True:
        try:
            now = time.time()
            downgrade_expired_users()
            expiry_reminders()
            # Scheduled broadcasts
            d = db_load()
            sb = d.get("scheduled_broadcasts", [])
            kept: List[Dict[str, Any]] = []
            for b in sb:
                try:
                    when = datetime.fromisoformat(str(b["at"]).replace("Z", "+00:00"))
                except Exception:
                    continue
                if when <= now_utc():
                    users = db_load()["users"]
                    sent = fail = 0
                    for uid_str, u in users.items():
                        if u.get("banned"): continue
                        pf = b.get("plan")
                        if pf and u.get("plan") != pf: continue
                        try:
                            bot.send_message(int(uid_str),
                                f"<b>\U0001f4e2 {BRAND_TAG}</b>\n{G['div']}\n{esc(b['text'])}",
                                parse_mode="HTML", disable_web_page_preview=True)
                            sent += 1
                        except Exception: fail += 1
                        time.sleep(0.05)
                    audit(b.get("by", 0), "broadcast_run", f"sent={sent} fail={fail}")
                else:
                    kept.append(b)
            if len(kept) != len(sb):
                d["scheduled_broadcasts"] = kept
                db_save(d)
            # Per-bot cron
            for bid, bdoc in db_load()["bots"].items():
                cron = bdoc.get("cron") or {}
                last = last_per_bot.setdefault(bid, {})
                if cron.get("restart_hours"):
                    iv = int(cron["restart_hours"]) * 3600
                    if now - last.get("restart", 0) >= iv:
                        try: restart_child(bdoc)
                        except Exception: pass
                        last["restart"] = now
                if cron.get("backup_hours"):
                    iv = int(cron["backup_hours"]) * 3600
                    if now - last.get("backup", 0) >= iv:
                        try: gh_backup_now()
                        except Exception: pass
                        last["backup"] = now
            # Auto TG channel backup
            tg_interval = int(get_setting("tg_backup_interval_h", 6)) * 3600
            if _tg_channel_backup_enabled() and bool(get_setting("tg_backup_auto", False)):
                if now - last_tg_backup >= tg_interval:
                    try:
                        res = tg_channel_backup_now()
                        print(f"[cron] tg backup: ok={res.get('ok')} size={res.get('size',0)}", flush=True)
                    except Exception as e:
                        print(f"[cron] tg backup error: {e}", flush=True)
                    last_tg_backup = now
        except Exception:
            traceback.print_exc()
        time.sleep(60)


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def banner() -> None:
    line = "=" * 64
    print(line)
    print(f"   {BRAND_TAG}")
    print(f"   owner id    : {OWNER_ID}")
    print(f"   gh backup   : {'on' if gh_enabled() else 'off'}")
    print(f"   mongo store : {'on' if _PANEL_MONGO_URI else 'off'}")
    print(f"   tg bkp ch   : {_tg_backup_channel() or '—'}")
    print(f"   announce ch : {ANNOUNCE_CHANNEL or '—'}")
    print(line)


def main() -> int:
    banner()
    global OWNER_ID, BRAND_TAG, ANNOUNCE_CHANNEL
    stored_owner = int(get_setting("owner_id", 0) or 0)
    if stored_owner > 0 and OWNER_ID <= 0:
        OWNER_ID = stored_owner
    bt = get_setting("brand_tag", None)
    if isinstance(bt, str) and bt:
        BRAND_TAG = bt
    ac = get_setting("announce_channel", None)
    if isinstance(ac, str):
        ANNOUNCE_CHANNEL = ac
    gh_load_config()
    GH["autoEnabled"] = bool(get_setting("github_auto_enabled", True))
    # Recover the master state before any other boot-time restoration logic.
    _durable_restore_on_boot()
    cache_clear_all()
    try:
        set_setting("payment_currency", "INR")
        set_setting("currency_symbol", "₹")
    except Exception:
        pass
    _load_required_groups()
    # Restore from GitHub on boot
    try:
        res = gh_auto_restore_on_boot()
        if res and res.get("ok"):
            print(f"[boot] restored gh backup ({fmt_bytes(res.get('sizeBytes', 0))})", flush=True)
    except Exception:
        pass
    try:
        gh_restore_custom_photos()
    except Exception:
        pass
    # Migrate any legacy plaintext child ENV / secret settings immediately
    # after restore so they do not remain on disk in clear text.
    _secure_storage_migrate()
    # Background threads
    threading.Thread(target=gh_auto_loop, daemon=True).start()
    threading.Thread(target=gh_uptime_backup_loop, daemon=True, name="gh-uptime-backup").start()
    threading.Thread(target=cron_runner, daemon=True).start()
    threading.Thread(target=_verify_state_janitor, daemon=True, name="verify-janitor").start()
    _start_extra_background_threads()
    _start_keepalive()
    # Bot commands
    try:
        bot.set_my_commands([
            types.BotCommand("start",  "Open main menu"),
            types.BotCommand("menu",   "Main menu"),
            types.BotCommand("help",   "Help & FAQ"),
            types.BotCommand("id",     "Your user ID"),
            types.BotCommand("cancel", "Cancel current action"),
            types.BotCommand("admin",  "Admin panel"),
        ])
    except Exception:
        pass
    # Notify owner on start
    notify_owner(
        f"<b>{G['ok']} Panel Online</b>\n"
        f"{bullet('Brand',   BRAND_TAG)}\n"
        f"{bullet('Owner',   OWNER_ID)}\n"
        f"{bullet('Users',   len(db_load()['users']))}\n"
        f"{bullet('Bots',    len(db_load()['bots']))}\n"
        f"{bullet('GH Bkp',  'on' if gh_enabled() else 'off')}\n"
        f"{bullet('TG Bkp',  _tg_backup_channel() or 'off')}"
    )
    # Auto-start bots that were running
    for b in db_load()["bots"].values():
        if b.get("status") == "running":
            try: start_child(b)
            except Exception: pass
    # Clear old webhook
    try:
        bot.remove_webhook()
        try: bot.delete_webhook(drop_pending_updates=True)
        except Exception: pass
        print("[bot] webhook cleared", flush=True)
    except Exception as e:
        print(f"[bot] webhook clear warning: {e}", flush=True)
    print("[bot] polling\u2026", flush=True)
    while True:
        try:
            bot.infinity_polling(skip_pending=True, timeout=30, long_polling_timeout=25)
        except KeyboardInterrupt:
            print("\n[bot] stopping\u2026", flush=True)
            for bid in list(RUNNING.keys()):
                stop_child(bid, manual=False)
            return 0
        except Exception as e:
            msg = str(e)
            print(f"[bot] poll error: {e}", flush=True)
            # Telegram 409 means another process currently owns getUpdates.
            # Do not hammer the API from both instances. Wait long enough for
            # the distributed lease/old process to settle, then retry.
            if "409" in msg or "Conflict: terminated by other getUpdates request" in msg:
                time.sleep(20)
            else:
                time.sleep(5)





if __name__ == "__main__":
    sys.exit(main())
